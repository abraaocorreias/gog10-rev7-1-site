# 2G · [Material Técnico Mecânico · 11 Peças] Somente Talas Aparafusadas M3 (7 un.) e Vigas de Balanço (4 un.) — PETG-CF (100% Sólido)

- **Propósito / Função**: Únicas peças do esqueleto que exigem parede cheia 100% e fibra de carbono
- **Material Recomendado**: `PETG-CF (Fibra de Carbono · 100% Sólido + 4 Perímetros)`
- **Cor Indicada**: `Preto Fosco Técnico CF` (`#18191C`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `100% Solido + 4 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `17` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `169.4 cm³` · **`~201 g`** · **`~9.4 h`** (`218 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-244` | `ESQ_Viga_Reforco_Balanco_Y137_Dir` | `123.9 × 15.9 × 12.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 23.32 | ~27.7 g | ~1.23 h |
| `GOG-245` | `ESQ_Viga_Reforco_Balanco_Y137_Esq` | `131.9 × 15.9 × 12.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 23.98 | ~28.5 g | ~1.27 h |
| `GOG-246` | `ESQ_Viga_Reforco_Balanco_Y61_Dir` | `123.9 × 15.9 × 12.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 23.32 | ~27.7 g | ~1.23 h |
| `GOG-247` | `ESQ_Viga_Reforco_Balanco_Y61_Esq` | `131.9 × 15.9 × 12.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 23.98 | ~28.5 g | ~1.27 h |
| `GOG-248` | `ESQ_Viga_Transf_BayRear_Z76` | `52.0 × 8.0 × 6.15` | `100% Solido + 4 Perimetros (Sem Suporte)` | 2.56 | ~3.0 g | ~0.17 h |
| `GOG-487` | `FIX_Tala_Struct_CasseteTrilho_Front` | `38.0 × 13.0 × 2.6` | `100% Solido + 4 Perimetros (Sem Suporte)` | 1.28 | ~1.5 g | ~0.11 h |
| `GOG-488` | `FIX_Tala_Struct_CasseteTrilho_Rear` | `38.0 × 3.55 × 2.55` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.34 | ~0.4 g | ~0.08 h |
| `GOG-489` | `FIX_Tala_Struct_Deck_Front_X38` | `68.0 × 15.0 × 4.5` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.58 | ~5.4 g | ~0.27 h |
| `GOG-490` | `FIX_Tala_Struct_Deck_Rear_X10` | `60.0 × 16.0 × 4.5` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.31 | ~5.1 g | ~0.26 h |
| `GOG-491` | `FIX_Tala_Struct_Esq_N1_Y146` | `14.5 × 12.0 × 2.7` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.47 | ~0.6 g | ~0.08 h |
| `GOG-492` | `FIX_Tala_Struct_Longarina_T4_Y100` | `70.0 × 13.0 × 4.4` | `100% Solido + 4 Perimetros (Sem Suporte)` | 3.38 | ~4.0 g | ~0.21 h |
| `GOG-493` | `FIX_Tala_Struct_MOD3_iClamper_Dir_Y22` | `39.4 × 35.0 × 1.65` | `100% Solido + 4 Perimetros (Sem Suporte)` | 2.27 | ~2.7 g | ~0.16 h |
| `GOG-494` | `FIX_Tala_Struct_MOD3_iClamper_Esq_Y22` | `39.4 × 35.0 × 1.65` | `100% Solido + 4 Perimetros (Sem Suporte)` | 2.27 | ~2.7 g | ~0.16 h |
| `GOG-495` | `FIX_Tala_Struct_Travessa_Front_Deck` | `72.0 × 17.0 × 16.5` | `100% Solido + 4 Perimetros (Sem Suporte)` | 9.66 | ~11.5 g | ~0.53 h |
| `GOG-496` | `FIX_Tala_Struct_Viga_Arco_X40` | `68.0 × 25.5 × 20.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 16.54 | ~19.6 g | ~0.89 h |
| `GOG-497` | `FIX_Tala_Struct_Viga_Balanco_Y137` | `72.0 × 19.4 × 14.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 11.03 | ~13.1 g | ~0.60 h |
| `GOG-498` | `FIX_Tala_Struct_Viga_Balanco_Y61` | `72.0 × 22.0 × 19.4` | `100% Solido + 4 Perimetros (Sem Suporte)` | 16.17 | ~19.2 g | ~0.87 h |
