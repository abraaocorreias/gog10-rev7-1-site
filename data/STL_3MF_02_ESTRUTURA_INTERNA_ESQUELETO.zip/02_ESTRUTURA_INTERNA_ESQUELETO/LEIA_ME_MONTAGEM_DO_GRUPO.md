# 02 · Estrutura Portante Interna (Colunas, Pisos e Longarinas em PETG Comum / PLA+ + Talas/Vigas em PETG-CF)

**Objetivo construtivo**: As 26 colunas tem margem contra flambagem >= 15x no pior caso! Por isso, 101 das 112 pecas do esqueleto (colunas, pisos, longarinas e suportes de pele) usam PETG Comum ou PLA+ (20% infill, 3 perimetros), reservando PETG-CF (100% solido) apenas para as 7 talas aparafusadas M3 e 4 vigas criticas de balanco (2G).

**Como montar este grupo**: Passo 2: Erga as 7 colunas T1 (2A) sobre as sapatas e trave com as longarinas Z25/N1 (2F). Suba as 7 colunas T2 (2B) e o Piso Deck Central Z=360 mm (2E) unido pelas vigas e talas M3 (2G). Finalize com as colunas T3 (2C), T4 e Viga Arco (2D).

| Subpasta | Material | Fatiamento | Peças | Bandejas 202×202 | Peso Leve | Tempo Estimado |
|---|---|---|---:|---:|---:|---:|
| `2A_Colunas_Andar1_T1__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 7 | 1 | **~115 g** | **~3.7 h** |
| `2B_Colunas_Andar2_T2__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 7 | 1 | **~112 g** | **~3.6 h** |
| `2C_Colunas_Andar3_T3__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 6 | 1 | **~92 g** | **~3.0 h** |
| `2D_Colunas_Andar4_T4_e_Arco_Superior__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 13 | 2 | **~152 g** | **~5.0 h** |
| `2E_Placas_Piso_Deck_Central_Z360__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 6 | 6 | **~278 g** | **~8.5 h** |
| `2F_Longarinas_Travessas_e_Bracos_Pele__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 56 | 4 | **~303 g** | **~11.3 h** |
| `2G_Talas_Parafusadas_M3_e_Vigas_Balanco__PETG-CF_100Pct_Solido` | PETG-CF (Fibra de Carbono · 100% Sólido + 4 Perímetros) | `100% Solido + 4 Perimetros (Sem Suporte)` | 17 | 1 | **~201 g** | **~9.4 h** |
