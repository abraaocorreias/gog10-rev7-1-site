# 2A · Colunas do 1º Andar (7 colunas · FoS >= 15×) — PETG Comum ou PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Pilares do andar inferior com margem de flambagem >= 15x (não precisam de CF!)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `7` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `258.7 cm³` · **`~115 g`** · **`~3.7 h`** (`323 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-144` | `ESQ_Col_BayCheek_T1` | `173.6 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 25.00 | ~13.5 g | ~0.44 h |
| `GOG-148` | `ESQ_Col_BayRear_T1` | `68.85 × 14.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.71 | ~4.5 g | ~0.17 h |
| `GOG-152` | `ESQ_Col_Front_Dir_T1` | `173.6 × 24.0 × 14.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 58.33 | ~26.2 g | ~0.82 h |
| `GOG-156` | `ESQ_Col_Front_Esq_T1` | `173.6 × 51.5 × 27.55` | `20% Infill + 3 Perimetros (Sem Suporte)` | 67.13 | ~23.9 g | ~0.75 h |
| `GOG-160` | `ESQ_Col_Mid_Esq_T1` | `173.6 × 19.0 × 9.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 29.69 | ~15.3 g | ~0.49 h |
| `GOG-164` | `ESQ_Col_Rear_EsqExt_T1` | `173.6 × 27.6 × 22.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 36.44 | ~14.8 g | ~0.48 h |
| `GOG-168` | `ESQ_Col_Rear_Esq_T1` | `173.6 × 22.0 × 9.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 34.37 | ~17.2 g | ~0.55 h |
