# 2D · Colunas do 4º Andar (6 colunas), Viga Arco e Nervuras — PETG Comum ou PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Fechamento estrutural superior do pórtico no nível T4 (Z = 536 a 596 mm)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `13` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `317.5 cm³` · **`~152 g`** · **`~5.0 h`** (`397 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-147` | `ESQ_Col_BayCheek_T4` | `67.6 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 9.73 | ~5.4 g | ~0.20 h |
| `GOG-151` | `ESQ_Col_BayRear_T4` | `67.6 × 14.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.57 | ~4.4 g | ~0.17 h |
| `GOG-155` | `ESQ_Col_Front_Dir_T4` | `60.9 × 24.0 × 14.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 20.46 | ~9.6 g | ~0.33 h |
| `GOG-159` | `ESQ_Col_Front_Esq_T4` | `72.6 × 27.55 × 16.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 19.01 | ~8.4 g | ~0.29 h |
| `GOG-163` | `ESQ_Col_Rear_Dir_T4` | `60.9 × 29.88 × 18.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 15.62 | ~6.8 g | ~0.24 h |
| `GOG-167` | `ESQ_Col_Rear_EsqExt_T4` | `60.9 × 14.0 × 13.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 11.08 | ~6.0 g | ~0.22 h |
| `GOG-191` | `ESQ_Longarina_T4_Arco_Dir` | `174.0 × 14.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 18.77 | ~10.7 g | ~0.36 h |
| `GOG-192` | `ESQ_Longarina_T4_Arco_Esq_Front` | `197.8 × 14.0 × 13.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 35.88 | ~18.7 g | ~0.59 h |
| `GOG-193` | `ESQ_Longarina_T4_Arco_Esq_Rear` | `199.3 × 37.0 × 19.55` | `20% Infill + 3 Perimetros (Sem Suporte)` | 38.59 | ~15.1 g | ~0.49 h |
| `GOG-194` | `ESQ_Nervura_ASA_8x50_Seg1` | `184.0 × 50.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 67.45 | ~31.2 g | ~0.97 h |
| `GOG-195` | `ESQ_Nervura_ASA_8x50_Seg2` | `71.3 × 50.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 28.37 | ~13.6 g | ~0.44 h |
| `GOG-242` | `ESQ_Viga_Arco_MOD4_Top_Dir` | `79.8 × 18.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 16.53 | ~8.4 g | ~0.29 h |
| `GOG-243` | `ESQ_Viga_Arco_MOD4_Top_Esq` | `136.0 × 18.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 28.42 | ~14.1 g | ~0.46 h |
