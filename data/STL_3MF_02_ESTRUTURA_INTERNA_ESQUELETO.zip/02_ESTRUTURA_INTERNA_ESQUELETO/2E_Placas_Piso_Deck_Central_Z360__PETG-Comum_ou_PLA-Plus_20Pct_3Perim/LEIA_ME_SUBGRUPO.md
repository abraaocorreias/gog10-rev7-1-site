# 2E · 7 Placas do Piso Deck Intermediário (Z = 360 mm) — PETG Comum ou PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Placas de piso apoiadas sobre as vigas de balanço entre MOD3 e MOD4
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `6` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `6` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `529.2 cm³` · **`~278 g`** · **`~8.5 h`** (`662 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-196` | `ESQ_Piso_Balanco_Estrutural_Front_Dir` | `138.9 × 134.0 × 5.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 96.19 | ~50.4 g | ~1.53 h |
| `GOG-197` | `ESQ_Piso_Balanco_Estrutural_Front_Esq` | `134.0 × 133.9 × 5.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 79.16 | ~41.5 g | ~1.27 h |
| `GOG-198` | `ESQ_Piso_Balanco_Estrutural_Mid_Dir` | `138.9 × 121.6 × 5.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 87.42 | ~45.9 g | ~1.40 h |
| `GOG-199` | `ESQ_Piso_Balanco_Estrutural_Mid_Esq` | `133.9 × 121.6 × 5.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 84.67 | ~44.5 g | ~1.36 h |
| `GOG-200` | `ESQ_Piso_Balanco_Estrutural_Rear_Dir` | `138.9 × 128.1 × 5.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 92.52 | ~48.5 g | ~1.48 h |
| `GOG-201` | `ESQ_Piso_Balanco_Estrutural_Rear_Esq` | `133.9 × 128.1 × 5.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 89.19 | ~46.8 g | ~1.43 h |
