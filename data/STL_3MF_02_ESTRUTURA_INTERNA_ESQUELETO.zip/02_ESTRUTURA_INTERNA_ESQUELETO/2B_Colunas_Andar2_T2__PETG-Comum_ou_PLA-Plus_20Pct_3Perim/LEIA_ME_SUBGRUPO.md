# 2B · Colunas do 2º Andar (7 colunas · FoS >= 18×) — PETG Comum ou PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Pilares do compartimento médio (MOD3)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `7` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `248.3 cm³` · **`~112 g`** · **`~3.6 h`** (`310 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-145` | `ESQ_Col_BayCheek_T2` | `144.9 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 20.87 | ~11.3 g | ~0.37 h |
| `GOG-149` | `ESQ_Col_BayRear_T2` | `160.9 × 14.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 18.02 | ~10.3 g | ~0.35 h |
| `GOG-153` | `ESQ_Col_Front_Dir_T2` | `161.9 × 24.0 × 14.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 54.40 | ~24.5 g | ~0.76 h |
| `GOG-157` | `ESQ_Col_Front_Esq_T2` | `161.9 × 51.5 × 27.55` | `20% Infill + 3 Perimetros (Sem Suporte)` | 63.20 | ~22.6 g | ~0.71 h |
| `GOG-161` | `ESQ_Col_Mid_Esq_T2` | `160.9 × 19.0 × 9.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 26.62 | ~13.8 g | ~0.45 h |
| `GOG-165` | `ESQ_Col_Rear_EsqExt_T2` | `160.9 × 27.55 × 21.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 33.30 | ~13.6 g | ~0.44 h |
| `GOG-169` | `ESQ_Col_Rear_Esq_T2` | `160.9 × 22.0 × 9.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 31.86 | ~16.0 g | ~0.51 h |
