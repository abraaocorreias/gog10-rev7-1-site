# 2C · Colunas do 3º Andar (6 colunas · FoS >= 22×) — PETG Comum ou PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Pilares inferiores do compartimento do servidor VPS (MOD4)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `6` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `206.2 cm³` · **`~92 g`** · **`~3.0 h`** (`258 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-146` | `ESQ_Col_BayCheek_T3` | `159.6 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 22.98 | ~12.4 g | ~0.41 h |
| `GOG-150` | `ESQ_Col_BayRear_T3` | `159.6 × 14.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 17.88 | ~10.2 g | ~0.34 h |
| `GOG-154` | `ESQ_Col_Front_Dir_T3` | `164.3 × 24.0 × 14.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 55.20 | ~24.8 g | ~0.77 h |
| `GOG-158` | `ESQ_Col_Front_Esq_T3` | `164.3 × 27.55 × 16.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 38.80 | ~16.6 g | ~0.53 h |
| `GOG-162` | `ESQ_Col_Rear_Dir_T3` | `159.6 × 29.88 × 28.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 38.35 | ~14.9 g | ~0.48 h |
| `GOG-166` | `ESQ_Col_Rear_EsqExt_T3` | `159.6 × 27.6 × 22.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 32.98 | ~13.4 g | ~0.44 h |
