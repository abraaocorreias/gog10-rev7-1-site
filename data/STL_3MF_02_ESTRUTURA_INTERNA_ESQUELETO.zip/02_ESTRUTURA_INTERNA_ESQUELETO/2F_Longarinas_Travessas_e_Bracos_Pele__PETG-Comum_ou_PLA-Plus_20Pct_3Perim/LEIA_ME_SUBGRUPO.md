# 2F · Longarinas, Travessas Horizontais e Braços de Ancoragem da Pele — PETG Comum ou PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Anéis horizontais de travamento entre colunas e suportes dos pinos das placas externas
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `56` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `4` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `523.0 cm³` · **`~303 g`** · **`~11.3 h`** (`654 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-136` | `ESQ_Abas_Inserto_Rear_0` | `12.2 × 8.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 0.78 | ~0.6 g | ~0.08 h |
| `GOG-137` | `ESQ_Abas_Inserto_Rear_2` | `12.2 × 8.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 0.78 | ~0.6 g | ~0.08 h |
| `GOG-138` | `ESQ_Abas_Inserto_Rear_4` | `12.2 × 8.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 0.78 | ~0.6 g | ~0.08 h |
| `GOG-139` | `ESQ_Braco_PinoPele_Dir_11` | `29.88 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.21 | ~2.5 g | ~0.11 h |
| `GOG-140` | `ESQ_Braco_PinoPele_Dir_12` | `29.88 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.21 | ~2.5 g | ~0.11 h |
| `GOG-141` | `ESQ_Braco_PinoPele_Dir_13` | `29.88 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.21 | ~2.5 g | ~0.11 h |
| `GOG-142` | `ESQ_Braco_PinoPele_Dir_14` | `29.88 × 18.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.11 | ~2.4 g | ~0.11 h |
| `GOG-143` | `ESQ_Braco_PinoPele_Esq_5` | `28.5 × 27.55 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.20 | ~3.4 g | ~0.14 h |
| `GOG-170` | `ESQ_Longarina_Dir_S1_Deck` | `162.0 × 12.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 22.11 | ~12.3 g | ~0.40 h |
| `GOG-171` | `ESQ_Longarina_Dir_S1_Top` | `162.0 × 12.0 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 13.61 | ~8.4 g | ~0.29 h |
| `GOG-172` | `ESQ_Longarina_Dir_S2_Deck` | `121.6 × 12.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 17.51 | ~9.8 g | ~0.33 h |
| `GOG-173` | `ESQ_Longarina_Dir_S2_Top` | `121.6 × 12.0 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 10.21 | ~6.3 g | ~0.23 h |
| `GOG-174` | `ESQ_Longarina_Dir_S3_Deck` | `135.6 × 12.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 19.53 | ~10.9 g | ~0.36 h |
| `GOG-175` | `ESQ_Longarina_Dir_S3_Top` | `125.4 × 12.0 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 10.53 | ~6.5 g | ~0.23 h |
| `GOG-176` | `ESQ_Longarina_Esq_S1_Deck` | `114.8 × 12.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 16.53 | ~9.3 g | ~0.31 h |
| `GOG-177` | `ESQ_Longarina_Esq_S1_N1` | `114.8 × 12.0 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.89 | ~4.7 g | ~0.18 h |
| `GOG-178` | `ESQ_Longarina_Esq_S1_N2` | `114.8 × 12.0 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 8.27 | ~5.3 g | ~0.20 h |
| `GOG-179` | `ESQ_Longarina_Esq_S1_Top` | `151.8 × 12.0 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 12.75 | ~7.8 g | ~0.27 h |
| `GOG-180` | `ESQ_Longarina_Esq_S1_Z25` | `114.8 × 12.0 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.89 | ~4.7 g | ~0.18 h |
| `GOG-181` | `ESQ_Longarina_Esq_S2_Deck` | `121.6 × 12.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 17.23 | ~9.6 g | ~0.33 h |
| `GOG-182` | `ESQ_Longarina_Esq_S2_N1` | `121.6 × 12.0 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.18 | ~4.8 g | ~0.18 h |
| `GOG-183` | `ESQ_Longarina_Esq_S2_N2` | `121.6 × 12.0 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 8.62 | ~5.5 g | ~0.20 h |
| `GOG-184` | `ESQ_Longarina_Esq_S2_Top` | `121.6 × 36.5 × 27.55` | `20% Infill + 3 Perimetros (Sem Suporte)` | 17.51 | ~6.7 g | ~0.24 h |
| `GOG-185` | `ESQ_Longarina_Esq_S2_Z25` | `121.6 × 27.55 × 21.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 11.30 | ~4.7 g | ~0.18 h |
| `GOG-186` | `ESQ_Longarina_Esq_S3_Deck` | `125.4 × 12.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 16.15 | ~9.0 g | ~0.31 h |
| `GOG-187` | `ESQ_Longarina_Esq_S3_N1` | `114.4 × 12.0 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.73 | ~4.5 g | ~0.17 h |
| `GOG-188` | `ESQ_Longarina_Esq_S3_N2` | `114.4 × 12.0 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 8.08 | ~5.2 g | ~0.19 h |
| `GOG-189` | `ESQ_Longarina_Esq_S3_Top` | `125.4 × 40.5 × 27.55` | `20% Infill + 3 Perimetros (Sem Suporte)` | 18.71 | ~7.0 g | ~0.25 h |
| `GOG-190` | `ESQ_Longarina_Esq_S3_Z25` | `114.4 × 12.0 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.73 | ~4.5 g | ~0.17 h |
| `GOG-208` | `ESQ_Sapata_Junta_Nervura_Front_Base` | `52.35 × 16.5 × 13.95` | `20% Infill + 3 Perimetros (Sem Suporte)` | 12.03 | ~6.2 g | ~0.22 h |
| `GOG-209` | `ESQ_Sapata_Junta_Nervura_Front_FlangeSup` | `52.9 × 36.05 × 16.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 31.41 | ~13.6 g | ~0.44 h |
| `GOG-210` | `ESQ_Sapata_Junta_Nervura_Rear_BackWrap` | `50.0 × 9.45 × 1.95` | `20% Infill + 3 Perimetros (Sem Suporte)` | 0.92 | ~0.9 g | ~0.08 h |
| `GOG-211` | `ESQ_Sapata_Junta_Nervura_Rear_SideCol` | `50.0 × 27.5 × 6.9` | `20% Infill + 3 Perimetros (Sem Suporte)` | 9.13 | ~5.0 g | ~0.19 h |
| `GOG-219` | `ESQ_Suporte_Coletor_Air_Esq` | `44.0 × 7.0 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.85 | ~1.4 g | ~0.08 h |
| `GOG-220` | `ESQ_Suporte_Coletor_Air_Front` | `44.0 × 6.0 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.58 | ~1.3 g | ~0.08 h |
| `GOG-221` | `ESQ_Suporte_Coletor_Air_Rear` | `44.0 × 7.25 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 2.23 | ~1.7 g | ~0.09 h |
| `GOG-222` | `ESQ_Travessa_Front_Deck_Dir` | `123.9 × 12.0 × 11.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 15.60 | ~8.8 g | ~0.30 h |
| `GOG-223` | `ESQ_Travessa_Front_Deck_Esq` | `115.7 × 12.0 × 11.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 15.97 | ~9.0 g | ~0.31 h |
| `GOG-224` | `ESQ_Travessa_Front_N1_Dir` | `123.9 × 11.5 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.50 | ~4.4 g | ~0.17 h |
| `GOG-225` | `ESQ_Travessa_Front_N1_Esq` | `115.7 × 11.5 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.65 | ~4.5 g | ~0.17 h |
| `GOG-226` | `ESQ_Travessa_Front_N2_Dir` | `123.9 × 11.5 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.80 | ~5.1 g | ~0.19 h |
| `GOG-227` | `ESQ_Travessa_Front_N2_Esq` | `115.7 × 11.5 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.98 | ~5.2 g | ~0.19 h |
| `GOG-228` | `ESQ_Travessa_Front_Top_Dir` | `123.9 × 11.5 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 9.82 | ~6.1 g | ~0.22 h |
| `GOG-229` | `ESQ_Travessa_Front_Top_Esq` | `115.7 × 11.5 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 9.31 | ~5.8 g | ~0.21 h |
| `GOG-230` | `ESQ_Travessa_Front_Z25_Dir` | `123.9 × 11.5 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.50 | ~4.4 g | ~0.17 h |
| `GOG-231` | `ESQ_Travessa_Front_Z25_Esq` | `115.7 × 11.5 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.65 | ~4.5 g | ~0.17 h |
| `GOG-232` | `ESQ_Travessa_Rear_Deck_Dir` | `29.8 × 12.0 × 10.8` | `20% Infill + 3 Perimetros (Sem Suporte)` | 3.86 | ~2.4 g | ~0.11 h |
| `GOG-233` | `ESQ_Travessa_Rear_Deck_Esq` | `184.0 × 12.0 × 10.8` | `20% Infill + 3 Perimetros (Sem Suporte)` | 21.25 | ~12.0 g | ~0.39 h |
| `GOG-234` | `ESQ_Travessa_Rear_N1_Dir` | `29.8 × 10.8 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.61 | ~1.2 g | ~0.08 h |
| `GOG-235` | `ESQ_Travessa_Rear_N1_Esq` | `163.8 × 10.8 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 8.85 | ~6.1 g | ~0.22 h |
| `GOG-236` | `ESQ_Travessa_Rear_N2_Dir` | `29.8 × 10.8 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.93 | ~1.3 g | ~0.08 h |
| `GOG-237` | `ESQ_Travessa_Rear_N2_Esq` | `163.8 × 10.8 × 6.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 10.58 | ~6.9 g | ~0.25 h |
| `GOG-238` | `ESQ_Travessa_Rear_Top_Dir` | `91.8 × 10.8 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 6.94 | ~4.4 g | ~0.17 h |
| `GOG-239` | `ESQ_Travessa_Rear_Top_Esq` | `184.0 × 10.8 × 7.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 13.91 | ~8.8 g | ~0.30 h |
| `GOG-240` | `ESQ_Travessa_Rear_Z25_Dir` | `91.8 × 10.8 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.96 | ~3.4 g | ~0.14 h |
| `GOG-241` | `ESQ_Travessa_Rear_Z25_Esq` | `163.8 × 10.8 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 8.85 | ~6.1 g | ~0.22 h |
