# 1A · Sapatas de Apoio no Piso (7 un.) e Placas do Piso Basal (4 un.) — PETG Comum / PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Apoio direto no solo e base estrutural do 1º andar (Z = 0..24,5 mm)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `13` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `6` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `385.7 cm³` · **`~241 g`** · **`~7.7 h`** (`482 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-202` | `ESQ_Piso_Basal_Frontal_Dir_102x165` | `173.0 × 123.9 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 45.93 | ~29.3 g | ~0.91 h |
| `GOG-203` | `ESQ_Piso_Basal_Frontal_Esq_102x165` | `173.0 × 141.9 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 71.02 | ~45.2 g | ~1.38 h |
| `GOG-204` | `ESQ_Piso_Basal_Mid_Dir_102x112` | `142.0 × 123.9 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 56.00 | ~35.8 g | ~1.10 h |
| `GOG-205` | `ESQ_Piso_Basal_Mid_Esq_102x112` | `142.0 × 141.9 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 66.24 | ~42.3 g | ~1.29 h |
| `GOG-206` | `ESQ_Piso_Basal_Traseiro_Dir_102x101` | `123.9 × 101.2 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 43.89 | ~28.3 g | ~0.88 h |
| `GOG-207` | `ESQ_Piso_Basal_Traseiro_Esq_102x101` | `141.9 × 101.2 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 50.13 | ~32.2 g | ~0.99 h |
| `GOG-212` | `ESQ_Sapata_Plinto_Front_Dir` | `21.0 × 20.0 × 20.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 8.40 | ~4.5 g | ~0.17 h |
| `GOG-213` | `ESQ_Sapata_Plinto_Front_Esq` | `21.0 × 20.0 × 20.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 8.40 | ~4.5 g | ~0.17 h |
| `GOG-214` | `ESQ_Sapata_Plinto_Mid_Dir` | `21.0 × 20.0 × 18.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.56 | ~4.0 g | ~0.16 h |
| `GOG-215` | `ESQ_Sapata_Plinto_Mid_Esq` | `21.0 × 20.0 × 19.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.98 | ~4.3 g | ~0.17 h |
| `GOG-216` | `ESQ_Sapata_Plinto_Rear_Core` | `21.0 × 15.0 × 12.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 3.78 | ~2.3 g | ~0.11 h |
| `GOG-217` | `ESQ_Sapata_Plinto_Rear_Esq` | `22.0 × 21.0 × 20.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 9.24 | ~4.8 g | ~0.18 h |
| `GOG-218` | `ESQ_Sapata_Plinto_Rear_EsqExt` | `21.0 × 20.0 × 17.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 7.14 | ~3.8 g | ~0.15 h |
