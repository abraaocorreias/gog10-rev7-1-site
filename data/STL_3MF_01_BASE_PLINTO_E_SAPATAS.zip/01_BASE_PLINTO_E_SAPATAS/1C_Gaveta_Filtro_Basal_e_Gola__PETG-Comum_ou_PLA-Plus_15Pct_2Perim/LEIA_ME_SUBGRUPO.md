# 1C · Cartucho Removível do Filtro de Ar Basal e Gola de Passagem — PETG Comum / PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Gaveta removível para tela antipoeira inferior e colar de cabos
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Preto Fosco (#141619)` (`#141619`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `3` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `12.7 cm³` · **`~6 g`** · **`~0.3 h`** (`16 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-038` | `BAIA_Gola_Plinto_Rear_Cabos` | `26.0 × 19.5 × 8.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 4.46 | ~2.0 g | ~0.10 h |
| `GOG-499` | `MANUT_Cartucho_Filtro_Basal_182mm` | `182.0 × 100.0 × 3.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 5.93 | ~2.9 g | ~0.13 h |
| `GOG-500` | `MANUT_Cartucho_Filtro_Basal_Admissao` | `96.0 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.31 | ~1.1 g | ~0.08 h |
