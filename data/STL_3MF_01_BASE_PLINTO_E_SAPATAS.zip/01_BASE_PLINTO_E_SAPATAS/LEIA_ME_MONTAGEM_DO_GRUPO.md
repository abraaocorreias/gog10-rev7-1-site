# 01 · Base, Plinto Flutuante e Sapatas de Apoio (PETG Comum / PLA+)

**Objetivo construtivo**: Base estrutural no piso (Z = 0 a 24,5 mm), 7 sapatas das colunas, carenagem inferior recuada (fresta 13 mm) e gaveta do filtro basal — 100% em PETG Comum ou PLA+.

**Como montar este grupo**: Passo 1: Posicione as 7 sapatas (1A) no piso e apoie sobre elas as 4 placas do Piso Basal (1A) com insertos M3. Encaixe as placas externas do plinto (1B) e deslize o cartucho do filtro basal (1C).

| Subpasta | Material | Fatiamento | Peças | Bandejas 202×202 | Peso Leve | Tempo Estimado |
|---|---|---|---:|---:|---:|---:|
| `1A_Sapatas_e_Piso_Basal__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 13 | 6 | **~241 g** | **~7.7 h** |
| `1B_Placas_Externas_Plinto__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 13 | 1 | **~34 g** | **~1.6 h** |
| `1C_Gaveta_Filtro_Basal_e_Gola__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 3 | 1 | **~6 g** | **~0.3 h** |
