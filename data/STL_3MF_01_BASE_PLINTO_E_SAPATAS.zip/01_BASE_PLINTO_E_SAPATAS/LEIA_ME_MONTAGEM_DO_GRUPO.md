# 01 · Base, Plinto Flutuante e Sapatas de Apoio

**Objetivo construtivo**: Base estrutural no piso (Z = 0 a 24,5 mm), 7 sapatas que recebem as colunas do 1º andar, carenagem inferior recuada (fresta 13 mm) e gaveta do filtro de ar basal.

**Como montar este grupo**: Passo 1 da montagem: Posicione as 7 sapatas (1A) no piso, apoie sobre elas as 4 placas do Piso Basal (1A) aparafusando com insertos M3. Encaixe por baixo o labirinto óptico preto (1C) e as placas externas brancas do plinto (1B). Deslize o cartucho do filtro basal (1C) na janela central.

**Vistas de referência no site (`https://abraaocorreias.github.io/gog10-rev7-1-site/`)**: `V01, V03, V10, V15, V19, V21, V22, V27`

## Subgrupos de Peças, Materiais e Cores:

| Subpasta | Material | Cor | Peças | Bandejas 202×202 | Volume | Peso Estimado |
|---|---|---|---:|---:|---:|---:|
| `1A_Sapatas_e_Piso_Basal__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 13 | 6 | 385.7 cm³ | **~209 g** |
| `1B_Placas_Externas_Plinto__ASA-PETG_BrancoOsso_ECEAE4` | ASA / PETG / PLA+ Estético | Branco-Osso / Cinza-Pedra (#ECEAE4) | 13 | 1 | 87.8 cm³ | **~46 g** |
| `1C_Labirinto_Optico_e_Gaveta_Filtro_Basal__PETG_Preto_141619` | PETG / ASA Opaco (Sem Fibra) | Preto Fosco Profundo (#141619) | 14 | 2 | 28.7 cm³ | **~15 g** |
