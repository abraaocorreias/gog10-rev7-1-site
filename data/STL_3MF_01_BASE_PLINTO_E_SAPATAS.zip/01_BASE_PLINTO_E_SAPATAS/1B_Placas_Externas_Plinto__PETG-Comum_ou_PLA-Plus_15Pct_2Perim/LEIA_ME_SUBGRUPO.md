# 1B · Placas Externas do Plinto Recuado e Fresta 13 mm — PETG Comum / PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Acabamento perimetral inferior com sombra flutuante de 13 mm
- **Material Recomendado**: `PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `13` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `87.8 cm³` · **`~34 g`** · **`~1.6 h`** (`109 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-773` | `PELE_F6_Plinto_Fresta13mm_F_Dir` | `73.6 × 14.0 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 6.02 | ~2.4 g | ~0.11 h |
| `GOG-774` | `PELE_F6_Plinto_Fresta13mm_F_Dir_Seg2` | `120.6 × 16.0 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 11.29 | ~4.3 g | ~0.17 h |
| `GOG-775` | `PELE_F6_Plinto_Fresta13mm_F_Esq` | `96.6 × 14.0 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 8.17 | ~3.3 g | ~0.14 h |
| `GOG-776` | `PELE_F6_Plinto_Fresta13mm_F_Esq_Seg2` | `120.6 × 16.0 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 11.29 | ~4.3 g | ~0.17 h |
| `GOG-777` | `PELE_F6_Plinto_Fresta13mm_M_Dir` | `58.1 × 16.0 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 6.21 | ~2.4 g | ~0.11 h |
| `GOG-778` | `PELE_F6_Plinto_Fresta13mm_M_Esq` | `75.1 × 16.0 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 8.38 | ~3.3 g | ~0.14 h |
| `GOG-779` | `PELE_F6_Plinto_Fresta13mm_R_Dir` | `150.3 × 29.8 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 16.35 | ~5.4 g | ~0.20 h |
| `GOG-780` | `PELE_F6_Plinto_Fresta13mm_R_Dir_Seg2` | `51.6 × 12.6 × 10.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.87 | ~1.3 g | ~0.08 h |
| `GOG-781` | `PELE_F6_Plinto_Fresta13mm_R_Esq` | `16.0 × 15.1 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.31 | ~1.1 g | ~0.08 h |
| `GOG-782` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg2` | `61.6 × 16.0 × 12.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 6.31 | ~2.5 g | ~0.11 h |
| `GOG-783` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg3` | `16.0 × 13.6 × 1.2` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.26 | ~0.3 g | ~0.08 h |
| `GOG-784` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg4` | `16.0 × 13.6 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.39 | ~0.3 g | ~0.08 h |
| `GOG-785` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg5` | `96.6 × 12.6 × 10.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 7.95 | ~3.4 g | ~0.14 h |
