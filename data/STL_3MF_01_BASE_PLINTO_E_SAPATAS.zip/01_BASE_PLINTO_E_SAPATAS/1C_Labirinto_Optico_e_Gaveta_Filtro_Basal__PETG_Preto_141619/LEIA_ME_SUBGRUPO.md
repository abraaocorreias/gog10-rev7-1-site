# 1C · Chicanes do Labirinto Óptico Basal, Gola de Cabos e Cartucho do Filtro

- **Propósito / Função**: Bloqueio de luz na entrada de ar basal e gaveta removível do filtro inferior
- **Material Recomendado**: `PETG / ASA Opaco (Sem Fibra)`
- **Cor Indicada**: `Preto Fosco Profundo (#141619)` (`#141619`)
- **Quantidade de Peças Imprimíveis**: `14` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `28.7 cm³` · **`~15 g`** (`36 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-038` | `BAIA_Gola_Plinto_Rear_Cabos` | `26.0 × 19.5 × 8.8` | 4.46 | ~2.4 g |
| `GOG-039` | `BAIA_Labirinto_Plinto_Dir_Front` | `125.3 × 12.9 × 2.0` | 2.62 | ~1.4 g |
| `GOG-040` | `BAIA_Labirinto_Plinto_Dir_Rear` | `37.0 × 12.9 × 2.0` | 0.77 | ~0.4 g |
| `GOG-041` | `BAIA_Labirinto_Plinto_Esq_Front` | `148.8 × 12.9 × 2.0` | 3.03 | ~1.6 g |
| `GOG-042` | `BAIA_Labirinto_Plinto_Esq_Mid` | `76.8 × 12.9 × 2.0` | 1.32 | ~0.7 g |
| `GOG-043` | `BAIA_Labirinto_Plinto_Esq_Mid_Seg2` | `48.8 × 12.9 × 2.0` | 0.91 | ~0.5 g |
| `GOG-044` | `BAIA_Labirinto_Plinto_Esq_RearGap` | `12.9 × 12.8 × 2.0` | 0.33 | ~0.2 g |
| `GOG-045` | `BAIA_Labirinto_Plinto_Front_Dir` | `91.7 × 12.9 × 1.8` | 1.69 | ~0.9 g |
| `GOG-046` | `BAIA_Labirinto_Plinto_Front_Esq` | `89.7 × 12.9 × 1.8` | 2.01 | ~1.1 g |
| `GOG-047` | `BAIA_Labirinto_Plinto_Rear_Dir` | `69.7 × 12.9 × 1.8` | 1.22 | ~0.7 g |
| `GOG-048` | `BAIA_Labirinto_Plinto_Rear_Dir_Seg2` | `29.8 × 12.9 × 1.8` | 0.59 | ~0.3 g |
| `GOG-049` | `BAIA_Labirinto_Plinto_Rear_Esq` | `89.7 × 12.9 × 1.8` | 1.52 | ~0.8 g |
| `GOG-499` | `MANUT_Cartucho_Filtro_Basal_182mm` | `182.0 × 100.0 × 3.6` | 5.93 | ~3.2 g |
| `GOG-500` | `MANUT_Cartucho_Filtro_Basal_Admissao` | `96.0 × 56.0 × 4.0` | 2.31 | ~1.2 g |
