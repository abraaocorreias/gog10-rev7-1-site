# 1A · Sapatas de Apoio no Piso (7 un.) e Placas do Piso Basal (4 un.)

- **Propósito / Função**: Apoio direto no solo e base estrutural do 1º andar (Z = 0..24,5 mm)
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `13` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `6` bandeja(s)
- **Volume Sólido / Peso Estimado**: `385.7 cm³` · **`~209 g`** (`497 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-202` | `ESQ_Piso_Basal_Frontal_Dir_102x165` | `173.0 × 123.9 × 3.5` | 45.93 | ~24.9 g |
| `GOG-203` | `ESQ_Piso_Basal_Frontal_Esq_102x165` | `173.0 × 141.9 × 3.5` | 71.02 | ~38.5 g |
| `GOG-204` | `ESQ_Piso_Basal_Mid_Dir_102x112` | `142.0 × 123.9 × 3.5` | 56.00 | ~30.3 g |
| `GOG-205` | `ESQ_Piso_Basal_Mid_Esq_102x112` | `142.0 × 141.9 × 3.5` | 66.24 | ~35.9 g |
| `GOG-206` | `ESQ_Piso_Basal_Traseiro_Dir_102x101` | `123.9 × 101.2 × 3.5` | 43.89 | ~23.8 g |
| `GOG-207` | `ESQ_Piso_Basal_Traseiro_Esq_102x101` | `141.9 × 101.2 × 3.5` | 50.13 | ~27.2 g |
| `GOG-212` | `ESQ_Sapata_Plinto_Front_Dir` | `21.0 × 20.0 × 20.0` | 8.40 | ~4.6 g |
| `GOG-213` | `ESQ_Sapata_Plinto_Front_Esq` | `21.0 × 20.0 × 20.0` | 8.40 | ~4.6 g |
| `GOG-214` | `ESQ_Sapata_Plinto_Mid_Dir` | `21.0 × 20.0 × 18.0` | 7.56 | ~4.1 g |
| `GOG-215` | `ESQ_Sapata_Plinto_Mid_Esq` | `21.0 × 20.0 × 19.0` | 7.98 | ~4.3 g |
| `GOG-216` | `ESQ_Sapata_Plinto_Rear_Core` | `21.0 × 15.0 × 12.0` | 3.78 | ~2.0 g |
| `GOG-217` | `ESQ_Sapata_Plinto_Rear_Esq` | `22.0 × 21.0 × 20.0` | 9.24 | ~5.0 g |
| `GOG-218` | `ESQ_Sapata_Plinto_Rear_EsqExt` | `21.0 × 20.0 × 17.0` | 7.14 | ~3.9 g |
