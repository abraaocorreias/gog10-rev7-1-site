# 1B · Placas Externas do Plinto Recuado e Fresta de Admissão 13 mm

- **Propósito / Função**: Acabamento perimetral inferior com sombra flutuante de 13 mm
- **Material Recomendado**: `ASA / PETG / PLA+ Estético`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Quantidade de Peças Imprimíveis**: `13` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Estimado**: `87.8 cm³` · **`~46 g`** (`109 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-773` | `PELE_F6_Plinto_Fresta13mm_F_Dir` | `73.6 × 14.0 × 12.6` | 6.02 | ~3.1 g |
| `GOG-774` | `PELE_F6_Plinto_Fresta13mm_F_Dir_Seg2` | `120.6 × 16.0 × 12.6` | 11.29 | ~5.9 g |
| `GOG-775` | `PELE_F6_Plinto_Fresta13mm_F_Esq` | `96.6 × 14.0 × 12.6` | 8.17 | ~4.3 g |
| `GOG-776` | `PELE_F6_Plinto_Fresta13mm_F_Esq_Seg2` | `120.6 × 16.0 × 12.6` | 11.29 | ~5.9 g |
| `GOG-777` | `PELE_F6_Plinto_Fresta13mm_M_Dir` | `58.1 × 16.0 × 12.6` | 6.21 | ~3.2 g |
| `GOG-778` | `PELE_F6_Plinto_Fresta13mm_M_Esq` | `75.1 × 16.0 × 12.6` | 8.38 | ~4.4 g |
| `GOG-779` | `PELE_F6_Plinto_Fresta13mm_R_Dir` | `150.3 × 29.8 × 12.6` | 16.35 | ~8.5 g |
| `GOG-780` | `PELE_F6_Plinto_Fresta13mm_R_Dir_Seg2` | `51.6 × 12.6 × 10.0` | 2.87 | ~1.5 g |
| `GOG-781` | `PELE_F6_Plinto_Fresta13mm_R_Esq` | `16.0 × 15.1 × 12.6` | 2.31 | ~1.2 g |
| `GOG-782` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg2` | `61.6 × 16.0 × 12.6` | 6.31 | ~3.3 g |
| `GOG-783` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg3` | `16.0 × 13.6 × 1.2` | 0.26 | ~0.1 g |
| `GOG-784` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg4` | `16.0 × 13.6 × 1.8` | 0.39 | ~0.2 g |
| `GOG-785` | `PELE_F6_Plinto_Fresta13mm_R_Esq_Seg5` | `96.6 × 12.6 × 10.0` | 7.95 | ~4.1 g |
