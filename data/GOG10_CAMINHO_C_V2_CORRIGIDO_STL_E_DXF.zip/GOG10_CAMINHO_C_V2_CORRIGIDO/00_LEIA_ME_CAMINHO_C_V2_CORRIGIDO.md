# GABINETE GOG10 · CAMINHO C v2 (CORRIGIDO E AUDITADO)

- **Impressão 3D**: apenas **`14` peças funcionais** em **PETG Comum Preto** (`241 g` · `8.1 h` · `3` bandejas `202×202 mm` · `14/14` STLs com `degen=0, nm=0, ilha=1`).
- **Corte a Laser (`3,0 mm`)**: `10` chapas inteiriças compatíveis com **MDF `3 mm` Laminado 2 Faces** (`~3,2 kg` de chapa, `~6,3 kg` total montado, zero pintura) OU **PSAI `3 mm` Fosco** (`~4,5 kg` de chapa, `~7,6 kg` total montado), com desconto exato de `3 mm`, aberturas circulares `Ø 76 mm` + furos `71,5 mm` para `FAN1/FAN2`, `8` furos exatos `H1..H21` da `LA-L161P` direto no laser e `4` fendas U reais do `MR30G` em `Z = 68 mm`.
- **Placa de Alumínio (`2,0 mm`)**: `220 × 150 mm` (`LASER-11`) para dissipação direta da Fonte Lenovo `135 W` (elimina 100% do `PC-ABS FR`).
- **Ferragens comerciais**: `1` ou `2` pares de corrediça telescópica metálica mini `250 mm` (`27 mm` largura) + `8` espaçadores de latão/nylon `M2.5 × 14 mm`.
