# 5C · Selos Deslizantes das 4 Antenas e Tampas das Fendas U (30 Peças) — PETG Comum ou PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Vedação que acompanha o curso de +125 mm das 4 antenas do MR30G
- **Material Recomendado**: `PETG Comum ou PLA+ Preto Sem Fibra (15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Preto Fosco Profundo (#141619)` (`#141619`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `30` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `105.8 cm³` · **`~47 g`** · **`~3.3 h`** (`132 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-030` | `BAIA_GavetaColarFront_Preto` | `165.4 × 42.8 × 10.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 70.79 | ~23.8 g | ~0.75 h |
| `GOG-031` | `BAIA_GavetaFloorCover_Mid` | `59.0 × 41.7 × 3.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 7.38 | ~4.3 g | ~0.17 h |
| `GOG-032` | `BAIA_GavetaFloorCover_SideL` | `41.7 × 5.5 × 3.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.69 | ~0.5 g | ~0.08 h |
| `GOG-033` | `BAIA_GavetaFloorCover_SideR` | `41.7 × 6.0 × 3.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.75 | ~0.6 g | ~0.08 h |
| `GOG-034` | `BAIA_GavetaFloorCover_WingL` | `27.3 × 25.8 × 3.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.88 | ~0.5 g | ~0.08 h |
| `GOG-035` | `BAIA_GavetaFloorCover_WingR` | `30.2 × 25.8 × 3.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.11 | ~0.7 g | ~0.08 h |
| `GOG-036` | `BAIA_GavetaSelo_Pocket_Front` | `14.05 × 9.7 × 4.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.60 | ~0.4 g | ~0.08 h |
| `GOG-037` | `BAIA_GavetaSelo_Pocket_Rear` | `14.05 × 9.7 × 4.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.58 | ~0.4 g | ~0.08 h |
| `GOG-079` | `BAIA_Selo_AtrasAntenas_SobFendas_Front` | `70.2 × 12.0 × 3.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.56 | ~1.6 g | ~0.09 h |
| `GOG-080` | `BAIA_Selo_AtrasAntenas_SobFendas_Rear` | `103.7 × 12.0 × 3.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 3.80 | ~2.4 g | ~0.11 h |
| `GOG-081` | `BAIA_Selo_Corredor_Fixo_Front` | `135.8 × 5.4 × 2.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.59 | ~1.3 g | ~0.08 h |
| `GOG-082` | `BAIA_Selo_Corredor_Fixo_Rear` | `135.8 × 8.25 × 6.5` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.42 | ~0.8 g | ~0.08 h |
| `GOG-083` | `BAIA_Selo_Corredor_Movel_Rear_Left` | `12.0 × 3.9 × 2.65` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.12 | ~0.1 g | ~0.08 h |
| `GOG-084` | `BAIA_Selo_Corredor_Movel_Rear_Left_Labio` | `12.0 × 2.8 × 2.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.08 | ~0.1 g | ~0.08 h |
| `GOG-085` | `BAIA_Selo_Corredor_Movel_Rear_Left_Suporte` | `37.7 × 4.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.60 | ~0.5 g | ~0.08 h |
| `GOG-086` | `BAIA_Selo_Corredor_Movel_Rear_Right` | `12.0 × 3.9 × 2.65` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.12 | ~0.1 g | ~0.08 h |
| `GOG-087` | `BAIA_Selo_Corredor_Movel_Rear_Right_Labio` | `12.0 × 2.8 × 2.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.08 | ~0.1 g | ~0.08 h |
| `GOG-088` | `BAIA_Selo_Corredor_Movel_Rear_Right_Suporte` | `37.7 × 4.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.60 | ~0.5 g | ~0.08 h |
| `GOG-089` | `BAIA_Selo_Corredor_Movel_Side_Left` | `25.1 × 15.5 × 2.65` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.03 | ~0.7 g | ~0.08 h |
| `GOG-090` | `BAIA_Selo_Corredor_Movel_Side_Left_Labio` | `15.5 × 2.8 × 2.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.10 | ~0.1 g | ~0.08 h |
| `GOG-091` | `BAIA_Selo_Corredor_Movel_Side_Right` | `25.1 × 15.5 × 2.65` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.03 | ~0.7 g | ~0.08 h |
| `GOG-092` | `BAIA_Selo_Corredor_Movel_Side_Right_Labio` | `15.5 × 2.8 × 2.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.10 | ~0.1 g | ~0.08 h |
| `GOG-093` | `BAIA_Selo_EntreFendas_Band1` | `53.8 × 7.9 × 3.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.84 | ~0.6 g | ~0.08 h |
| `GOG-094` | `BAIA_Selo_EntreFendas_Band2` | `53.8 × 17.8 × 3.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.95 | ~0.6 g | ~0.08 h |
| `GOG-095` | `BAIA_Selo_EntreFendas_Band3` | `66.8 × 53.8 × 3.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.68 | ~0.9 g | ~0.08 h |
| `GOG-096` | `BAIA_Selo_EntreFendas_Band4` | `53.8 × 17.8 × 3.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.89 | ~0.5 g | ~0.08 h |
| `GOG-097` | `BAIA_Selo_EntreFendas_Band5` | `53.8 × 11.0 × 3.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.03 | ~0.7 g | ~0.08 h |
| `GOG-102` | `BAIA_Selo_Pocket_Front` | `10.0 × 6.2 × 4.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.26 | ~0.2 g | ~0.08 h |
| `GOG-103` | `BAIA_Selo_Pocket_Rear` | `10.0 × 6.2 × 4.2` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.26 | ~0.2 g | ~0.08 h |
| `GOG-104` | `BAIA_Selo_Transicao_Piso_Corner` | `62.3 × 46.6 × 1.5` | `15% Infill + 2 Perimetros (Sem Suporte)` | 3.87 | ~3.4 g | ~0.14 h |
