# 5C · Plenums Chevron 45° (Admissão ColF T1..T4) e Placas do Labirinto Óptico do Topo

- **Propósito / Função**: Aletas oblíquas 45° bloqueadoras de visão interna na fachada frontal e no teto
- **Material Recomendado**: `PETG / ASA Opaco (Sem Fibra)`
- **Cor Indicada**: `Preto Fosco Profundo (#141619)` (`#141619`)
- **Quantidade de Peças Imprimíveis**: `20` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `9` bandeja(s)
- **Volume Sólido / Peso Estimado**: `643.5 cm³` · **`~343 g`** (`817 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-050` | `BAIA_Labirinto_Topo_Plat_F_Dir` | `155.8 × 113.8 × 3.6` | 61.20 | ~32.6 g |
| `GOG-051` | `BAIA_Labirinto_Topo_Plat_F_Esq` | `155.8 × 147.8 × 3.6` | 61.31 | ~32.7 g |
| `GOG-052` | `BAIA_Labirinto_Topo_Plat_M_Dir` | `118.6 × 113.8 × 3.6` | 45.80 | ~24.4 g |
| `GOG-053` | `BAIA_Labirinto_Topo_Plat_M_Esq` | `147.8 × 118.6 × 3.6` | 51.93 | ~27.7 g |
| `GOG-054` | `BAIA_Labirinto_Topo_Plat_R_Dir` | `125.6 × 113.8 × 3.6` | 49.64 | ~26.5 g |
| `GOG-055` | `BAIA_Labirinto_Topo_Plat_R_Esq` | `147.8 × 125.6 × 3.6` | 59.17 | ~31.6 g |
| `GOG-065` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T1_ColF` | `137.9 × 108.0 × 9.4` | 87.44 | ~46.6 g |
| `GOG-066` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T1_ColF_BracoBot` | `2.05 × 104.0 × 3.95` | 0.84 | ~0.4 g |
| `GOG-067` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T1_ColF_BracoTop` | `1.4 × 104.0 × 3.95` | 0.45 | ~0.2 g |
| `GOG-068` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T2_ColF` | `149.0 × 108.0 × 9.4` | 90.72 | ~48.4 g |
| `GOG-069` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T2_ColF_BracoBot` | `1.4 × 104.0 × 3.95` | 0.45 | ~0.2 g |
| `GOG-070` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T2_ColF_BracoTop` | `1.4 × 104.0 × 3.95` | 0.45 | ~0.2 g |
| `GOG-071` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF` | `169.0 × 108.0 × 9.4` | 106.72 | ~56.9 g |
| `GOG-072` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF_BracoBot` | `2.05 × 104.0 × 3.95` | 0.43 | ~0.2 g |
| `GOG-073` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF_BracoTop` | `1.4 × 14.8 × 3.95` | 0.06 | ~0.0 g |
| `GOG-074` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF_BracoTop_Seg2` | `1.4 × 80.8 × 3.95` | 0.35 | ~0.2 g |
| `GOG-075` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF` | `37.9 × 108.0 × 9.4` | 25.24 | ~13.5 g |
| `GOG-076` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF_BracoBot` | `1.4 × 14.8 × 3.95` | 0.06 | ~0.0 g |
| `GOG-077` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF_BracoBot_Seg2` | `1.4 × 80.8 × 3.95` | 0.35 | ~0.2 g |
| `GOG-078` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF_BracoTop` | `2.05 × 104.0 × 3.95` | 0.84 | ~0.4 g |
