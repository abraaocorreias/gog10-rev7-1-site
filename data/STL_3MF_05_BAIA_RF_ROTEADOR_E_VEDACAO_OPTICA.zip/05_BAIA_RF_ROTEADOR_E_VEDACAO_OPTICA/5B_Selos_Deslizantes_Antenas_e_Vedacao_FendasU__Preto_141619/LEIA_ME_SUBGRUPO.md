# 5B · Selos Labirinto das 4 Antenas e Coberturas Móveis do Piso da Gaveta MOD1

- **Propósito / Função**: Vedação óptica que acompanha o curso de +125 mm das antenas sem abrir frestas visíveis
- **Material Recomendado**: `PETG / ASA Opaco (Sem Fibra)`
- **Cor Indicada**: `Preto Fosco Profundo (#141619)` (`#141619`)
- **Quantidade de Peças Imprimíveis**: `30` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `105.8 cm³` · **`~56 g`** (`134 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-030` | `BAIA_GavetaColarFront_Preto` | `165.4 × 42.8 × 10.0` | 70.79 | ~37.8 g |
| `GOG-031` | `BAIA_GavetaFloorCover_Mid` | `59.0 × 41.7 × 3.0` | 7.38 | ~3.9 g |
| `GOG-032` | `BAIA_GavetaFloorCover_SideL` | `41.7 × 5.5 × 3.0` | 0.69 | ~0.4 g |
| `GOG-033` | `BAIA_GavetaFloorCover_SideR` | `41.7 × 6.0 × 3.0` | 0.75 | ~0.4 g |
| `GOG-034` | `BAIA_GavetaFloorCover_WingL` | `27.3 × 25.8 × 3.0` | 0.88 | ~0.5 g |
| `GOG-035` | `BAIA_GavetaFloorCover_WingR` | `30.2 × 25.8 × 3.0` | 1.11 | ~0.6 g |
| `GOG-036` | `BAIA_GavetaSelo_Pocket_Front` | `14.05 × 9.7 × 4.4` | 0.60 | ~0.3 g |
| `GOG-037` | `BAIA_GavetaSelo_Pocket_Rear` | `14.05 × 9.7 × 4.3` | 0.58 | ~0.3 g |
| `GOG-079` | `BAIA_Selo_AtrasAntenas_SobFendas_Front` | `70.2 × 12.0 × 3.1` | 2.56 | ~1.4 g |
| `GOG-080` | `BAIA_Selo_AtrasAntenas_SobFendas_Rear` | `103.7 × 12.0 × 3.1` | 3.80 | ~2.0 g |
| `GOG-081` | `BAIA_Selo_Corredor_Fixo_Front` | `135.8 × 5.4 × 2.3` | 1.59 | ~0.8 g |
| `GOG-082` | `BAIA_Selo_Corredor_Fixo_Rear` | `135.8 × 8.25 × 6.5` | 1.42 | ~0.8 g |
| `GOG-083` | `BAIA_Selo_Corredor_Movel_Rear_Left` | `12.0 × 3.9 × 2.65` | 0.12 | ~0.1 g |
| `GOG-084` | `BAIA_Selo_Corredor_Movel_Rear_Left_Labio` | `12.0 × 2.8 × 2.3` | 0.08 | ~0.0 g |
| `GOG-085` | `BAIA_Selo_Corredor_Movel_Rear_Left_Suporte` | `37.7 × 4.0 × 4.0` | 0.60 | ~0.3 g |
| `GOG-086` | `BAIA_Selo_Corredor_Movel_Rear_Right` | `12.0 × 3.9 × 2.65` | 0.12 | ~0.1 g |
| `GOG-087` | `BAIA_Selo_Corredor_Movel_Rear_Right_Labio` | `12.0 × 2.8 × 2.3` | 0.08 | ~0.0 g |
| `GOG-088` | `BAIA_Selo_Corredor_Movel_Rear_Right_Suporte` | `37.7 × 4.0 × 4.0` | 0.60 | ~0.3 g |
| `GOG-089` | `BAIA_Selo_Corredor_Movel_Side_Left` | `25.1 × 15.5 × 2.65` | 1.03 | ~0.5 g |
| `GOG-090` | `BAIA_Selo_Corredor_Movel_Side_Left_Labio` | `15.5 × 2.8 × 2.3` | 0.10 | ~0.1 g |
| `GOG-091` | `BAIA_Selo_Corredor_Movel_Side_Right` | `25.1 × 15.5 × 2.65` | 1.03 | ~0.5 g |
| `GOG-092` | `BAIA_Selo_Corredor_Movel_Side_Right_Labio` | `15.5 × 2.8 × 2.3` | 0.10 | ~0.1 g |
| `GOG-093` | `BAIA_Selo_EntreFendas_Band1` | `53.8 × 7.9 × 3.1` | 0.84 | ~0.5 g |
| `GOG-094` | `BAIA_Selo_EntreFendas_Band2` | `53.8 × 17.8 × 3.1` | 0.95 | ~0.5 g |
| `GOG-095` | `BAIA_Selo_EntreFendas_Band3` | `66.8 × 53.8 × 3.1` | 1.68 | ~0.9 g |
| `GOG-096` | `BAIA_Selo_EntreFendas_Band4` | `53.8 × 17.8 × 3.1` | 0.89 | ~0.5 g |
| `GOG-097` | `BAIA_Selo_EntreFendas_Band5` | `53.8 × 11.0 × 3.1` | 1.03 | ~0.5 g |
| `GOG-102` | `BAIA_Selo_Pocket_Front` | `10.0 × 6.2 × 4.3` | 0.26 | ~0.1 g |
| `GOG-103` | `BAIA_Selo_Pocket_Rear` | `10.0 × 6.2 × 4.2` | 0.26 | ~0.1 g |
| `GOG-104` | `BAIA_Selo_Transicao_Piso_Corner` | `62.3 × 46.6 × 1.5` | 3.87 | ~2.1 g |
