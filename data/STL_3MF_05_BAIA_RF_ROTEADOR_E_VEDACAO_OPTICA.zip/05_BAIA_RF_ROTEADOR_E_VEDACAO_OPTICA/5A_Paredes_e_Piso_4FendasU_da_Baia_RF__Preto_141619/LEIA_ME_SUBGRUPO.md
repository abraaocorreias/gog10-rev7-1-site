# 5A · Piso Preto com 4 Fendas U, Paredes Internas, Teto e Baffles da Baía do Roteador

- **Propósito / Função**: Cavidade escura livre de metais/carbono ao redor das 4 antenas do MR30G
- **Material Recomendado**: `PETG / ASA Opaco (Sem Fibra)`
- **Cor Indicada**: `Preto Fosco Profundo (#141619)` (`#141619`)
- **Quantidade de Peças Imprimíveis**: `26` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `5` bandeja(s)
- **Volume Sólido / Peso Estimado**: `612.7 cm³` · **`~321 g`** (`766 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-022` | `BAIA_BafflePreto_FundoInferior_Front` | `43.5 × 40.5 × 8.0` | 12.59 | ~6.6 g |
| `GOG-023` | `BAIA_BafflePreto_FundoInferior_Rear` | `43.5 × 32.3 × 8.0` | 6.49 | ~3.4 g |
| `GOG-024` | `BAIA_CheekFrente_Preto_Inf` | `155.5 × 63.8 × 2.0` | 18.56 | ~9.7 g |
| `GOG-025` | `BAIA_CheekFrente_Preto_Sup` | `160.3 × 59.6 × 2.0` | 18.58 | ~9.8 g |
| `GOG-026` | `BAIA_FundoPreto_BayWall_Corner_Inf` | `132.5 × 58.0 × 4.0` | 30.08 | ~15.8 g |
| `GOG-027` | `BAIA_FundoPreto_BayWall_Corner_Sup` | `160.3 × 58.0 × 4.0` | 36.43 | ~19.1 g |
| `GOG-028` | `BAIA_FundoPreto_BayWall_Inf` | `181.1 × 132.5 × 4.0` | 95.13 | ~49.9 g |
| `GOG-029` | `BAIA_FundoPreto_BayWall_Sup` | `181.1 × 158.3 × 4.0` | 113.64 | ~59.7 g |
| `GOG-056` | `BAIA_PisoPreto_BaiaBase_Behind` | `19.8 × 3.8 × 3.3` | 0.25 | ~0.1 g |
| `GOG-057` | `BAIA_PisoPreto_BaiaBase_Escuro_F` | `34.0 × 15.8 × 3.35` | 1.80 | ~0.9 g |
| `GOG-058` | `BAIA_PisoPreto_BaiaBase_Escuro_R` | `170.5 × 15.8 × 3.65` | 9.83 | ~5.2 g |
| `GOG-059` | `BAIA_PisoPreto_Corner_Podio_Z21_68` | `63.8 × 46.9 × 27.8` | 67.16 | ~35.3 g |
| `GOG-060` | `BAIA_PisoPreto_Corner_Z68_74` | `63.8 × 26.1 × 6.0` | 9.99 | ~5.2 g |
| `GOG-061` | `BAIA_PisoPreto_Fixo_4FendasU` | `177.5 × 63.8 × 6.0` | 51.70 | ~27.1 g |
| `GOG-062` | `BAIA_PisoPreto_FrontStub_BaseLower` | `59.2 × 35.0 × 17.3` | 35.85 | ~18.8 g |
| `GOG-063` | `BAIA_PisoPreto_FrontStub_Podio_Z21_68` | `59.6 × 35.0 × 25.95` | 54.13 | ~28.4 g |
| `GOG-064` | `BAIA_PisoPreto_FrontStub_Z68_74` | `63.8 × 33.8 × 6.0` | 12.94 | ~6.8 g |
| `GOG-098` | `BAIA_Selo_Junta_Z286_Balanco` | `177.5 × 2.4 × 1.8` | 0.49 | ~0.3 g |
| `GOG-099` | `BAIA_Selo_Junta_Z286_Corner_Dir` | `60.0 × 2.5 × 1.8` | 0.27 | ~0.1 g |
| `GOG-100` | `BAIA_Selo_Junta_Z286_Rear_Dir` | `103.8 × 2.8 × 1.5` | 0.26 | ~0.1 g |
| `GOG-101` | `BAIA_Selo_Junta_Z286_Rear_Esq` | `178.9 × 2.8 × 1.5` | 0.75 | ~0.4 g |
| `GOG-105` | `BAIA_TetoPreto_Corner_Z286` | `59.5 × 57.6 × 1.6` | 0.84 | ~0.4 g |
| `GOG-106` | `BAIA_TetoPreto_PisoBalanco_178mm` | `177.5 × 2.6 × 2.4` | 1.11 | ~0.6 g |
| `GOG-107` | `BAIA_TetoPreto_SoffitDeck_Front` | `56.1 × 39.6 × 3.8` | 8.44 | ~4.4 g |
| `GOG-108` | `BAIA_TetoPreto_SoffitDeck_Front_Seg2` | `74.8 × 39.6 × 3.8` | 11.26 | ~5.9 g |
| `GOG-109` | `BAIA_TetoPreto_SoffitDeck_Rear` | `93.6 × 39.6 × 4.0` | 14.13 | ~7.4 g |
