# 5B · [Material Técnico Térmico · 4 Peças] Paredes BayWall Encostadas no MOD3 (Fonte 135 W) — PC-ABS FR UL94 V-0

- **Propósito / Função**: As 4 placas de fundo da baía que fazem parede direta com o compartimento quente MOD3
- **Material Recomendado**: `PC-ABS FR / PC-FR UL94 V-0 (Barreira Térmica entre Fonte 135 W e Roteador)`
- **Cor Indicada**: `Preto Técnico FR (#141619)` (`#141619`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `4` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `275.3 cm³` · **`~155 g`** · **`~7.5 h`** (`325 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-026` | `BAIA_FundoPreto_BayWall_Corner_Inf` | `132.5 × 58.0 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 30.08 | ~17.4 g | ~0.86 h |
| `GOG-027` | `BAIA_FundoPreto_BayWall_Corner_Sup` | `160.3 × 58.0 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 36.43 | ~21.0 g | ~1.03 h |
| `GOG-028` | `BAIA_FundoPreto_BayWall_Inf` | `181.1 × 132.5 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 95.13 | ~53.2 g | ~2.54 h |
| `GOG-029` | `BAIA_FundoPreto_BayWall_Sup` | `181.1 × 158.3 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 113.64 | ~63.3 g | ~3.02 h |
