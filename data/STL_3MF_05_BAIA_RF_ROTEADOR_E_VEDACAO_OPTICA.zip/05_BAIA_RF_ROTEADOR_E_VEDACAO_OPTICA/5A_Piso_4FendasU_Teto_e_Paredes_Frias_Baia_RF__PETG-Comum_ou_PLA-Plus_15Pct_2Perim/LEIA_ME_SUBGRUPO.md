# 5A · Piso Preto com 4 Fendas U, Teto e Paredes Frias da Baía RF (22 Peças) — PETG Comum ou PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Enclausuramento frio da baía aberta do roteador MR30G (isento de carbono)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto Sem Fibra (15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Preto Fosco Profundo (#141619)` (`#141619`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `22` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `337.4 cm³` · **`~139 g`** · **`~5.2 h`** (`422 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-022` | `BAIA_BafflePreto_FundoInferior_Front` | `43.5 × 40.5 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 12.59 | ~4.9 g | ~0.18 h |
| `GOG-023` | `BAIA_BafflePreto_FundoInferior_Rear` | `43.5 × 32.3 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 6.49 | ~2.6 g | ~0.12 h |
| `GOG-024` | `BAIA_CheekFrente_Preto_Inf` | `155.5 × 63.8 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 18.56 | ~13.3 g | ~0.43 h |
| `GOG-025` | `BAIA_CheekFrente_Preto_Sup` | `160.3 × 59.6 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 18.58 | ~13.4 g | ~0.44 h |
| `GOG-056` | `BAIA_PisoPreto_BaiaBase_Behind` | `19.8 × 3.8 × 3.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.25 | ~0.2 g | ~0.08 h |
| `GOG-057` | `BAIA_PisoPreto_BaiaBase_Escuro_F` | `34.0 × 15.8 × 3.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.80 | ~1.1 g | ~0.08 h |
| `GOG-058` | `BAIA_PisoPreto_BaiaBase_Escuro_R` | `170.5 × 15.8 × 3.65` | `15% Infill + 2 Perimetros (Sem Suporte)` | 9.83 | ~5.5 g | ~0.20 h |
| `GOG-059` | `BAIA_PisoPreto_Corner_Podio_Z21_68` | `63.8 × 46.9 × 27.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 67.16 | ~19.3 g | ~0.61 h |
| `GOG-060` | `BAIA_PisoPreto_Corner_Z68_74` | `63.8 × 26.1 × 6.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 9.99 | ~4.4 g | ~0.17 h |
| `GOG-061` | `BAIA_PisoPreto_Fixo_4FendasU` | `177.5 × 63.8 × 6.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 51.70 | ~20.1 g | ~0.64 h |
| `GOG-062` | `BAIA_PisoPreto_FrontStub_BaseLower` | `59.2 × 35.0 × 17.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 35.85 | ~11.5 g | ~0.38 h |
| `GOG-063` | `BAIA_PisoPreto_FrontStub_Podio_Z21_68` | `59.6 × 35.0 × 25.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 54.13 | ~16.4 g | ~0.53 h |
| `GOG-064` | `BAIA_PisoPreto_FrontStub_Z68_74` | `63.8 × 33.8 × 6.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 12.94 | ~5.5 g | ~0.20 h |
| `GOG-098` | `BAIA_Selo_Junta_Z286_Balanco` | `177.5 × 2.4 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.49 | ~0.5 g | ~0.08 h |
| `GOG-099` | `BAIA_Selo_Junta_Z286_Corner_Dir` | `60.0 × 2.5 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.27 | ~0.3 g | ~0.08 h |
| `GOG-100` | `BAIA_Selo_Junta_Z286_Rear_Dir` | `103.8 × 2.8 × 1.5` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.26 | ~0.3 g | ~0.08 h |
| `GOG-101` | `BAIA_Selo_Junta_Z286_Rear_Esq` | `178.9 × 2.8 × 1.5` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.75 | ~0.8 g | ~0.08 h |
| `GOG-105` | `BAIA_TetoPreto_Corner_Z286` | `59.5 × 57.6 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.84 | ~0.7 g | ~0.08 h |
| `GOG-106` | `BAIA_TetoPreto_PisoBalanco_178mm` | `177.5 × 2.6 × 2.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.11 | ~1.1 g | ~0.08 h |
| `GOG-107` | `BAIA_TetoPreto_SoffitDeck_Front` | `56.1 × 39.6 × 3.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 8.44 | ~4.3 g | ~0.17 h |
| `GOG-108` | `BAIA_TetoPreto_SoffitDeck_Front_Seg2` | `74.8 × 39.6 × 3.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 11.26 | ~5.7 g | ~0.21 h |
| `GOG-109` | `BAIA_TetoPreto_SoffitDeck_Rear` | `93.6 × 39.6 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 14.13 | ~6.9 g | ~0.25 h |
