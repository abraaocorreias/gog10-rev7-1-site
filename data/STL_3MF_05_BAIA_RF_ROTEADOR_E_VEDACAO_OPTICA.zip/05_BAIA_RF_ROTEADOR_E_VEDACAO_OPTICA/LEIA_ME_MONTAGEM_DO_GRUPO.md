# 05 · Baía RF Preta do Roteador, Piso 4 Fendas U, Selos das Antenas e Plenums Chevron

**Objetivo construtivo**: Enclausuramento interno preto fosco (#141619) da baía aberta do roteador MR30G, vedação deslizante das 4 fendas U das antenas e bloqueadores ópticos de luz (plenums chevron 45° e labirinto do teto).

**Como montar este grupo**: Passo 5 da montagem: Fixe o Piso Preto com 4 Fendas U e as paredes pretas da baía (5A) no quadrante frontal direito (+X/+Y, andar T1). Encaixe os selos móveis das antenas (5B) sobre a bandeja do MR30G. Posicione os 4 plenums chevron 45° (5C) atrás das telas frontais ColF e as placas do labirinto superior (5C) sob a coroa do teto.

**Vistas de referência no site (`https://abraaocorreias.github.io/gog10-rev7-1-site/`)**: `V01, V04, V11, V21, V25, V28`

## Subgrupos de Peças, Materiais e Cores:

| Subpasta | Material | Cor | Peças | Bandejas 202×202 | Volume | Peso Estimado |
|---|---|---|---:|---:|---:|---:|
| `5A_Paredes_e_Piso_4FendasU_da_Baia_RF__Preto_141619` | PETG / ASA Opaco (Sem Fibra) | Preto Fosco Profundo (#141619) | 26 | 5 | 612.7 cm³ | **~321 g** |
| `5B_Selos_Deslizantes_Antenas_e_Vedacao_FendasU__Preto_141619` | PETG / ASA Opaco (Sem Fibra) | Preto Fosco Profundo (#141619) | 30 | 2 | 105.8 cm³ | **~56 g** |
| `5C_Plenums_Chevron_45graus_e_Labirinto_Topo__Preto_141619` | PETG / ASA Opaco (Sem Fibra) | Preto Fosco Profundo (#141619) | 20 | 9 | 643.5 cm³ | **~343 g** |
