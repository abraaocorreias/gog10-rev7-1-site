# 05 · Baía RF do Roteador e Selos das 4 Antenas (PETG Comum Sem Fibra + 4 Paredes BayWall MOD3 em PC-ABS FR)

**Objetivo construtivo**: Enclausuramento da baia aberta do roteador MR30G: 52 pecas (piso de 4 fendas U, paredes frias, teto e selos deslizantes das antenas) em PETG Comum ou PLA+ Preto Sem Fibra (15% infill, 2 perimetros), mantendo apenas as 4 placas BayWall encostadas na fonte de 135 W em PC-ABS FR (5B).

**Como montar este grupo**: Passo 5: Fixe as 4 paredes BayWall termicas (5B) na divisoria com o MOD3, monte o Piso de 4 Fendas U e paredes da baia (5A) no quadrante frontal direito e encaixe os selos deslizantes das 4 antenas (5C).

| Subpasta | Material | Fatiamento | Peças | Bandejas 202×202 | Peso Leve | Tempo Estimado |
|---|---|---|---:|---:|---:|---:|
| `5A_Piso_4FendasU_Teto_e_Paredes_Frias_Baia_RF__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Preto Sem Fibra (15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 22 | 3 | **~139 g** | **~5.2 h** |
| `5B_Paredes_Divisorias_BayWall_Contiguas_MOD3__PC-ABS-FR_20Pct_3Perim` | PC-ABS FR / PC-FR UL94 V-0 (Barreira Térmica entre Fonte 135 W e Roteador) | `20% Infill + 3 Perimetros (Sem Suporte)` | 4 | 3 | **~155 g** | **~7.5 h** |
| `5C_Selos_Deslizantes_4Antenas_e_Vedacao_FendasU__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Preto Sem Fibra (15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 30 | 2 | **~47 g** | **~3.3 h** |
