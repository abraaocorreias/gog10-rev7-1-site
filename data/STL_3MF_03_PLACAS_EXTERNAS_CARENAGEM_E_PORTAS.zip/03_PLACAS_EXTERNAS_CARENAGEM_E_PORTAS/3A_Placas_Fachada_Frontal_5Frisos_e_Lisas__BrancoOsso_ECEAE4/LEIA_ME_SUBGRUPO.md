# 3A · Placas Externas da Fachada Frontal (+X · 5 Frisos ColF, ColM e Moldura da Baía)

- **Propósito / Função**: Placas frontais visíveis da carenagem externa
- **Material Recomendado**: `ASA / PETG / PLA+ Estético`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Quantidade de Peças Imprimíveis**: `12` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `6` bandeja(s)
- **Volume Sólido / Peso Estimado**: `575.3 cm³` · **`~300 g`** (`713 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-724` | `PELE_F6_Baia_FrenteBandeja_CornerRear` | `29.12 × 24.0 × 4.0` | 2.68 | ~1.4 g |
| `GOG-725` | `PELE_F6_Baia_FrenteBandeja_FrontStub` | `32.0 × 24.0 × 4.0` | 3.07 | ~1.6 g |
| `GOG-733` | `PELE_F6_Front_5Frisos_T1_ColF` | `179.1 × 170.62 × 4.0` | 98.46 | ~51.3 g |
| `GOG-734` | `PELE_F6_Front_5Frisos_T2_ColF` | `170.62 × 157.2 × 4.0` | 81.44 | ~42.4 g |
| `GOG-735` | `PELE_F6_Front_5Frisos_T3_ColF` | `177.2 × 170.62 × 4.0` | 91.79 | ~47.8 g |
| `GOG-736` | `PELE_F6_Front_5Frisos_T4_ColF` | `170.62 × 56.0 × 4.0` | 31.03 | ~16.2 g |
| `GOG-737` | `PELE_F6_Front_Lisa_T3_ColM` | `177.2 × 80.7 × 4.0` | 56.94 | ~29.7 g |
| `GOG-738` | `PELE_F6_Front_Lisa_T3_ColR` | `178.32 × 177.2 × 4.0` | 125.03 | ~65.1 g |
| `GOG-739` | `PELE_F6_Front_Lisa_T4_ColM` | `80.7 × 56.0 × 4.0` | 17.87 | ~9.3 g |
| `GOG-740` | `PELE_F6_Front_Lisa_T4_ColR` | `178.32 × 56.0 × 4.0` | 39.16 | ~20.4 g |
| `GOG-741` | `PELE_F6_Front_PilarBay_ColM_T1` | `179.1 × 20.7 × 4.0` | 14.83 | ~7.7 g |
| `GOG-742` | `PELE_F6_Front_PilarBay_ColM_T2` | `157.2 × 20.7 × 4.0` | 12.96 | ~6.8 g |
