# 3B · Placas Externas da Fachada Traseira (-X) e as 2 Portas de Manutenção Push-Latch

- **Propósito / Função**: Fechamento traseiro 3×4 e portas de giro -95° (T1 Cabos e T3 Hub/SSD)
- **Material Recomendado**: `ASA / PETG / PLA+ Estético`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Quantidade de Peças Imprimíveis**: `12` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `9` bandeja(s)
- **Volume Sólido / Peso Estimado**: `972.9 cm³` · **`~507 g`** (`1206 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-786` | `PELE_F6_PortaClic_Rear_T1_Cabos` | `179.45 × 179.1 × 4.25` | 126.88 | ~66.1 g |
| `GOG-787` | `PELE_F6_PortaClic_Rear_T3_Hub` | `179.45 × 177.2 × 4.25` | 125.53 | ~65.4 g |
| `GOG-788` | `PELE_F6_Rear_Painel_T1_ColF` | `179.1 × 171.75 × 4.25` | 121.36 | ~63.2 g |
| `GOG-789` | `PELE_F6_Rear_Painel_T1_ColM` | `179.1 × 80.7 × 4.0` | 57.75 | ~30.1 g |
| `GOG-790` | `PELE_F6_Rear_Painel_T2_ColF` | `171.75 × 157.2 × 4.25` | 106.52 | ~55.5 g |
| `GOG-791` | `PELE_F6_Rear_Painel_T2_ColM` | `157.2 × 80.7 × 4.0` | 50.68 | ~26.4 g |
| `GOG-792` | `PELE_F6_Rear_Painel_T2_ColR` | `179.45 × 157.2 × 4.25` | 111.36 | ~58.0 g |
| `GOG-793` | `PELE_F6_Rear_Painel_T3_ColF` | `177.2 × 171.75 × 4.25` | 120.07 | ~62.5 g |
| `GOG-794` | `PELE_F6_Rear_Painel_T3_ColM` | `177.2 × 80.7 × 4.0` | 57.14 | ~29.8 g |
| `GOG-795` | `PELE_F6_Rear_Painel_T4_ColF` | `171.75 × 56.0 × 4.25` | 37.94 | ~19.8 g |
| `GOG-796` | `PELE_F6_Rear_Painel_T4_ColM` | `80.7 × 56.0 × 4.0` | 18.01 | ~9.4 g |
| `GOG-797` | `PELE_F6_Rear_Painel_T4_ColR` | `179.45 × 56.0 × 4.25` | 39.66 | ~20.7 g |
