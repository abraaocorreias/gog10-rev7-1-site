# 3E · Placas da Coroa Superior de 21 mm (6 un.) e Colares da Fresta de Exaustão de 8 mm

- **Propósito / Função**: Tampa superior monolítica bipartida e colar perimetral de saída de ar quente
- **Material Recomendado**: `ASA / PETG / PLA+ Estético`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Quantidade de Peças Imprimíveis**: `12` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `12` bandeja(s)
- **Volume Sólido / Peso Estimado**: `2695.8 cm³` · **`~1404 g`** (`3343 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-727` | `PELE_F6_FrestaExaustao_8mm_F_Dir` | `158.8 × 116.6 × 8.4` | 9.78 | ~5.1 g |
| `GOG-728` | `PELE_F6_FrestaExaustao_8mm_F_Esq` | `158.8 × 150.6 × 8.4` | 8.39 | ~4.4 g |
| `GOG-729` | `PELE_F6_FrestaExaustao_8mm_M_Dir` | `121.6 × 116.6 × 8.4` | 9.62 | ~5.0 g |
| `GOG-730` | `PELE_F6_FrestaExaustao_8mm_M_Esq` | `150.6 × 121.6 × 8.4` | 8.05 | ~4.2 g |
| `GOG-731` | `PELE_F6_FrestaExaustao_8mm_R_Dir` | `128.6 × 116.6 × 8.4` | 9.62 | ~5.0 g |
| `GOG-732` | `PELE_F6_FrestaExaustao_8mm_R_Esq` | `150.6 × 128.6 × 8.4` | 11.33 | ~5.9 g |
| `GOG-743` | `PELE_F6_LajeTopo_21mm_F_Dir` | `172.0 × 145.8 × 21.0` | 518.08 | ~269.8 g |
| `GOG-744` | `PELE_F6_LajeTopo_21mm_F_Esq` | `172.0 × 147.8 × 21.0` | 525.17 | ~273.5 g |
| `GOG-745` | `PELE_F6_LajeTopo_21mm_M_Dir` | `145.8 × 121.6 × 21.0` | 365.83 | ~190.5 g |
| `GOG-746` | `PELE_F6_LajeTopo_21mm_M_Esq` | `147.8 × 121.6 × 21.0` | 370.84 | ~193.1 g |
| `GOG-747` | `PELE_F6_LajeTopo_21mm_R_Dir` | `145.8 × 141.6 × 21.0` | 426.60 | ~222.2 g |
| `GOG-748` | `PELE_F6_LajeTopo_21mm_R_Esq` | `147.8 × 141.6 × 21.0` | 432.45 | ~225.2 g |
