# 3D · Placas Externas da Lateral Direita (+Y · Placas Lisas e Envoltório em L da Baía)

- **Propósito / Função**: Fechamento externo da face direita contornando a baía aberta do roteador
- **Material Recomendado**: `ASA / PETG / PLA+ Estético`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Quantidade de Peças Imprimíveis**: `10` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `5` bandeja(s)
- **Volume Sólido / Peso Estimado**: `568.0 cm³` · **`~296 g`** (`704 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-757` | `PELE_F6_LatPosY_BayFrameFill_T2T3` | `68.0 × 2.3 × 1.4` | 0.22 | ~0.1 g |
| `GOG-758` | `PELE_F6_LatPosY_BayWrap_T1` | `62.62 × 24.0 × 4.0` | 5.89 | ~3.1 g |
| `GOG-759` | `PELE_F6_LatPosY_T1_ColD` | `179.1 × 67.9 × 4.0` | 48.30 | ~25.2 g |
| `GOG-760` | `PELE_F6_LatPosY_T1_ColE` | `179.1 × 155.55 × 4.0` | 110.90 | ~57.8 g |
| `GOG-761` | `PELE_F6_LatPosY_T2_ColD` | `157.2 × 67.9 × 4.0` | 42.23 | ~22.0 g |
| `GOG-762` | `PELE_F6_LatPosY_T2_ColE` | `157.2 × 155.55 × 4.0` | 96.97 | ~50.5 g |
| `GOG-763` | `PELE_F6_LatPosY_T3_ColD` | `177.2 × 130.62 × 4.0` | 91.00 | ~47.4 g |
| `GOG-764` | `PELE_F6_LatPosY_T3_ColE` | `177.2 × 155.55 × 4.0` | 109.40 | ~57.0 g |
| `GOG-765` | `PELE_F6_LatPosY_T4_ColD` | `130.62 × 56.0 × 4.0` | 28.65 | ~14.9 g |
| `GOG-766` | `PELE_F6_LatPosY_T4_ColE` | `155.55 × 56.0 × 4.0` | 34.44 | ~17.9 g |
