# 3F · Almas Internas de Encaixe das Placas Externas (Juntas Secas 2 mm) — PETG Comum / PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Conectores ocultos que alinham as placas externas (agrupados juntos na mesma bandeja)
- **Material Recomendado**: `PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `73` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `81.7 cm³` · **`~77 g`** · **`~6.1 h`** (`102 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-651` | `PELE_F6_AlmaCanto_FD_T1` | `176.1 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.70 | ~0.7 g | ~0.08 h |
| `GOG-652` | `PELE_F6_AlmaCanto_FD_T2` | `151.2 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.60 | ~0.6 g | ~0.08 h |
| `GOG-653` | `PELE_F6_AlmaCanto_FD_T3` | `171.2 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.68 | ~0.7 g | ~0.08 h |
| `GOG-654` | `PELE_F6_AlmaCanto_FD_T4` | `52.6 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.21 | ~0.2 g | ~0.08 h |
| `GOG-655` | `PELE_F6_AlmaCanto_FE_T1` | `177.7 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.71 | ~0.7 g | ~0.08 h |
| `GOG-656` | `PELE_F6_AlmaCanto_FE_T2` | `154.4 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.62 | ~0.7 g | ~0.08 h |
| `GOG-657` | `PELE_F6_AlmaCanto_FE_T3` | `58.5 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.23 | ~0.2 g | ~0.08 h |
| `GOG-658` | `PELE_F6_AlmaCanto_FE_T4` | `14.5 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.06 | ~0.1 g | ~0.08 h |
| `GOG-659` | `PELE_F6_AlmaCanto_TD_T3` | `174.4 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.70 | ~0.7 g | ~0.08 h |
| `GOG-660` | `PELE_F6_AlmaCanto_TD_T4` | `54.2 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.22 | ~0.2 g | ~0.08 h |
| `GOG-661` | `PELE_F6_AlmaCanto_TE_T1` | `130.2 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.52 | ~0.5 g | ~0.08 h |
| `GOG-662` | `PELE_F6_AlmaCanto_TE_T2` | `154.4 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.62 | ~0.7 g | ~0.08 h |
| `GOG-663` | `PELE_F6_AlmaCanto_TE_T3` | `128.2 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.51 | ~0.5 g | ~0.08 h |
| `GOG-664` | `PELE_F6_AlmaCanto_TE_T4` | `54.2 × 2.0 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.22 | ~0.2 g | ~0.08 h |
| `GOG-665` | `PELE_F6_AlmaHoriz_FrontX_T1T2_ColF` | `169.3 × 7.4 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.00 | ~1.8 g | ~0.09 h |
| `GOG-666` | `PELE_F6_AlmaHoriz_FrontX_T2T3_ColF` | `169.3 × 7.4 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.00 | ~1.8 g | ~0.09 h |
| `GOG-667` | `PELE_F6_AlmaHoriz_FrontX_T2T3_ColM` | `20.7 × 4.2 × 2.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.18 | ~0.2 g | ~0.08 h |
| `GOG-668` | `PELE_F6_AlmaHoriz_FrontX_T3T4_ColF` | `169.3 × 7.4 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.99 | ~1.8 g | ~0.09 h |
| `GOG-669` | `PELE_F6_AlmaHoriz_FrontX_T3T4_ColM` | `80.7 × 4.2 × 2.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.71 | ~0.6 g | ~0.08 h |
| `GOG-670` | `PELE_F6_AlmaHoriz_FrontX_T3T4_ColR` | `175.0 × 4.2 × 2.1` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.54 | ~1.4 g | ~0.08 h |
| `GOG-671` | `PELE_F6_AlmaHoriz_NegY_T1T2_Dir` | `168.0 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.27 | ~1.2 g | ~0.08 h |
| `GOG-672` | `PELE_F6_AlmaHoriz_NegY_T1T2_Esq` | `113.45 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.86 | ~0.8 g | ~0.08 h |
| `GOG-673` | `PELE_F6_AlmaHoriz_NegY_T2T3_Dir` | `168.0 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.27 | ~1.2 g | ~0.08 h |
| `GOG-674` | `PELE_F6_AlmaHoriz_NegY_T2T3_Esq` | `113.45 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.86 | ~0.8 g | ~0.08 h |
| `GOG-675` | `PELE_F6_AlmaHoriz_NegY_T3T4_Dir` | `168.0 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.27 | ~1.2 g | ~0.08 h |
| `GOG-676` | `PELE_F6_AlmaHoriz_NegY_T3T4_Esq` | `113.45 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.86 | ~0.8 g | ~0.08 h |
| `GOG-677` | `PELE_F6_AlmaHoriz_PosY_T1T2_Dir` | `112.1 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.85 | ~0.8 g | ~0.08 h |
| `GOG-678` | `PELE_F6_AlmaHoriz_PosY_T1T2_Esq` | `113.45 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.86 | ~0.8 g | ~0.08 h |
| `GOG-679` | `PELE_F6_AlmaHoriz_PosY_T2T3_BayOverhang` | `57.2 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.43 | ~0.4 g | ~0.08 h |
| `GOG-680` | `PELE_F6_AlmaHoriz_PosY_T2T3_Dir` | `112.1 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.85 | ~0.8 g | ~0.08 h |
| `GOG-681` | `PELE_F6_AlmaHoriz_PosY_T2T3_Esq` | `113.45 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.86 | ~0.8 g | ~0.08 h |
| `GOG-682` | `PELE_F6_AlmaHoriz_PosY_T3T4_Dir` | `171.7 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.30 | ~1.2 g | ~0.08 h |
| `GOG-683` | `PELE_F6_AlmaHoriz_PosY_T3T4_Esq` | `113.45 × 4.2 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.86 | ~0.8 g | ~0.08 h |
| `GOG-684` | `PELE_F6_AlmaHoriz_RearX_T1T2_ColF` | `164.1 × 3.9 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.44 | ~1.3 g | ~0.08 h |
| `GOG-685` | `PELE_F6_AlmaHoriz_RearX_T1T2_ColM` | `85.5 × 3.9 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.75 | ~0.7 g | ~0.08 h |
| `GOG-686` | `PELE_F6_AlmaHoriz_RearX_T1T2_ColR` | `175.0 × 3.9 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.54 | ~1.4 g | ~0.08 h |
| `GOG-687` | `PELE_F6_AlmaHoriz_RearX_T2T3_ColF` | `164.1 × 4.2 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.55 | ~1.4 g | ~0.08 h |
| `GOG-688` | `PELE_F6_AlmaHoriz_RearX_T2T3_ColM` | `85.5 × 4.2 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.81 | ~0.7 g | ~0.08 h |
| `GOG-689` | `PELE_F6_AlmaHoriz_RearX_T2T3_ColR` | `175.0 × 4.2 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.65 | ~1.5 g | ~0.08 h |
| `GOG-690` | `PELE_F6_AlmaHoriz_RearX_T3T4_ColF` | `164.1 × 4.2 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.55 | ~1.4 g | ~0.08 h |
| `GOG-691` | `PELE_F6_AlmaHoriz_RearX_T3T4_ColM` | `85.5 × 4.2 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.81 | ~0.7 g | ~0.08 h |
| `GOG-692` | `PELE_F6_AlmaHoriz_RearX_T3T4_ColR` | `175.0 × 4.2 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.65 | ~1.5 g | ~0.08 h |
| `GOG-693` | `PELE_F6_AlmaLaje_Cross_F` | `12.0 × 4.0 × 1.7` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.08 | ~0.1 g | ~0.08 h |
| `GOG-694` | `PELE_F6_AlmaLaje_Cross_M` | `12.0 × 4.0 × 1.7` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.08 | ~0.1 g | ~0.08 h |
| `GOG-695` | `PELE_F6_AlmaLaje_X38_F` | `171.6 × 12.0 × 1.85` | `15% Infill + 2 Perimetros (Sem Suporte)` | 3.81 | ~3.1 g | ~0.13 h |
| `GOG-696` | `PELE_F6_AlmaLaje_X38_M` | `121.2 × 12.0 × 1.85` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.69 | ~2.2 g | ~0.11 h |
| `GOG-697` | `PELE_F6_AlmaLaje_X38_R` | `141.2 × 12.0 × 1.85` | `15% Infill + 2 Perimetros (Sem Suporte)` | 3.13 | ~2.5 g | ~0.12 h |
| `GOG-698` | `PELE_F6_AlmaLaje_Y_F_Dir` | `129.8 × 5.6 × 1.85` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.34 | ~1.2 g | ~0.08 h |
| `GOG-699` | `PELE_F6_AlmaLaje_Y_F_Esq` | `131.8 × 5.6 × 1.85` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.37 | ~1.2 g | ~0.08 h |
| `GOG-700` | `PELE_F6_AlmaLaje_Y_M_Dir` | `129.8 × 5.0 × 1.85` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.20 | ~1.1 g | ~0.08 h |
| `GOG-701` | `PELE_F6_AlmaLaje_Y_M_Esq` | `131.8 × 5.0 × 1.85` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.22 | ~1.1 g | ~0.08 h |
| `GOG-702` | `PELE_F6_AlmaVert_FrontX_T1_Y145` | `175.7 × 2.7 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.95 | ~1.0 g | ~0.08 h |
| `GOG-703` | `PELE_F6_AlmaVert_FrontX_T2_Y145` | `151.2 × 2.7 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.82 | ~0.8 g | ~0.08 h |
| `GOG-704` | `PELE_F6_AlmaVert_FrontX_T3_Y145` | `171.2 × 2.7 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.92 | ~1.0 g | ~0.08 h |
| `GOG-705` | `PELE_F6_AlmaVert_FrontX_T3_Y62` | `171.2 × 2.3 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.79 | ~0.8 g | ~0.08 h |
| `GOG-706` | `PELE_F6_AlmaVert_FrontX_T4_Y145` | `52.6 × 2.7 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.28 | ~0.3 g | ~0.08 h |
| `GOG-707` | `PELE_F6_AlmaVert_FrontX_T4_Y62` | `52.6 × 2.3 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.24 | ~0.3 g | ~0.08 h |
| `GOG-708` | `PELE_F6_AlmaVert_LatNegY_T1_X25` | `177.7 × 8.0 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.27 | ~2.1 g | ~0.10 h |
| `GOG-709` | `PELE_F6_AlmaVert_LatNegY_T2_X25` | `154.4 × 8.0 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.98 | ~1.8 g | ~0.09 h |
| `GOG-710` | `PELE_F6_AlmaVert_LatNegY_T3_X25` | `174.4 × 8.0 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.23 | ~2.0 g | ~0.10 h |
| `GOG-711` | `PELE_F6_AlmaVert_LatNegY_T4_X25` | `54.6 × 8.0 × 1.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.70 | ~0.6 g | ~0.08 h |
| `GOG-712` | `PELE_F6_AlmaVert_LatPosY_T1_X25` | `177.7 × 8.0 × 1.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.85 | ~1.9 g | ~0.10 h |
| `GOG-713` | `PELE_F6_AlmaVert_LatPosY_T2_X25` | `154.4 × 8.0 × 1.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.61 | ~1.6 g | ~0.09 h |
| `GOG-714` | `PELE_F6_AlmaVert_LatPosY_T3_X25` | `174.4 × 8.0 × 1.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.81 | ~1.9 g | ~0.10 h |
| `GOG-715` | `PELE_F6_AlmaVert_LatPosY_T4_X25` | `54.6 × 8.0 × 1.3` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.57 | ~0.6 g | ~0.08 h |
| `GOG-716` | `PELE_F6_AlmaVert_RearX_T1_Y145` | `177.7 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.68 | ~1.7 g | ~0.09 h |
| `GOG-717` | `PELE_F6_AlmaVert_RearX_T1_Y62` | `177.7 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.68 | ~1.7 g | ~0.09 h |
| `GOG-718` | `PELE_F6_AlmaVert_RearX_T2_Y145` | `154.4 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.46 | ~1.5 g | ~0.08 h |
| `GOG-719` | `PELE_F6_AlmaVert_RearX_T2_Y62` | `154.4 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.46 | ~1.5 g | ~0.08 h |
| `GOG-720` | `PELE_F6_AlmaVert_RearX_T3_Y145` | `174.4 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.65 | ~1.7 g | ~0.09 h |
| `GOG-721` | `PELE_F6_AlmaVert_RearX_T3_Y62` | `174.4 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.65 | ~1.7 g | ~0.09 h |
| `GOG-722` | `PELE_F6_AlmaVert_RearX_T4_Y145` | `54.2 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.51 | ~0.5 g | ~0.08 h |
| `GOG-723` | `PELE_F6_AlmaVert_RearX_T4_Y62` | `54.2 × 7.0 × 1.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.51 | ~0.5 g | ~0.08 h |
