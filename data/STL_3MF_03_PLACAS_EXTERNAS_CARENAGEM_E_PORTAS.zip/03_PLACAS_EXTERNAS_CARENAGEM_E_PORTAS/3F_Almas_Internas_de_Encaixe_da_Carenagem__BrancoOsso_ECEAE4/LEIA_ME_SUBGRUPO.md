# 3F · Almas Internas Horizontais, Verticais, de Canto e de Laje (Juntas Secas 2 mm)

- **Propósito / Função**: Conectores ocultos que alinham e travam as placas externas sem parafusos aparentes
- **Material Recomendado**: `ASA / PETG / PLA+ Estético`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Quantidade de Peças Imprimíveis**: `73` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Estimado**: `81.7 cm³` · **`~42 g`** (`102 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-651` | `PELE_F6_AlmaCanto_FD_T1` | `176.1 × 2.0 × 2.0` | 0.70 | ~0.4 g |
| `GOG-652` | `PELE_F6_AlmaCanto_FD_T2` | `151.2 × 2.0 × 2.0` | 0.60 | ~0.3 g |
| `GOG-653` | `PELE_F6_AlmaCanto_FD_T3` | `171.2 × 2.0 × 2.0` | 0.68 | ~0.4 g |
| `GOG-654` | `PELE_F6_AlmaCanto_FD_T4` | `52.6 × 2.0 × 2.0` | 0.21 | ~0.1 g |
| `GOG-655` | `PELE_F6_AlmaCanto_FE_T1` | `177.7 × 2.0 × 2.0` | 0.71 | ~0.4 g |
| `GOG-656` | `PELE_F6_AlmaCanto_FE_T2` | `154.4 × 2.0 × 2.0` | 0.62 | ~0.3 g |
| `GOG-657` | `PELE_F6_AlmaCanto_FE_T3` | `58.5 × 2.0 × 2.0` | 0.23 | ~0.1 g |
| `GOG-658` | `PELE_F6_AlmaCanto_FE_T4` | `14.5 × 2.0 × 2.0` | 0.06 | ~0.0 g |
| `GOG-659` | `PELE_F6_AlmaCanto_TD_T3` | `174.4 × 2.0 × 2.0` | 0.70 | ~0.4 g |
| `GOG-660` | `PELE_F6_AlmaCanto_TD_T4` | `54.2 × 2.0 × 2.0` | 0.22 | ~0.1 g |
| `GOG-661` | `PELE_F6_AlmaCanto_TE_T1` | `130.2 × 2.0 × 2.0` | 0.52 | ~0.3 g |
| `GOG-662` | `PELE_F6_AlmaCanto_TE_T2` | `154.4 × 2.0 × 2.0` | 0.62 | ~0.3 g |
| `GOG-663` | `PELE_F6_AlmaCanto_TE_T3` | `128.2 × 2.0 × 2.0` | 0.51 | ~0.3 g |
| `GOG-664` | `PELE_F6_AlmaCanto_TE_T4` | `54.2 × 2.0 × 2.0` | 0.22 | ~0.1 g |
| `GOG-665` | `PELE_F6_AlmaHoriz_FrontX_T1T2_ColF` | `169.3 × 7.4 × 1.6` | 2.00 | ~1.0 g |
| `GOG-666` | `PELE_F6_AlmaHoriz_FrontX_T2T3_ColF` | `169.3 × 7.4 × 1.6` | 2.00 | ~1.0 g |
| `GOG-667` | `PELE_F6_AlmaHoriz_FrontX_T2T3_ColM` | `20.7 × 4.2 × 2.1` | 0.18 | ~0.1 g |
| `GOG-668` | `PELE_F6_AlmaHoriz_FrontX_T3T4_ColF` | `169.3 × 7.4 × 1.6` | 1.99 | ~1.0 g |
| `GOG-669` | `PELE_F6_AlmaHoriz_FrontX_T3T4_ColM` | `80.7 × 4.2 × 2.1` | 0.71 | ~0.4 g |
| `GOG-670` | `PELE_F6_AlmaHoriz_FrontX_T3T4_ColR` | `175.0 × 4.2 × 2.1` | 1.54 | ~0.8 g |
| `GOG-671` | `PELE_F6_AlmaHoriz_NegY_T1T2_Dir` | `168.0 × 4.2 × 1.8` | 1.27 | ~0.7 g |
| `GOG-672` | `PELE_F6_AlmaHoriz_NegY_T1T2_Esq` | `113.45 × 4.2 × 1.8` | 0.86 | ~0.4 g |
| `GOG-673` | `PELE_F6_AlmaHoriz_NegY_T2T3_Dir` | `168.0 × 4.2 × 1.8` | 1.27 | ~0.7 g |
| `GOG-674` | `PELE_F6_AlmaHoriz_NegY_T2T3_Esq` | `113.45 × 4.2 × 1.8` | 0.86 | ~0.4 g |
| `GOG-675` | `PELE_F6_AlmaHoriz_NegY_T3T4_Dir` | `168.0 × 4.2 × 1.8` | 1.27 | ~0.7 g |
| `GOG-676` | `PELE_F6_AlmaHoriz_NegY_T3T4_Esq` | `113.45 × 4.2 × 1.8` | 0.86 | ~0.4 g |
| `GOG-677` | `PELE_F6_AlmaHoriz_PosY_T1T2_Dir` | `112.1 × 4.2 × 1.8` | 0.85 | ~0.4 g |
| `GOG-678` | `PELE_F6_AlmaHoriz_PosY_T1T2_Esq` | `113.45 × 4.2 × 1.8` | 0.86 | ~0.4 g |
| `GOG-679` | `PELE_F6_AlmaHoriz_PosY_T2T3_BayOverhang` | `57.2 × 4.2 × 1.8` | 0.43 | ~0.2 g |
| `GOG-680` | `PELE_F6_AlmaHoriz_PosY_T2T3_Dir` | `112.1 × 4.2 × 1.8` | 0.85 | ~0.4 g |
| `GOG-681` | `PELE_F6_AlmaHoriz_PosY_T2T3_Esq` | `113.45 × 4.2 × 1.8` | 0.86 | ~0.4 g |
| `GOG-682` | `PELE_F6_AlmaHoriz_PosY_T3T4_Dir` | `171.7 × 4.2 × 1.8` | 1.30 | ~0.7 g |
| `GOG-683` | `PELE_F6_AlmaHoriz_PosY_T3T4_Esq` | `113.45 × 4.2 × 1.8` | 0.86 | ~0.4 g |
| `GOG-684` | `PELE_F6_AlmaHoriz_RearX_T1T2_ColF` | `164.1 × 3.9 × 2.25` | 1.44 | ~0.7 g |
| `GOG-685` | `PELE_F6_AlmaHoriz_RearX_T1T2_ColM` | `85.5 × 3.9 × 2.25` | 0.75 | ~0.4 g |
| `GOG-686` | `PELE_F6_AlmaHoriz_RearX_T1T2_ColR` | `175.0 × 3.9 × 2.25` | 1.54 | ~0.8 g |
| `GOG-687` | `PELE_F6_AlmaHoriz_RearX_T2T3_ColF` | `164.1 × 4.2 × 2.25` | 1.55 | ~0.8 g |
| `GOG-688` | `PELE_F6_AlmaHoriz_RearX_T2T3_ColM` | `85.5 × 4.2 × 2.25` | 0.81 | ~0.4 g |
| `GOG-689` | `PELE_F6_AlmaHoriz_RearX_T2T3_ColR` | `175.0 × 4.2 × 2.25` | 1.65 | ~0.9 g |
| `GOG-690` | `PELE_F6_AlmaHoriz_RearX_T3T4_ColF` | `164.1 × 4.2 × 2.25` | 1.55 | ~0.8 g |
| `GOG-691` | `PELE_F6_AlmaHoriz_RearX_T3T4_ColM` | `85.5 × 4.2 × 2.25` | 0.81 | ~0.4 g |
| `GOG-692` | `PELE_F6_AlmaHoriz_RearX_T3T4_ColR` | `175.0 × 4.2 × 2.25` | 1.65 | ~0.9 g |
| `GOG-693` | `PELE_F6_AlmaLaje_Cross_F` | `12.0 × 4.0 × 1.7` | 0.08 | ~0.0 g |
| `GOG-694` | `PELE_F6_AlmaLaje_Cross_M` | `12.0 × 4.0 × 1.7` | 0.08 | ~0.0 g |
| `GOG-695` | `PELE_F6_AlmaLaje_X38_F` | `171.6 × 12.0 × 1.85` | 3.81 | ~2.0 g |
| `GOG-696` | `PELE_F6_AlmaLaje_X38_M` | `121.2 × 12.0 × 1.85` | 2.69 | ~1.4 g |
| `GOG-697` | `PELE_F6_AlmaLaje_X38_R` | `141.2 × 12.0 × 1.85` | 3.13 | ~1.6 g |
| `GOG-698` | `PELE_F6_AlmaLaje_Y_F_Dir` | `129.8 × 5.6 × 1.85` | 1.34 | ~0.7 g |
| `GOG-699` | `PELE_F6_AlmaLaje_Y_F_Esq` | `131.8 × 5.6 × 1.85` | 1.37 | ~0.7 g |
| `GOG-700` | `PELE_F6_AlmaLaje_Y_M_Dir` | `129.8 × 5.0 × 1.85` | 1.20 | ~0.6 g |
| `GOG-701` | `PELE_F6_AlmaLaje_Y_M_Esq` | `131.8 × 5.0 × 1.85` | 1.22 | ~0.6 g |
| `GOG-702` | `PELE_F6_AlmaVert_FrontX_T1_Y145` | `175.7 × 2.7 × 2.0` | 0.95 | ~0.5 g |
| `GOG-703` | `PELE_F6_AlmaVert_FrontX_T2_Y145` | `151.2 × 2.7 × 2.0` | 0.82 | ~0.4 g |
| `GOG-704` | `PELE_F6_AlmaVert_FrontX_T3_Y145` | `171.2 × 2.7 × 2.0` | 0.92 | ~0.5 g |
| `GOG-705` | `PELE_F6_AlmaVert_FrontX_T3_Y62` | `171.2 × 2.3 × 2.0` | 0.79 | ~0.4 g |
| `GOG-706` | `PELE_F6_AlmaVert_FrontX_T4_Y145` | `52.6 × 2.7 × 2.0` | 0.28 | ~0.1 g |
| `GOG-707` | `PELE_F6_AlmaVert_FrontX_T4_Y62` | `52.6 × 2.3 × 2.0` | 0.24 | ~0.1 g |
| `GOG-708` | `PELE_F6_AlmaVert_LatNegY_T1_X25` | `177.7 × 8.0 × 1.6` | 2.27 | ~1.2 g |
| `GOG-709` | `PELE_F6_AlmaVert_LatNegY_T2_X25` | `154.4 × 8.0 × 1.6` | 1.98 | ~1.0 g |
| `GOG-710` | `PELE_F6_AlmaVert_LatNegY_T3_X25` | `174.4 × 8.0 × 1.6` | 2.23 | ~1.2 g |
| `GOG-711` | `PELE_F6_AlmaVert_LatNegY_T4_X25` | `54.6 × 8.0 × 1.6` | 0.70 | ~0.4 g |
| `GOG-712` | `PELE_F6_AlmaVert_LatPosY_T1_X25` | `177.7 × 8.0 × 1.3` | 1.85 | ~1.0 g |
| `GOG-713` | `PELE_F6_AlmaVert_LatPosY_T2_X25` | `154.4 × 8.0 × 1.3` | 1.61 | ~0.8 g |
| `GOG-714` | `PELE_F6_AlmaVert_LatPosY_T3_X25` | `174.4 × 8.0 × 1.3` | 1.81 | ~0.9 g |
| `GOG-715` | `PELE_F6_AlmaVert_LatPosY_T4_X25` | `54.6 × 8.0 × 1.3` | 0.57 | ~0.3 g |
| `GOG-716` | `PELE_F6_AlmaVert_RearX_T1_Y145` | `177.7 × 7.0 × 1.35` | 1.68 | ~0.9 g |
| `GOG-717` | `PELE_F6_AlmaVert_RearX_T1_Y62` | `177.7 × 7.0 × 1.35` | 1.68 | ~0.9 g |
| `GOG-718` | `PELE_F6_AlmaVert_RearX_T2_Y145` | `154.4 × 7.0 × 1.35` | 1.46 | ~0.8 g |
| `GOG-719` | `PELE_F6_AlmaVert_RearX_T2_Y62` | `154.4 × 7.0 × 1.35` | 1.46 | ~0.8 g |
| `GOG-720` | `PELE_F6_AlmaVert_RearX_T3_Y145` | `174.4 × 7.0 × 1.35` | 1.65 | ~0.9 g |
| `GOG-721` | `PELE_F6_AlmaVert_RearX_T3_Y62` | `174.4 × 7.0 × 1.35` | 1.65 | ~0.9 g |
| `GOG-722` | `PELE_F6_AlmaVert_RearX_T4_Y145` | `54.2 × 7.0 × 1.35` | 0.51 | ~0.3 g |
| `GOG-723` | `PELE_F6_AlmaVert_RearX_T4_Y62` | `54.2 × 7.0 × 1.35` | 0.51 | ~0.3 g |
