# 3C · Placas Externas da Lateral Esquerda (-Y · 8 Placas Lisas T1 a T4)

- **Propósito / Função**: Fechamento externo liso da face estreita esquerda (294 mm)
- **Material Recomendado**: `ASA / PETG / PLA+ Estético`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Quantidade de Peças Imprimíveis**: `8` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `6` bandeja(s)
- **Volume Sólido / Peso Estimado**: `641.1 cm³` · **`~334 g`** (`795 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-749` | `PELE_F6_LatNegY_T1_ColD` | `179.1 × 127.8 × 4.0` | 91.17 | ~47.5 g |
| `GOG-750` | `PELE_F6_LatNegY_T1_ColE` | `179.1 × 155.55 × 4.0` | 110.98 | ~57.8 g |
| `GOG-751` | `PELE_F6_LatNegY_T2_ColD` | `157.2 × 127.8 × 4.0` | 79.73 | ~41.5 g |
| `GOG-752` | `PELE_F6_LatNegY_T2_ColE` | `157.2 × 155.55 × 4.0` | 97.05 | ~50.5 g |
| `GOG-753` | `PELE_F6_LatNegY_T3_ColD` | `177.2 × 127.8 × 4.0` | 89.94 | ~46.8 g |
| `GOG-754` | `PELE_F6_LatNegY_T3_ColE` | `177.2 × 155.55 × 4.0` | 109.48 | ~57.0 g |
| `GOG-755` | `PELE_F6_LatNegY_T4_ColD` | `127.8 × 56.0 × 4.0` | 28.32 | ~14.7 g |
| `GOG-756` | `PELE_F6_LatNegY_T4_ColE` | `155.55 × 56.0 × 4.0` | 34.47 | ~18.0 g |
