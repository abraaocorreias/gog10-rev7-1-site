# 03 · Placas da Parte Externa e Portas (PETG Comum ou PLA+ · 15% Infill e 2 Perímetros)

**Objetivo construtivo**: Toda a carenagem externa (#ECEAE4) usa PETG Comum ou PLA+ com 15% de preenchimento e 2 perimetros (sem suporte). As 6 lajes de 21 mm do teto (3E) foram aliviadas em casca de 3,2 mm (-1.535 cm3 / -1,0 kg!), e as 32 placas lisas de 4 mm (3B) acompanham arquivo .DXF 1:1 para opcao de corte a laser.

**Como montar este grupo**: Passo 6 (final): Encaixe as almas de 2 mm (3F), monte os paineis frontais de 5 frisos (3A), as placas lisas de 4 mm (3B), as 2 portas traseiras de clique (3C) e feche o teto com a coroa aliviada de 21 mm (3E).

| Subpasta | Material | Fatiamento | Peças | Bandejas 202×202 | Peso Leve | Tempo Estimado |
|---|---|---|---:|---:|---:|---:|
| `3A_Placas_Frontais_5Frisos_e_Envoltorio_Baia_3D__PETG-Comum_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 8 | 4 | **~144 g** | **~4.7 h** |
| `3B_Placas_Planas_Lisas_4mm__PETG-Comum_PLA-Plus_15Pct_2Perim_ou_Laser_DXF` | PETG Comum ou PLA+ (#ECEAE4 · 15% Infill · 2 Perímetros) OU Chapa Cortada a Laser | `15% Infill + 2 Perimetros (Sem Suporte)` | 32 | 19 | **~999 g** | **~31.1 h** |
| `3C_Portas_Traseiras_de_Clique_Giro_95graus__PETG-Comum_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 2 | 2 | **~111 g** | **~3.4 h** |
| `3E_Placas_Topo_Coroa_21mm_Aliviada_e_Frestas_8mm__PETG-Comum_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 12 | 12 | **~306 g** | **~9.6 h** |
| `3F_Almas_Internas_de_Encaixe_da_Carenagem__PETG-Comum_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 73 | 3 | **~77 g** | **~6.1 h** |
