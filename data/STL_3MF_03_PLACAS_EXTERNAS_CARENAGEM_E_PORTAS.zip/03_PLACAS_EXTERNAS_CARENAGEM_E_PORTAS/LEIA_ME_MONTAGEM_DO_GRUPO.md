# 03 · Placas da Parte Externa (Carenagem #ECEAE4, 2 Portas Clique, Topo e Almas)

**Objetivo construtivo**: Fechamento externo modular em placas (< 202 mm) com junta seca de 2 mm, 5 frisos verticais frontais ColF, 2 portas traseiras com abertura -95° e coroa superior de 21 mm.

**Como montar este grupo**: Passo 6 (final) da montagem: Instale primeiro as almas internas de união (3F) nos pinos/braços do esqueleto. Cole/encaixe as 4 telas colmeia pretas (3G) atrás dos painéis frontais de 5 frisos (3A). Monte os painéis frontais (3A), laterais esquerdos (3C), laterais direitos (3D) e traseiros fixos (3B). Instale as 2 portas traseiras (3B) com pino inox vertical e fecho push-latch (tic-tac). Feche o topo com os 6 colares de fresta 8 mm e as 6 placas da laje de 21 mm (3E).

**Vistas de referência no site (`https://abraaocorreias.github.io/gog10-rev7-1-site/`)**: `V01, V02, V03, V04, V05, V18, V26, V28, V30`

## Subgrupos de Peças, Materiais e Cores:

| Subpasta | Material | Cor | Peças | Bandejas 202×202 | Volume | Peso Estimado |
|---|---|---|---:|---:|---:|---:|
| `3A_Placas_Fachada_Frontal_5Frisos_e_Lisas__BrancoOsso_ECEAE4` | ASA / PETG / PLA+ Estético | Branco-Osso / Cinza-Pedra (#ECEAE4) | 12 | 6 | 575.3 cm³ | **~300 g** |
| `3B_Placas_Fachada_Traseira_e_2_Portas_Clique__BrancoOsso_ECEAE4` | ASA / PETG / PLA+ Estético | Branco-Osso / Cinza-Pedra (#ECEAE4) | 12 | 9 | 972.9 cm³ | **~507 g** |
| `3C_Placas_Lateral_Esquerda_NegY__BrancoOsso_ECEAE4` | ASA / PETG / PLA+ Estético | Branco-Osso / Cinza-Pedra (#ECEAE4) | 8 | 6 | 641.1 cm³ | **~334 g** |
| `3D_Placas_Lateral_Direita_PosY__BrancoOsso_ECEAE4` | ASA / PETG / PLA+ Estético | Branco-Osso / Cinza-Pedra (#ECEAE4) | 10 | 5 | 568.0 cm³ | **~296 g** |
| `3E_Placas_Topo_Coroa_21mm_e_Frestas_8mm__BrancoOsso_ECEAE4` | ASA / PETG / PLA+ Estético | Branco-Osso / Cinza-Pedra (#ECEAE4) | 12 | 12 | 2695.8 cm³ | **~1404 g** |
| `3F_Almas_Internas_de_Encaixe_da_Carenagem__BrancoOsso_ECEAE4` | ASA / PETG / PLA+ Estético | Branco-Osso / Cinza-Pedra (#ECEAE4) | 73 | 3 | 81.7 cm³ | **~42 g** |
| `3G_Telas_Colmeia_Internas_dos_Frisos__PETG_Preto_141619` | PETG / ASA Opaco | Preto Fosco Profundo (#141619) | 4 | 3 | 28.3 cm³ | **~15 g** |
