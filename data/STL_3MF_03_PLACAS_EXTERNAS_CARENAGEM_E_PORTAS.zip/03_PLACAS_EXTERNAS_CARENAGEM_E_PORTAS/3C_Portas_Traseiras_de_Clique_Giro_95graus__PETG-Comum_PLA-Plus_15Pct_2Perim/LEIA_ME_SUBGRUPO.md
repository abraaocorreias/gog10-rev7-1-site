# 3C · As 2 Portas Traseiras de Manutenção (Giro -95°) — PETG Comum / PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Portas móveis T1 (Cabos/Fibra) e T3 (Hub/SSD/SW1) com bucha oculta
- **Material Recomendado**: `PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `2` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `252.4 cm³` · **`~111 g`** · **`~3.4 h`** (`313 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-786` | `PELE_F6_PortaClic_Rear_T1_Cabos` | `179.45 × 179.1 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 126.88 | ~55.7 g | ~1.70 h |
| `GOG-787` | `PELE_F6_PortaClic_Rear_T3_Hub` | `179.45 × 177.2 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 125.53 | ~55.2 g | ~1.69 h |
