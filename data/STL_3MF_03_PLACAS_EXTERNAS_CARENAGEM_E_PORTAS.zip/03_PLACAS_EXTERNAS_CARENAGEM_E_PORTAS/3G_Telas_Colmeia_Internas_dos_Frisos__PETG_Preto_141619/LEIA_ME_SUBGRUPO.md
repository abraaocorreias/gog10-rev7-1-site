# 3G · Telas Colmeia Recuadas dos 5 Frisos Frontais ColF (T1 a T4 · 1 Ilha Sólida)

- **Propósito / Função**: Grades colmeia pretas encaixadas atrás dos 5 rasgos verticais frontais
- **Material Recomendado**: `PETG / ASA Opaco`
- **Cor Indicada**: `Preto Fosco Profundo (#141619)` (`#141619`)
- **Quantidade de Peças Imprimíveis**: `4` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Estimado**: `28.3 cm³` · **`~15 g`** (`36 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-018` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T1_ColF` | `142.84 × 104.0 × 1.8` | 7.88 | ~4.2 g |
| `GOG-019` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T2_ColF` | `153.94 × 104.0 × 1.8` | 8.41 | ~4.5 g |
| `GOG-020` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T3_ColF` | `173.94 × 104.0 × 1.8` | 9.39 | ~5.0 g |
| `GOG-021` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T4_ColF` | `104.0 × 42.84 × 1.8` | 2.64 | ~1.4 g |
