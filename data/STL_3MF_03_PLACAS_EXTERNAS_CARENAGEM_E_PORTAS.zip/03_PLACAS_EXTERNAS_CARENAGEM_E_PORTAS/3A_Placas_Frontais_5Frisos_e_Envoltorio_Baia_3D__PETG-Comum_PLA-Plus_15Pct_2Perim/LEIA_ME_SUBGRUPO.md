# 3A · Placas com Geometria 3D (Fachada 5 Frisos ColF e Envoltório em L) — PETG Comum / PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Placas externas com rasgos cápsula R=4 mm e dobras em L
- **Material Recomendado**: `PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `8` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `4` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `314.6 cm³` · **`~144 g`** · **`~4.7 h`** (`390 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-724` | `PELE_F6_Baia_FrenteBandeja_CornerRear` | `29.12 × 24.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.68 | ~1.4 g | ~0.08 h |
| `GOG-725` | `PELE_F6_Baia_FrenteBandeja_FrontStub` | `32.0 × 24.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 3.07 | ~1.6 g | ~0.09 h |
| `GOG-733` | `PELE_F6_Front_5Frisos_T1_ColF` | `179.1 × 170.62 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 98.46 | ~44.7 g | ~1.38 h |
| `GOG-734` | `PELE_F6_Front_5Frisos_T2_ColF` | `170.62 × 157.2 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 81.44 | ~37.1 g | ~1.15 h |
| `GOG-735` | `PELE_F6_Front_5Frisos_T3_ColF` | `177.2 × 170.62 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 91.79 | ~41.7 g | ~1.29 h |
| `GOG-736` | `PELE_F6_Front_5Frisos_T4_ColF` | `170.62 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 31.03 | ~14.6 g | ~0.48 h |
| `GOG-757` | `PELE_F6_LatPosY_BayFrameFill_T2T3` | `68.0 × 2.3 × 1.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.22 | ~0.2 g | ~0.08 h |
| `GOG-758` | `PELE_F6_LatPosY_BayWrap_T1` | `62.62 × 24.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 5.89 | ~3.0 g | ~0.13 h |
