# 3E · Placas da Coroa Superior de 21 mm (Aliviadas em Casca 3,2 mm: -1 kg!) e Fresta 8 mm — PETG Comum / PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Tampa superior nervurada (imprime virada em Z=0 sem suportes) e colar de exaustão
- **Material Recomendado**: `PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `12` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `12` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `1171.7 cm³` · **`~306 g`** · **`~9.6 h`** (`1453 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-727` | `PELE_F6_FrestaExaustao_8mm_F_Dir` | `158.8 × 116.6 × 8.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 9.78 | ~3.2 g | ~0.14 h |
| `GOG-728` | `PELE_F6_FrestaExaustao_8mm_F_Esq` | `158.8 × 150.6 × 8.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 8.39 | ~2.7 g | ~0.12 h |
| `GOG-729` | `PELE_F6_FrestaExaustao_8mm_M_Dir` | `121.6 × 116.6 × 8.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 9.62 | ~3.2 g | ~0.14 h |
| `GOG-730` | `PELE_F6_FrestaExaustao_8mm_M_Esq` | `150.6 × 121.6 × 8.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 8.05 | ~2.7 g | ~0.12 h |
| `GOG-731` | `PELE_F6_FrestaExaustao_8mm_R_Dir` | `128.6 × 116.6 × 8.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 9.62 | ~3.2 g | ~0.14 h |
| `GOG-732` | `PELE_F6_FrestaExaustao_8mm_R_Esq` | `150.6 × 128.6 × 8.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 11.33 | ~3.7 g | ~0.15 h |
| `GOG-743` | `PELE_F6_LajeTopo_21mm_F_Dir` | `145.8 × 172.0 × 21.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 200.94 | ~51.3 g | ~1.57 h |
| `GOG-744` | `PELE_F6_LajeTopo_21mm_F_Esq` | `147.8 × 172.0 × 21.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 221.42 | ~56.5 g | ~1.73 h |
| `GOG-745` | `PELE_F6_LajeTopo_21mm_M_Dir` | `145.8 × 121.6 × 21.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 156.79 | ~40.7 g | ~1.26 h |
| `GOG-746` | `PELE_F6_LajeTopo_21mm_M_Esq` | `147.8 × 121.6 × 21.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 170.67 | ~44.3 g | ~1.36 h |
| `GOG-747` | `PELE_F6_LajeTopo_21mm_R_Dir` | `145.8 × 141.6 × 21.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 174.31 | ~44.9 g | ~1.38 h |
| `GOG-748` | `PELE_F6_LajeTopo_21mm_R_Esq` | `147.8 × 141.6 × 21.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 190.81 | ~49.1 g | ~1.51 h |
