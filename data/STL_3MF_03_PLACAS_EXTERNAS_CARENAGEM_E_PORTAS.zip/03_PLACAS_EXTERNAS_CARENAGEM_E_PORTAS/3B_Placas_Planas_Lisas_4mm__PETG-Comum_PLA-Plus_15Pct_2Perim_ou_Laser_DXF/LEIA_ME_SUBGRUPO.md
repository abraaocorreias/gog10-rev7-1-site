# 3B · 32 Placas Externas Planas Lisas de 4 mm — PETG Comum / PLA+ (15% Infill · 2 Perímetros) OU Chapa Cortada a Laser (DXF incluso)

- **Propósito / Função**: Placas planas sem relevo 3D (imprimir com 15% infill e 2 perimetros ou cortar no laser via DXF)
- **Material Recomendado**: `PETG Comum ou PLA+ (#ECEAE4 · 15% Infill · 2 Perímetros) OU Chapa Cortada a Laser`
- **Cor Indicada**: `Branco-Osso / Cinza-Pedra (#ECEAE4)` (`#ECEAE4`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `32` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `19` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `2190.3 cm³` · **`~999 g`** · **`~31.1 h`** (`2716 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-737` | `PELE_F6_Front_Lisa_T3_ColM` | `177.2 × 80.7 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 56.94 | ~26.4 g | ~0.83 h |
| `GOG-738` | `PELE_F6_Front_Lisa_T3_ColR` | `178.32 × 177.2 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 125.03 | ~56.8 g | ~1.74 h |
| `GOG-739` | `PELE_F6_Front_Lisa_T4_ColM` | `80.7 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 17.87 | ~8.6 g | ~0.30 h |
| `GOG-740` | `PELE_F6_Front_Lisa_T4_ColR` | `178.32 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 39.16 | ~18.4 g | ~0.59 h |
| `GOG-741` | `PELE_F6_Front_PilarBay_ColM_T1` | `179.1 × 20.7 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 14.83 | ~7.6 g | ~0.27 h |
| `GOG-742` | `PELE_F6_Front_PilarBay_ColM_T2` | `157.2 × 20.7 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 12.96 | ~6.6 g | ~0.24 h |
| `GOG-749` | `PELE_F6_LatNegY_T1_ColD` | `179.1 × 127.8 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 91.17 | ~41.7 g | ~1.28 h |
| `GOG-750` | `PELE_F6_LatNegY_T1_ColE` | `179.1 × 155.55 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 110.98 | ~50.5 g | ~1.55 h |
| `GOG-751` | `PELE_F6_LatNegY_T2_ColD` | `157.2 × 127.8 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 79.73 | ~36.5 g | ~1.13 h |
| `GOG-752` | `PELE_F6_LatNegY_T2_ColE` | `157.2 × 155.55 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 97.05 | ~44.3 g | ~1.36 h |
| `GOG-753` | `PELE_F6_LatNegY_T3_ColD` | `177.2 × 127.8 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 89.94 | ~41.1 g | ~1.27 h |
| `GOG-754` | `PELE_F6_LatNegY_T3_ColE` | `177.2 × 155.55 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 109.48 | ~49.8 g | ~1.53 h |
| `GOG-755` | `PELE_F6_LatNegY_T4_ColD` | `127.8 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 28.32 | ~13.4 g | ~0.44 h |
| `GOG-756` | `PELE_F6_LatNegY_T4_ColE` | `155.55 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 34.47 | ~16.2 g | ~0.53 h |
| `GOG-759` | `PELE_F6_LatPosY_T1_ColD` | `179.1 × 67.9 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 48.30 | ~22.5 g | ~0.71 h |
| `GOG-760` | `PELE_F6_LatPosY_T1_ColE` | `179.1 × 155.55 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 110.90 | ~50.5 g | ~1.55 h |
| `GOG-761` | `PELE_F6_LatPosY_T2_ColD` | `157.2 × 67.9 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 42.23 | ~19.7 g | ~0.63 h |
| `GOG-762` | `PELE_F6_LatPosY_T2_ColE` | `157.2 × 155.55 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 96.97 | ~44.2 g | ~1.36 h |
| `GOG-763` | `PELE_F6_LatPosY_T3_ColD` | `177.2 × 130.62 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 91.00 | ~41.6 g | ~1.28 h |
| `GOG-764` | `PELE_F6_LatPosY_T3_ColE` | `177.2 × 155.55 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 109.40 | ~49.8 g | ~1.53 h |
| `GOG-765` | `PELE_F6_LatPosY_T4_ColD` | `130.62 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 28.65 | ~13.6 g | ~0.44 h |
| `GOG-766` | `PELE_F6_LatPosY_T4_ColE` | `155.55 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 34.44 | ~16.2 g | ~0.52 h |
| `GOG-788` | `PELE_F6_Rear_Painel_T1_ColF` | `179.1 × 171.75 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 121.36 | ~53.4 g | ~1.63 h |
| `GOG-789` | `PELE_F6_Rear_Painel_T1_ColM` | `179.1 × 80.7 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 57.75 | ~26.7 g | ~0.84 h |
| `GOG-790` | `PELE_F6_Rear_Painel_T2_ColF` | `171.75 × 157.2 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 106.52 | ~46.9 g | ~1.44 h |
| `GOG-791` | `PELE_F6_Rear_Painel_T2_ColM` | `157.2 × 80.7 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 50.68 | ~23.5 g | ~0.74 h |
| `GOG-792` | `PELE_F6_Rear_Painel_T2_ColR` | `179.45 × 157.2 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 111.36 | ~49.0 g | ~1.50 h |
| `GOG-793` | `PELE_F6_Rear_Painel_T3_ColF` | `177.2 × 171.75 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 120.07 | ~52.8 g | ~1.62 h |
| `GOG-794` | `PELE_F6_Rear_Painel_T3_ColM` | `177.2 × 80.7 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 57.14 | ~26.5 g | ~0.83 h |
| `GOG-795` | `PELE_F6_Rear_Painel_T4_ColF` | `171.75 × 56.0 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 37.94 | ~17.3 g | ~0.56 h |
| `GOG-796` | `PELE_F6_Rear_Painel_T4_ColM` | `80.7 × 56.0 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 18.01 | ~8.6 g | ~0.30 h |
| `GOG-797` | `PELE_F6_Rear_Painel_T4_ColR` | `179.45 × 56.0 × 4.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 39.66 | ~18.1 g | ~0.58 h |
