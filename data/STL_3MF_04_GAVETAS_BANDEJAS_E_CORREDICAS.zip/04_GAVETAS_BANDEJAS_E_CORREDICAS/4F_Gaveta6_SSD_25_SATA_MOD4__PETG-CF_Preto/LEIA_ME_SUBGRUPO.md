# 4F · Gaveta 6 (SSD 2,5" SATA · Curso -125 mm Traseiro) — Bandeja e Trilhos

- **Propósito / Função**: Extração traseira inferior (-X) para unidade de armazenamento 2,5"
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `9` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `74.2 cm³` · **`~40 g`** (`96 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-573` | `MOD4_Gaveta_SSD25_AbaFront` | `104.0 × 11.5 × 3.8` | 4.54 | ~2.5 g |
| `GOG-574` | `MOD4_Gaveta_SSD25_AbaRear` | `104.0 × 11.5 × 3.2` | 3.83 | ~2.1 g |
| `GOG-575` | `MOD4_Gaveta_SSD25_Bandeja` | `104.0 × 77.8 × 4.0` | 32.25 | ~17.5 g |
| `GOG-606` | `MOD4_Trilho_SSD25_Front` | `151.0 × 19.0 × 7.45` | 5.99 | ~3.2 g |
| `GOG-607` | `MOD4_Trilho_SSD25_Intermed_Front` | `149.0 × 15.5 × 5.7` | 5.19 | ~2.8 g |
| `GOG-608` | `MOD4_Trilho_SSD25_Intermed_Rear` | `149.0 × 15.5 × 5.8` | 5.19 | ~2.8 g |
| `GOG-609` | `MOD4_Trilho_SSD25_Movel_Front` | `145.0 × 11.85 × 3.95` | 5.55 | ~3.0 g |
| `GOG-610` | `MOD4_Trilho_SSD25_Movel_Rear` | `145.0 × 11.85 × 4.05` | 5.70 | ~3.1 g |
| `GOG-611` | `MOD4_Trilho_SSD25_Rear` | `151.0 × 19.0 × 7.55` | 5.99 | ~3.2 g |
