# 4D · [Material Técnico Térmico · 19 Peças] Gaveta 4 e Paredes da Fonte 135 W (até 65 °C) no MOD3 — PC-ABS FR UL94 V-0

- **Propósito / Função**: Bandeja, paredes de segurança elétrica/térmica e trilhos da Fonte de 135 W (100% nos trilhos, 20% nas paredes)
- **Material Recomendado**: `PC-ABS FR / PC-FR UL94 V-0 (Câmara Fechada · Resistente a 65 °C e Chama)`
- **Cor Indicada**: `Preto Técnico FR` (`#262626`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `19` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `181.0 cm³` · **`~181 g`** · **`~9.3 h`** (`214 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-525` | `MOD3_Gaveta_Energia_Bandeja` | `124.6 × 47.0 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 20.50 | ~12.8 g | ~0.64 h |
| `GOG-526` | `MOD3_Parede_Blindagem_UL94_V0_Lateral` | `124.6 × 53.5 × 1.45` | `20% Infill + 3 Perimetros (Sem Suporte)` | 9.67 | ~10.3 g | ~0.52 h |
| `GOG-527` | `MOD3_Presilha_Fonte135W_Front` | `79.85 × 26.0 × 1.6` | `20% Infill + 3 Perimetros (Sem Suporte)` | 3.32 | ~3.4 g | ~0.20 h |
| `GOG-528` | `MOD3_Presilha_Fonte135W_GuiaDir` | `118.1 × 62.85 × 1.9` | `20% Infill + 3 Perimetros (Sem Suporte)` | 14.10 | ~12.6 g | ~0.63 h |
| `GOG-529` | `MOD3_Presilha_Fonte135W_GuiaEsq` | `118.1 × 62.85 × 1.9` | `20% Infill + 3 Perimetros (Sem Suporte)` | 14.10 | ~12.6 g | ~0.63 h |
| `GOG-530` | `MOD3_Presilha_Fonte135W_Rear_Bot` | `26.0 × 25.85 × 1.6` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.07 | ~1.1 g | ~0.09 h |
| `GOG-531` | `MOD3_Presilha_Fonte135W_Rear_Top` | `30.0 × 26.0 × 1.6` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.25 | ~1.3 g | ~0.10 h |
| `GOG-535` | `MOD3_Suporte_Energia_BayCheek_Dir` | `30.5 × 23.5 × 22.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 6.07 | ~6.6 g | ~0.35 h |
| `GOG-536` | `MOD3_Trilho_Fixo_Energia_Front_Transv` | `198.0 × 6.0 × 4.8` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.59 | ~6.1 g | ~0.33 h |
| `GOG-537` | `MOD3_Trilho_Fixo_Energia_Mid_Transv` | `68.0 × 7.0 × 4.8` | `100% Solido + 4 Perimetros (Sem Suporte)` | 2.27 | ~2.5 g | ~0.16 h |
| `GOG-538` | `MOD3_Trilho_Fixo_Energia_Rear_Transv` | `198.0 × 6.0 × 4.8` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.03 | ~4.4 g | ~0.25 h |
| `GOG-539` | `MOD3_Trilho_Fonte135W_Batente_Dir` | `36.5 × 8.35 × 2.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.60 | ~0.7 g | ~0.08 h |
| `GOG-540` | `MOD3_Trilho_Fonte135W_Batente_Esq` | `36.5 × 8.35 × 2.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.60 | ~0.7 g | ~0.08 h |
| `GOG-541` | `MOD3_Trilho_Fonte135W_Fixo_Dir` | `186.0 × 36.5 × 8.35` | `100% Solido + 4 Perimetros (Sem Suporte)` | 13.69 | ~14.9 g | ~0.74 h |
| `GOG-542` | `MOD3_Trilho_Fonte135W_Fixo_Esq` | `186.0 × 36.5 × 8.35` | `100% Solido + 4 Perimetros (Sem Suporte)` | 13.69 | ~14.9 g | ~0.74 h |
| `GOG-543` | `MOD3_Trilho_Fonte135W_Intermed_Dir` | `182.0 × 32.4 × 6.5` | `100% Solido + 4 Perimetros (Sem Suporte)` | 12.14 | ~13.2 g | ~0.66 h |
| `GOG-544` | `MOD3_Trilho_Fonte135W_Intermed_Esq` | `182.0 × 32.4 × 6.5` | `100% Solido + 4 Perimetros (Sem Suporte)` | 12.14 | ~13.2 g | ~0.66 h |
| `GOG-545` | `MOD3_Trilho_Fonte135W_Movel_Dir` | `176.8 × 32.25 × 4.65` | `100% Solido + 4 Perimetros (Sem Suporte)` | 23.07 | ~25.0 g | ~1.22 h |
| `GOG-546` | `MOD3_Trilho_Fonte135W_Movel_Esq` | `176.8 × 32.25 × 4.65` | `100% Solido + 4 Perimetros (Sem Suporte)` | 23.07 | ~25.0 g | ~1.22 h |
