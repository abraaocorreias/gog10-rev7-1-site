# 4C · [Material Técnico Mecânico] Somente Trilhos das Corrediças 0,25 mm e Patins 40 mm — PETG-CF (100% Sólido)

- **Propósito / Função**: Peças de alto esforço mecânico e precisão de deslizamento 0,25 mm (não cortar!)
- **Material Recomendado**: `PETG-CF (Fibra de Carbono · 100% Sólido + 4 Perímetros)`
- **Cor Indicada**: `Preto Fosco Técnico CF` (`#18191C`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `100% Solido + 4 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `38` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `5` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `300.0 cm³` · **`~356 g`** · **`~16.9 h`** (`387 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-518` | `MOD2_Trilho_Fixo_ONT_Dir` | `136.0 × 19.0 × 6.55` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.25 | ~6.2 g | ~0.31 h |
| `GOG-519` | `MOD2_Trilho_Fixo_ONT_Esq` | `136.0 × 19.0 × 6.55` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.25 | ~6.2 g | ~0.31 h |
| `GOG-520` | `MOD2_Trilho_Intermed_ONT_Dir` | `134.0 × 14.85 × 4.9` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.10 | ~4.9 g | ~0.25 h |
| `GOG-521` | `MOD2_Trilho_Intermed_ONT_Esq` | `134.0 × 14.85 × 4.9` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.10 | ~4.9 g | ~0.25 h |
| `GOG-522` | `MOD2_Trilho_Transversal_Apoio_Extra` | `193.8 × 6.0 × 3.45` | `100% Solido + 4 Perimetros (Sem Suporte)` | 3.88 | ~4.6 g | ~0.24 h |
| `GOG-523` | `MOD2_Trilho_Transversal_Apoio_Front` | `193.8 × 8.0 × 3.45` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.22 | ~6.2 g | ~0.31 h |
| `GOG-524` | `MOD2_Trilho_Transversal_Apoio_Rear` | `193.8 × 8.0 × 3.45` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.30 | ~6.3 g | ~0.31 h |
| `GOG-547` | `MOD3_Trilho_iClamper_Dir_Front` | `159.8 × 41.4 × 6.6` | `100% Solido + 4 Perimetros (Sem Suporte)` | 14.67 | ~17.4 g | ~0.79 h |
| `GOG-548` | `MOD3_Trilho_iClamper_Dir_Rear` | `125.8 × 41.4 × 9.2` | `100% Solido + 4 Perimetros (Sem Suporte)` | 11.57 | ~13.7 g | ~0.63 h |
| `GOG-549` | `MOD3_Trilho_iClamper_Esq_Front` | `159.8 × 41.4 × 6.6` | `100% Solido + 4 Perimetros (Sem Suporte)` | 14.67 | ~17.4 g | ~0.79 h |
| `GOG-550` | `MOD3_Trilho_iClamper_Esq_Rear` | `125.8 × 41.4 × 9.3` | `100% Solido + 4 Perimetros (Sem Suporte)` | 11.57 | ~13.7 g | ~0.63 h |
| `GOG-551` | `MOD3_Trilho_iClamper_Intermed_Dir` | `201.5 × 37.3 × 7.15` | `100% Solido + 4 Perimetros (Sem Suporte)` | 17.09 | ~20.3 g | ~0.91 h |
| `GOG-552` | `MOD3_Trilho_iClamper_Intermed_Esq` | `201.5 × 37.3 × 7.25` | `100% Solido + 4 Perimetros (Sem Suporte)` | 17.09 | ~20.3 g | ~0.91 h |
| `GOG-553` | `MOD3_Trilho_iClamper_Movel_Dir_Front` | `137.3 × 35.58 × 5.1` | `100% Solido + 4 Perimetros (Sem Suporte)` | 22.41 | ~26.6 g | ~1.19 h |
| `GOG-554` | `MOD3_Trilho_iClamper_Movel_Dir_Rear` | `137.3 × 33.85 × 5.1` | `100% Solido + 4 Perimetros (Sem Suporte)` | 22.40 | ~26.6 g | ~1.18 h |
| `GOG-555` | `MOD3_Trilho_iClamper_Movel_Esq_Front` | `137.3 × 35.58 × 5.2` | `100% Solido + 4 Perimetros (Sem Suporte)` | 22.87 | ~27.1 g | ~1.21 h |
| `GOG-556` | `MOD3_Trilho_iClamper_Movel_Esq_Rear` | `137.3 × 33.85 × 5.2` | `100% Solido + 4 Perimetros (Sem Suporte)` | 22.86 | ~27.1 g | ~1.21 h |
| `GOG-557` | `MOD3_Trilho_iClamper_Transv_Front` | `61.6 × 6.0 × 4.3` | `100% Solido + 4 Perimetros (Sem Suporte)` | 1.58 | ~1.9 g | ~0.12 h |
| `GOG-558` | `MOD3_Trilho_iClamper_Transv_Mid` | `67.8 × 12.0 × 4.3` | `100% Solido + 4 Perimetros (Sem Suporte)` | 3.49 | ~4.1 g | ~0.22 h |
| `GOG-559` | `MOD3_Trilho_iClamper_Transv_Rear` | `61.6 × 6.7 × 4.3` | `100% Solido + 4 Perimetros (Sem Suporte)` | 1.67 | ~2.0 g | ~0.13 h |
| `GOG-581` | `MOD4_Patim_Cassete_Front` | `40.0 × 7.2 × 2.45` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.71 | ~0.8 g | ~0.08 h |
| `GOG-582` | `MOD4_Patim_Cassete_Rear` | `40.0 × 3.95 × 2.05` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.32 | ~0.4 g | ~0.08 h |
| `GOG-592` | `MOD4_Trilho_Fixo_Cassete_Front_Dir` | `45.0 × 13.8 × 4.25` | `100% Solido + 4 Perimetros (Sem Suporte)` | 1.74 | ~2.1 g | ~0.13 h |
| `GOG-593` | `MOD4_Trilho_Fixo_Cassete_Front_Esq` | `127.0 × 13.8 × 4.25` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.96 | ~5.9 g | ~0.29 h |
| `GOG-594` | `MOD4_Trilho_Fixo_Cassete_Rear_Dir` | `45.0 × 5.5 × 3.55` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.46 | ~0.5 g | ~0.08 h |
| `GOG-595` | `MOD4_Trilho_Fixo_Cassete_Rear_Esq` | `145.5 × 5.5 × 3.55` | `100% Solido + 4 Perimetros (Sem Suporte)` | 1.50 | ~1.8 g | ~0.12 h |
| `GOG-596` | `MOD4_Trilho_Hub_Dir` | `140.5 × 25.9 × 6.65` | `100% Solido + 4 Perimetros (Sem Suporte)` | 6.52 | ~7.7 g | ~0.37 h |
| `GOG-597` | `MOD4_Trilho_Hub_Esq` | `140.5 × 25.9 × 6.65` | `100% Solido + 4 Perimetros (Sem Suporte)` | 6.52 | ~7.7 g | ~0.37 h |
| `GOG-598` | `MOD4_Trilho_Hub_Intermed_Dir` | `138.5 × 22.4 × 5.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.74 | ~6.8 g | ~0.33 h |
| `GOG-599` | `MOD4_Trilho_Hub_Intermed_Esq` | `138.5 × 22.4 × 5.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.74 | ~6.8 g | ~0.33 h |
| `GOG-600` | `MOD4_Trilho_Hub_Movel_Dir` | `134.5 × 19.15 × 3.35` | `100% Solido + 4 Perimetros (Sem Suporte)` | 7.56 | ~9.0 g | ~0.43 h |
| `GOG-601` | `MOD4_Trilho_Hub_Movel_Esq` | `134.5 × 19.15 × 3.35` | `100% Solido + 4 Perimetros (Sem Suporte)` | 7.56 | ~9.0 g | ~0.43 h |
| `GOG-606` | `MOD4_Trilho_SSD25_Front` | `151.0 × 19.0 × 7.45` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.99 | ~7.1 g | ~0.35 h |
| `GOG-607` | `MOD4_Trilho_SSD25_Intermed_Front` | `149.0 × 15.5 × 5.7` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.19 | ~6.2 g | ~0.31 h |
| `GOG-608` | `MOD4_Trilho_SSD25_Intermed_Rear` | `149.0 × 15.5 × 5.8` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.19 | ~6.2 g | ~0.31 h |
| `GOG-609` | `MOD4_Trilho_SSD25_Movel_Front` | `145.0 × 11.85 × 3.95` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.55 | ~6.6 g | ~0.32 h |
| `GOG-610` | `MOD4_Trilho_SSD25_Movel_Rear` | `145.0 × 11.85 × 4.05` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.70 | ~6.8 g | ~0.33 h |
| `GOG-611` | `MOD4_Trilho_SSD25_Rear` | `151.0 × 19.0 × 7.55` | `100% Solido + 4 Perimetros (Sem Suporte)` | 5.99 | ~7.1 g | ~0.35 h |
