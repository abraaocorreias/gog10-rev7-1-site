# 4B · Gaveta 2 (ONT Fibra FD511G · Curso +115 mm) — Bandeja e Corrediças

- **Propósito / Função**: Bandeja deslizante lateral (+Y) e trilhos 3 estágios da ONT óptica
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `10` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `58.7 cm³` · **`~32 g`** (`76 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-515` | `MOD2_Gaveta_ONT_Abas_Retencao_Dir` | `118.0 × 12.85 × 3.25` | 3.77 | ~2.0 g |
| `GOG-516` | `MOD2_Gaveta_ONT_Abas_Retencao_Esq` | `118.0 × 12.85 × 3.25` | 3.77 | ~2.0 g |
| `GOG-517` | `MOD2_Gaveta_ONT_Bandeja` | `84.0 × 78.0 × 2.75` | 18.02 | ~9.8 g |
| `GOG-518` | `MOD2_Trilho_Fixo_ONT_Dir` | `136.0 × 19.0 × 6.55` | 5.25 | ~2.8 g |
| `GOG-519` | `MOD2_Trilho_Fixo_ONT_Esq` | `136.0 × 19.0 × 6.55` | 5.25 | ~2.8 g |
| `GOG-520` | `MOD2_Trilho_Intermed_ONT_Dir` | `134.0 × 14.85 × 4.9` | 4.10 | ~2.2 g |
| `GOG-521` | `MOD2_Trilho_Intermed_ONT_Esq` | `134.0 × 14.85 × 4.9` | 4.10 | ~2.2 g |
| `GOG-522` | `MOD2_Trilho_Transversal_Apoio_Extra` | `193.8 × 6.0 × 3.45` | 3.88 | ~2.1 g |
| `GOG-523` | `MOD2_Trilho_Transversal_Apoio_Front` | `193.8 × 8.0 × 3.45` | 5.22 | ~2.8 g |
| `GOG-524` | `MOD2_Trilho_Transversal_Apoio_Rear` | `193.8 × 8.0 × 3.45` | 5.30 | ~2.9 g |
