# 4A · [Material Técnico RF · 13 Peças] Gaveta 1 (Roteador MR30G perto das 4 Antenas) — PC Puro Sem Carga ou PETG Puro Sem Fibra

- **Propósito / Função**: Bandeja e corrediças telescópicas 3 estágios do roteador (100% nos trilhos, 20% na bandeja)
- **Material Recomendado**: `PC Puro Sem Carga (ou PETG Puro Sem Fibra — Isento de Carbono p/ RF)`
- **Cor Indicada**: `Incolor Natural ou Preto Sem Carbono` (`#2D3748`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `13` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `115.9 cm³` · **`~114 g`** · **`~5.9 h`** (`139 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-502` | `MOD1_Bandeja_MR30G_Base` | `161.8 × 133.75 × 2.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 47.61 | ~38.7 g | ~1.83 h |
| `GOG-503` | `MOD1_Corredica_Bandeja_Front` | `177.7 × 29.32 × 2.4` | `100% Solido + 4 Perimetros (Sem Suporte)` | 10.65 | ~11.8 g | ~0.58 h |
| `GOG-504` | `MOD1_Corredica_Bandeja_Rear` | `177.7 × 29.32 × 3.05` | `100% Solido + 4 Perimetros (Sem Suporte)` | 13.45 | ~14.8 g | ~0.73 h |
| `GOG-505` | `MOD1_Corredica_Batente_Front` | `33.1 × 4.3 × 1.9` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.27 | ~0.3 g | ~0.08 h |
| `GOG-506` | `MOD1_Corredica_Batente_Rear` | `33.1 × 4.2 × 1.9` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.26 | ~0.3 g | ~0.08 h |
| `GOG-507` | `MOD1_Corredica_Fixa_Front` | `188.0 × 33.1 × 16.4` | `100% Solido + 4 Perimetros (Sem Suporte)` | 12.26 | ~13.5 g | ~0.67 h |
| `GOG-508` | `MOD1_Corredica_Fixa_Rear` | `188.0 × 33.1 × 13.6` | `100% Solido + 4 Perimetros (Sem Suporte)` | 11.90 | ~13.1 g | ~0.65 h |
| `GOG-509` | `MOD1_Corredica_Intermed_Front` | `185.0 × 29.0 × 4.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 8.61 | ~9.5 g | ~0.48 h |
| `GOG-510` | `MOD1_Corredica_Intermed_Rear` | `185.0 × 29.0 × 4.65` | `100% Solido + 4 Perimetros (Sem Suporte)` | 9.09 | ~10.0 g | ~0.50 h |
| `GOG-511` | `MOD1_Pilar_Selo_Front` | `37.45 × 4.8 × 4.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 0.80 | ~0.7 g | ~0.08 h |
| `GOG-512` | `MOD1_Pilar_Selo_Rear` | `37.45 × 4.8 × 4.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 0.80 | ~0.7 g | ~0.08 h |
| `GOG-513` | `MOD1_Trava_PETG_Snap_Front` | `6.0 × 4.3 × 3.8` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.10 | ~0.1 g | ~0.08 h |
| `GOG-514` | `MOD1_Trava_PETG_Snap_Rear` | `6.0 × 4.2 × 3.8` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.09 | ~0.1 g | ~0.08 h |
