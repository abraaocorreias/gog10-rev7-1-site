# 04 · Sistema das 7 Gavetas, Bandejas de Equipamentos e Corrediças Telescópicas

**Objetivo construtivo**: As 7 gavetas deslizantes independentes (Roteador MR30G, ONT Fibra, Filtro iCLAMPER, Fonte 135 W, Hub USB-C, SSD 2,5" e Cassete da Placa-Mãe LA-L161P) com seus trilhos de 3 estágios (C1 Fixo, C2 Intermediário e T3 Móvel).

**Como montar este grupo**: Passo 4 da montagem: Parafuse os trilhos fixos (C1) nas colunas/pisos de cada andar. Encaixe os perfis intermediários (C2) nos canais de 0,25 mm (sem graxa espessa; usar PTFE seco se desejar) e deslize as bandejas com seus trilhos móveis (T3) até engatar no dente de batente positivo. Importante: a Gaveta 1 (4A - Roteador MR30G) deve ser impressa em Policarbonato (PC) puro sem fibra de carbono para não atenuar as 4 antenas.

**Vistas de referência no site (`https://abraaocorreias.github.io/gog10-rev7-1-site/`)**: `V11, V12, V13, V14, V16, V17, V28, V29`

## Subgrupos de Peças, Materiais e Cores:

| Subpasta | Material | Cor | Peças | Bandejas 202×202 | Volume | Peso Estimado |
|---|---|---|---:|---:|---:|---:|
| `4A_Gaveta1_Roteador_MR30G_MOD1__PC-Puro-Sem-Carga` | Policarbonato (PC) Puro Sem Carga (Obrigatório p/ RF) | Preto ou Incolor Natural (Sem Carbono) | 14 | 2 | 133.0 cm³ | **~67 g** |
| `4B_Gaveta2_ONT_Fibra_MOD2__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 10 | 2 | 58.7 cm³ | **~32 g** |
| `4C_Gaveta3_Filtro_iCLAMPER_MOD3__PC-FR_UL94-V0_Preto` | PC-FR / PC-ABS FR UL94 V-0 (Retardante de Chama) | Preto Técnico FR | 16 | 3 | 219.1 cm³ | **~108 g** |
| `4D_Gaveta4_Fonte_135W_e_Blindagem_MOD3__PC-ABS-FR_Preto` | PC-ABS FR UL94 V-0 (Alta Temp. / Retardante de Chama) | Preto Técnico FR | 19 | 3 | 181.0 cm³ | **~90 g** |
| `4E_Gaveta5_Hub_USBC_MOD4__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 12 | 2 | 81.8 cm³ | **~44 g** |
| `4F_Gaveta6_SSD_25_SATA_MOD4__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 9 | 2 | 74.2 cm³ | **~40 g** |
| `4G_Gaveta7_Cassete_PlacaMae_VPS_MOD4__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 26 | 3 | 285.8 cm³ | **~155 g** |
