# 04 · Sistema das 7 Gavetas (Bandejas em PETG Comum Separadas dos Trilhos em PETG-CF / PC-ABS FR)

**Objetivo construtivo**: Para cortar o custo pela metade sem perder rigidez nem folga de 0,25 mm, separamos as BANDEJAS/CAIXAS das gavetas MOD2 e MOD4 (4B, impressas em PETG Comum ou PLA+ com 20% infill e 3 perimetros) dos TRILHOS/CORREDICAS/PATINS (4C, 31 pecas impressas em PETG-CF 100% solido). As gavetas quentes do MOD3 (4D, Fonte 135 W ate 65 °C e iCLAMPER) usam PC-ABS FR, e a Gaveta 1 do Roteador (4A, perto das antenas) usa PC Puro ou PETG Puro Sem Fibra.

**Como montar este grupo**: Passo 4: Parafuse os trilhos fixos C1 nas colunas/pisos, insira os perfis intermediarios C2 no canal de 0,25 mm e deslize as bandejas com os trilhos moveis T3 ate travar no batente positivo.

| Subpasta | Material | Fatiamento | Peças | Bandejas 202×202 | Peso Leve | Tempo Estimado |
|---|---|---|---:|---:|---:|---:|
| `4A_Gaveta1_Roteador_MR30G_ZonaAntenas__PC-Puro_ou_PETG-Sem-Fibra` | PC Puro Sem Carga (ou PETG Puro Sem Fibra — Isento de Carbono p/ RF) | `20% Infill + 3 Perimetros (Sem Suporte)` | 13 | 2 | **~114 g** | **~5.9 h** |
| `4B_Bandejas_e_Caixas_Gavetas_MOD2_MOD3_MOD4__PETG-Comum_20Pct_3Perim` | PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 36 | 4 | **~292 g** | **~10.3 h** |
| `4C_Trilhos_Corredicas_e_Patins_Gavetas__PETG-CF_100Pct_Solido` | PETG-CF (Fibra de Carbono · 100% Sólido + 4 Perímetros) | `100% Solido + 4 Perimetros (Sem Suporte)` | 38 | 5 | **~356 g** | **~16.9 h** |
| `4D_Gaveta4_MOD3_Fonte135W_Ate65C_e_Trilhos__PC-ABS-FR` | PC-ABS FR / PC-FR UL94 V-0 (Câmara Fechada · Resistente a 65 °C e Chama) | `20% Infill + 3 Perimetros (Sem Suporte)` | 19 | 3 | **~181 g** | **~9.3 h** |
