# 4E · Gaveta 5 (Hub USB-C · Curso -125 mm Traseiro) — Bandeja, Pilares e Trilhos

- **Propósito / Função**: Extração traseira superior (-X) acessível pela porta clique T3
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `12` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `81.8 cm³` · **`~44 g`** (`106 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-571` | `MOD4_Gaveta_Hub_USBC_AbaBack` | `45.2 × 16.0 × 4.0` | 2.89 | ~1.6 g |
| `GOG-572` | `MOD4_Gaveta_Hub_USBC_Bandeja` | `120.0 × 45.2 × 4.0` | 21.61 | ~11.7 g |
| `GOG-596` | `MOD4_Trilho_Hub_Dir` | `140.5 × 25.9 × 6.65` | 6.52 | ~3.5 g |
| `GOG-597` | `MOD4_Trilho_Hub_Esq` | `140.5 × 25.9 × 6.65` | 6.52 | ~3.5 g |
| `GOG-598` | `MOD4_Trilho_Hub_Intermed_Dir` | `138.5 × 22.4 × 5.0` | 5.74 | ~3.1 g |
| `GOG-599` | `MOD4_Trilho_Hub_Intermed_Esq` | `138.5 × 22.4 × 5.0` | 5.74 | ~3.1 g |
| `GOG-600` | `MOD4_Trilho_Hub_Movel_Dir` | `134.5 × 19.15 × 3.35` | 7.56 | ~4.1 g |
| `GOG-601` | `MOD4_Trilho_Hub_Movel_Esq` | `134.5 × 19.15 × 3.35` | 7.56 | ~4.1 g |
| `GOG-602` | `MOD4_Trilho_Hub_PilarFront_Dir` | `27.8 × 16.0 × 10.0` | 4.45 | ~2.4 g |
| `GOG-603` | `MOD4_Trilho_Hub_PilarFront_Esq` | `27.8 × 16.0 × 10.0` | 4.45 | ~2.4 g |
| `GOG-604` | `MOD4_Trilho_Hub_PilarRear_Dir` | `27.8 × 16.0 × 10.0` | 4.39 | ~2.4 g |
| `GOG-605` | `MOD4_Trilho_Hub_PilarRear_Esq` | `27.8 × 16.0 × 10.0` | 4.39 | ~2.4 g |
