# 4B · Bandejas, Caixas, Frentes e Suportes das Gavetas (Sem os Trilhos) — PETG Comum ou PLA+ (20% Infill · 3 Perímetros)

- **Propósito / Função**: Corpos das bandejas ONT, Hub USB-C, SSD 2,5", Cassete da Placa-Mãe e Berço da Bateria
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `36` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `4` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `436.7 cm³` · **`~292 g`** · **`~10.3 h`** (`546 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-515` | `MOD2_Gaveta_ONT_Abas_Retencao_Dir` | `118.0 × 12.85 × 3.25` | `20% Infill + 3 Perimetros (Sem Suporte)` | 3.77 | ~2.9 g | ~0.13 h |
| `GOG-516` | `MOD2_Gaveta_ONT_Abas_Retencao_Esq` | `118.0 × 12.85 × 3.25` | `20% Infill + 3 Perimetros (Sem Suporte)` | 3.77 | ~2.9 g | ~0.13 h |
| `GOG-517` | `MOD2_Gaveta_ONT_Bandeja` | `84.0 × 78.0 × 2.75` | `20% Infill + 3 Perimetros (Sem Suporte)` | 18.02 | ~13.5 g | ~0.44 h |
| `GOG-532` | `MOD3_SubGaveta_iClamper_Front` | `137.4 × 42.6 × 2.55` | `20% Infill + 3 Perimetros (Sem Suporte)` | 14.93 | ~11.8 g | ~0.39 h |
| `GOG-533` | `MOD3_SubGaveta_iClamper_Rear` | `137.4 × 42.6 × 2.55` | `20% Infill + 3 Perimetros (Sem Suporte)` | 14.93 | ~11.8 g | ~0.39 h |
| `GOG-534` | `MOD3_SubGaveta_iClamper_TalaCentral` | `63.0 × 42.5 × 2.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 5.34 | ~4.9 g | ~0.19 h |
| `GOG-560` | `MOD4_Berco_Bateria_Front_114mm` | `114.0 × 15.0 × 13.7` | `20% Infill + 3 Perimetros (Sem Suporte)` | 15.91 | ~8.2 g | ~0.28 h |
| `GOG-561` | `MOD4_Berco_Bateria_Rear_102mm` | `102.0 × 15.0 × 13.7` | `20% Infill + 3 Perimetros (Sem Suporte)` | 14.23 | ~7.3 g | ~0.26 h |
| `GOG-562` | `MOD4_Bossa_Standoff_H1` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-563` | `MOD4_Bossa_Standoff_H11` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-564` | `MOD4_Bossa_Standoff_H15` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-565` | `MOD4_Bossa_Standoff_H16` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-566` | `MOD4_Bossa_Standoff_H21` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-567` | `MOD4_Bossa_Standoff_H4` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-568` | `MOD4_Bossa_Standoff_H5` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-569` | `MOD4_Bossa_Standoff_H8` | `14.3 × 6.0 × 6.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 0.51 | ~0.6 g | ~0.08 h |
| `GOG-571` | `MOD4_Gaveta_Hub_USBC_AbaBack` | `45.2 × 16.0 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 2.89 | ~2.1 g | ~0.10 h |
| `GOG-572` | `MOD4_Gaveta_Hub_USBC_Bandeja` | `120.0 × 45.2 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 21.61 | ~13.4 g | ~0.44 h |
| `GOG-573` | `MOD4_Gaveta_SSD25_AbaFront` | `104.0 × 11.5 × 3.8` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.54 | ~3.4 g | ~0.14 h |
| `GOG-574` | `MOD4_Gaveta_SSD25_AbaRear` | `104.0 × 11.5 × 3.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 3.83 | ~3.0 g | ~0.13 h |
| `GOG-575` | `MOD4_Gaveta_SSD25_Bandeja` | `104.0 × 77.8 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 32.25 | ~19.6 g | ~0.62 h |
| `GOG-576` | `MOD4_LEGO_Cassete_VPS_Frontal_114x164mm` | `157.0 × 113.8 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 85.13 | ~45.5 g | ~1.39 h |
| `GOG-577` | `MOD4_LEGO_Cassete_VPS_Traseiro_142x164mm` | `157.0 × 141.8 × 5.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 107.39 | ~57.0 g | ~1.73 h |
| `GOG-578` | `MOD4_Orelha_H15` | `13.2 × 12.0 × 7.6` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.08 | ~0.8 g | ~0.08 h |
| `GOG-579` | `MOD4_Orelha_H1_H5` | `39.0 × 15.5 × 7.6` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.38 | ~2.6 g | ~0.12 h |
| `GOG-580` | `MOD4_Orelha_H4_H11` | `20.0 × 13.2 × 7.6` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.76 | ~1.2 g | ~0.08 h |
| `GOG-583` | `MOD4_Ponte_Standoff_Suporte_PCB_Front` | `128.2 × 20.95 × 6.35` | `100% Solido + 4 Perimetros (Sem Suporte)` | 17.05 | ~19.6 g | ~0.62 h |
| `GOG-584` | `MOD4_Ponte_Standoff_Suporte_PCB_Rear` | `128.2 × 20.95 × 6.35` | `100% Solido + 4 Perimetros (Sem Suporte)` | 16.79 | ~19.3 g | ~0.61 h |
| `GOG-586` | `MOD4_Suporte_SSD2_Apoio` | `31.6 × 13.0 × 4.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.73 | ~1.3 g | ~0.08 h |
| `GOG-587` | `MOD4_Suporte_SSD2_Braco` | `59.2 × 10.5 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 4.97 | ~3.2 g | ~0.13 h |
| `GOG-588` | `MOD4_Suporte_SSD2_Sela` | `15.5 × 14.3 × 7.6` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.51 | ~1.0 g | ~0.08 h |
| `GOG-602` | `MOD4_Trilho_Hub_PilarFront_Dir` | `27.8 × 16.0 × 10.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.45 | ~5.1 g | ~0.19 h |
| `GOG-603` | `MOD4_Trilho_Hub_PilarFront_Esq` | `27.8 × 16.0 × 10.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.45 | ~5.1 g | ~0.19 h |
| `GOG-604` | `MOD4_Trilho_Hub_PilarRear_Dir` | `27.8 × 16.0 × 10.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.39 | ~5.0 g | ~0.19 h |
| `GOG-605` | `MOD4_Trilho_Hub_PilarRear_Esq` | `27.8 × 16.0 × 10.0` | `100% Solido + 4 Perimetros (Sem Suporte)` | 4.39 | ~5.0 g | ~0.19 h |
| `GOG-726` | `PELE_F6_Baia_FrenteGaveta_MR30G` | `173.9 × 23.5 × 4.2` | `20% Infill + 3 Perimetros (Sem Suporte)` | 17.11 | ~10.8 g | ~0.36 h |
