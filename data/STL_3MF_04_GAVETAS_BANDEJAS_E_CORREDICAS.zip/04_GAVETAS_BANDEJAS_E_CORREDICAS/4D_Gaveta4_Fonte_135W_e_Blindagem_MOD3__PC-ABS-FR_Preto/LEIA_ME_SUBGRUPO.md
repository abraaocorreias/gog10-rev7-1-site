# 4D · Gaveta 4 (Fonte Lenovo 135 W · Curso -150 mm) — Bandeja, Blindagem Térmica e Trilhos

- **Propósito / Função**: Bandeja retrátil (-Y), paredes de isolamento térmico e trilhos da fonte 135 W
- **Material Recomendado**: `PC-ABS FR UL94 V-0 (Alta Temp. / Retardante de Chama)`
- **Cor Indicada**: `Preto Técnico FR` (`#262626`)
- **Quantidade de Peças Imprimíveis**: `19` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Estimado**: `181.0 cm³` · **`~90 g`** (`214 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-525` | `MOD3_Gaveta_Energia_Bandeja` | `124.6 × 47.0 × 3.5` | 20.50 | ~10.2 g |
| `GOG-526` | `MOD3_Parede_Blindagem_UL94_V0_Lateral` | `124.6 × 53.5 × 1.45` | 9.67 | ~4.8 g |
| `GOG-527` | `MOD3_Presilha_Fonte135W_Front` | `79.85 × 26.0 × 1.6` | 3.32 | ~1.6 g |
| `GOG-528` | `MOD3_Presilha_Fonte135W_GuiaDir` | `118.1 × 62.85 × 1.9` | 14.10 | ~7.0 g |
| `GOG-529` | `MOD3_Presilha_Fonte135W_GuiaEsq` | `118.1 × 62.85 × 1.9` | 14.10 | ~7.0 g |
| `GOG-530` | `MOD3_Presilha_Fonte135W_Rear_Bot` | `26.0 × 25.85 × 1.6` | 1.07 | ~0.5 g |
| `GOG-531` | `MOD3_Presilha_Fonte135W_Rear_Top` | `30.0 × 26.0 × 1.6` | 1.25 | ~0.6 g |
| `GOG-535` | `MOD3_Suporte_Energia_BayCheek_Dir` | `30.5 × 23.5 × 22.0` | 6.07 | ~3.0 g |
| `GOG-536` | `MOD3_Trilho_Fixo_Energia_Front_Transv` | `198.0 × 6.0 × 4.8` | 5.59 | ~2.8 g |
| `GOG-537` | `MOD3_Trilho_Fixo_Energia_Mid_Transv` | `68.0 × 7.0 × 4.8` | 2.27 | ~1.1 g |
| `GOG-538` | `MOD3_Trilho_Fixo_Energia_Rear_Transv` | `198.0 × 6.0 × 4.8` | 4.03 | ~2.0 g |
| `GOG-539` | `MOD3_Trilho_Fonte135W_Batente_Dir` | `36.5 × 8.35 × 2.0` | 0.60 | ~0.3 g |
| `GOG-540` | `MOD3_Trilho_Fonte135W_Batente_Esq` | `36.5 × 8.35 × 2.0` | 0.60 | ~0.3 g |
| `GOG-541` | `MOD3_Trilho_Fonte135W_Fixo_Dir` | `186.0 × 36.5 × 8.35` | 13.69 | ~6.8 g |
| `GOG-542` | `MOD3_Trilho_Fonte135W_Fixo_Esq` | `186.0 × 36.5 × 8.35` | 13.69 | ~6.8 g |
| `GOG-543` | `MOD3_Trilho_Fonte135W_Intermed_Dir` | `182.0 × 32.4 × 6.5` | 12.14 | ~6.0 g |
| `GOG-544` | `MOD3_Trilho_Fonte135W_Intermed_Esq` | `182.0 × 32.4 × 6.5` | 12.14 | ~6.0 g |
| `GOG-545` | `MOD3_Trilho_Fonte135W_Movel_Dir` | `176.8 × 32.25 × 4.65` | 23.07 | ~11.4 g |
| `GOG-546` | `MOD3_Trilho_Fonte135W_Movel_Esq` | `176.8 × 32.25 × 4.65` | 23.07 | ~11.4 g |
