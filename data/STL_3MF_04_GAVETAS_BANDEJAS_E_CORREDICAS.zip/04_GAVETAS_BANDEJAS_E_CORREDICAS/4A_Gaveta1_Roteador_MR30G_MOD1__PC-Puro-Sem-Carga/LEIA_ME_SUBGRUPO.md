# 4A · Gaveta 1 (Roteador MR30G · Curso +125 mm) — Bandeja, Corrediças C1/C2/T3 e Frente

- **Propósito / Função**: Bandeja e corrediças telescópicas 3 estágios do roteador (isento de carbono p/ RF)
- **Material Recomendado**: `Policarbonato (PC) Puro Sem Carga (Obrigatório p/ RF)`
- **Cor Indicada**: `Preto ou Incolor Natural (Sem Carbono)` (`#2D3748`)
- **Quantidade de Peças Imprimíveis**: `14` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `133.0 cm³` · **`~67 g`** (`160 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-502` | `MOD1_Bandeja_MR30G_Base` | `161.8 × 133.75 × 2.2` | 47.61 | ~24.0 g |
| `GOG-503` | `MOD1_Corredica_Bandeja_Front` | `177.7 × 29.32 × 2.4` | 10.65 | ~5.4 g |
| `GOG-504` | `MOD1_Corredica_Bandeja_Rear` | `177.7 × 29.32 × 3.05` | 13.45 | ~6.8 g |
| `GOG-505` | `MOD1_Corredica_Batente_Front` | `33.1 × 4.3 × 1.9` | 0.27 | ~0.1 g |
| `GOG-506` | `MOD1_Corredica_Batente_Rear` | `33.1 × 4.2 × 1.9` | 0.26 | ~0.1 g |
| `GOG-507` | `MOD1_Corredica_Fixa_Front` | `188.0 × 33.1 × 16.4` | 12.26 | ~6.2 g |
| `GOG-508` | `MOD1_Corredica_Fixa_Rear` | `188.0 × 33.1 × 13.6` | 11.90 | ~6.0 g |
| `GOG-509` | `MOD1_Corredica_Intermed_Front` | `185.0 × 29.0 × 4.0` | 8.61 | ~4.3 g |
| `GOG-510` | `MOD1_Corredica_Intermed_Rear` | `185.0 × 29.0 × 4.65` | 9.09 | ~4.6 g |
| `GOG-511` | `MOD1_Pilar_Selo_Front` | `37.45 × 4.8 × 4.5` | 0.80 | ~0.4 g |
| `GOG-512` | `MOD1_Pilar_Selo_Rear` | `37.45 × 4.8 × 4.5` | 0.80 | ~0.4 g |
| `GOG-513` | `MOD1_Trava_PETG_Snap_Front` | `6.0 × 4.3 × 3.8` | 0.10 | ~0.0 g |
| `GOG-514` | `MOD1_Trava_PETG_Snap_Rear` | `6.0 × 4.2 × 3.8` | 0.09 | ~0.0 g |
| `GOG-726` | `PELE_F6_Baia_FrenteGaveta_MR30G` | `173.9 × 23.5 × 4.2` | 17.11 | ~8.9 g |
