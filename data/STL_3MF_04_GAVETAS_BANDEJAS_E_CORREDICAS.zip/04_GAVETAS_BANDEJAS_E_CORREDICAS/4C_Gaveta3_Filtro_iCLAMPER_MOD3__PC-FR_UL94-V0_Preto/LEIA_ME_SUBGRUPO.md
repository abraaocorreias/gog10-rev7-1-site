# 4C · Gaveta 3 (Filtro iCLAMPER + 3 Fontes · Curso +200 mm) — Bandeja Bipartida e Trilhos

- **Propósito / Função**: Gaveta de maior curso (+200 mm) para régua iCLAMPER e fontes AC/DC
- **Material Recomendado**: `PC-FR / PC-ABS FR UL94 V-0 (Retardante de Chama)`
- **Cor Indicada**: `Preto Técnico FR` (`#262626`)
- **Quantidade de Peças Imprimíveis**: `16` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Estimado**: `219.1 cm³` · **`~108 g`** (`259 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-532` | `MOD3_SubGaveta_iClamper_Front` | `137.4 × 42.6 × 2.55` | 14.93 | ~7.4 g |
| `GOG-533` | `MOD3_SubGaveta_iClamper_Rear` | `137.4 × 42.6 × 2.55` | 14.93 | ~7.4 g |
| `GOG-534` | `MOD3_SubGaveta_iClamper_TalaCentral` | `63.0 × 42.5 × 2.0` | 5.34 | ~2.6 g |
| `GOG-547` | `MOD3_Trilho_iClamper_Dir_Front` | `159.8 × 41.4 × 6.6` | 14.67 | ~7.3 g |
| `GOG-548` | `MOD3_Trilho_iClamper_Dir_Rear` | `125.8 × 41.4 × 9.2` | 11.57 | ~5.7 g |
| `GOG-549` | `MOD3_Trilho_iClamper_Esq_Front` | `159.8 × 41.4 × 6.6` | 14.67 | ~7.3 g |
| `GOG-550` | `MOD3_Trilho_iClamper_Esq_Rear` | `125.8 × 41.4 × 9.3` | 11.57 | ~5.7 g |
| `GOG-551` | `MOD3_Trilho_iClamper_Intermed_Dir` | `201.5 × 37.3 × 7.15` | 17.09 | ~8.5 g |
| `GOG-552` | `MOD3_Trilho_iClamper_Intermed_Esq` | `201.5 × 37.3 × 7.25` | 17.09 | ~8.5 g |
| `GOG-553` | `MOD3_Trilho_iClamper_Movel_Dir_Front` | `137.3 × 35.58 × 5.1` | 22.41 | ~11.1 g |
| `GOG-554` | `MOD3_Trilho_iClamper_Movel_Dir_Rear` | `137.3 × 33.85 × 5.1` | 22.40 | ~11.1 g |
| `GOG-555` | `MOD3_Trilho_iClamper_Movel_Esq_Front` | `137.3 × 35.58 × 5.2` | 22.87 | ~11.3 g |
| `GOG-556` | `MOD3_Trilho_iClamper_Movel_Esq_Rear` | `137.3 × 33.85 × 5.2` | 22.86 | ~11.3 g |
| `GOG-557` | `MOD3_Trilho_iClamper_Transv_Front` | `61.6 × 6.0 × 4.3` | 1.58 | ~0.8 g |
| `GOG-558` | `MOD3_Trilho_iClamper_Transv_Mid` | `67.8 × 12.0 × 4.3` | 3.49 | ~1.7 g |
| `GOG-559` | `MOD3_Trilho_iClamper_Transv_Rear` | `61.6 × 6.7 × 4.3` | 1.67 | ~0.8 g |
