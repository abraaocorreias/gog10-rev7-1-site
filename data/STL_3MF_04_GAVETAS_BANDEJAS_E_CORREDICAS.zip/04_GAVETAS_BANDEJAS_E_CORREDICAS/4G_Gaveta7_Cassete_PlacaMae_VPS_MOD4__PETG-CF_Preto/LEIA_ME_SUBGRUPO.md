# 4G · Gaveta 7 (Cassete Vertical da Placa-Mãe LA-L161P · Curso -120 mm) — Cassete, Patins 40 mm, Berço Bateria e Standoffs

- **Propósito / Função**: Chassi móvel vertical da placa-mãe VPS, berço da bateria e patins de engaste 40 mm
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `26` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Estimado**: `285.8 cm³` · **`~155 g`** (`369 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-560` | `MOD4_Berco_Bateria_Front_114mm` | `114.0 × 15.0 × 13.7` | 15.91 | ~8.6 g |
| `GOG-561` | `MOD4_Berco_Bateria_Rear_102mm` | `102.0 × 15.0 × 13.7` | 14.23 | ~7.7 g |
| `GOG-562` | `MOD4_Bossa_Standoff_H1` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-563` | `MOD4_Bossa_Standoff_H11` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-564` | `MOD4_Bossa_Standoff_H15` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-565` | `MOD4_Bossa_Standoff_H16` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-566` | `MOD4_Bossa_Standoff_H21` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-567` | `MOD4_Bossa_Standoff_H4` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-568` | `MOD4_Bossa_Standoff_H5` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-569` | `MOD4_Bossa_Standoff_H8` | `14.3 × 6.0 × 6.0` | 0.51 | ~0.3 g |
| `GOG-576` | `MOD4_LEGO_Cassete_VPS_Frontal_114x164mm` | `157.0 × 113.8 × 5.0` | 85.13 | ~46.1 g |
| `GOG-577` | `MOD4_LEGO_Cassete_VPS_Traseiro_142x164mm` | `157.0 × 141.8 × 5.0` | 107.39 | ~58.2 g |
| `GOG-578` | `MOD4_Orelha_H15` | `13.2 × 12.0 × 7.6` | 1.08 | ~0.6 g |
| `GOG-579` | `MOD4_Orelha_H1_H5` | `39.0 × 15.5 × 7.6` | 4.38 | ~2.4 g |
| `GOG-580` | `MOD4_Orelha_H4_H11` | `20.0 × 13.2 × 7.6` | 1.76 | ~1.0 g |
| `GOG-581` | `MOD4_Patim_Cassete_Front` | `40.0 × 7.2 × 2.45` | 0.71 | ~0.4 g |
| `GOG-582` | `MOD4_Patim_Cassete_Rear` | `40.0 × 3.95 × 2.05` | 0.32 | ~0.2 g |
| `GOG-583` | `MOD4_Ponte_Standoff_Suporte_PCB_Front` | `128.2 × 20.95 × 6.35` | 17.05 | ~9.2 g |
| `GOG-584` | `MOD4_Ponte_Standoff_Suporte_PCB_Rear` | `128.2 × 20.95 × 6.35` | 16.79 | ~9.1 g |
| `GOG-586` | `MOD4_Suporte_SSD2_Apoio` | `31.6 × 13.0 × 4.2` | 1.73 | ~0.9 g |
| `GOG-587` | `MOD4_Suporte_SSD2_Braco` | `59.2 × 10.5 × 8.0` | 4.97 | ~2.7 g |
| `GOG-588` | `MOD4_Suporte_SSD2_Sela` | `15.5 × 14.3 × 7.6` | 1.51 | ~0.8 g |
| `GOG-592` | `MOD4_Trilho_Fixo_Cassete_Front_Dir` | `45.0 × 13.8 × 4.25` | 1.74 | ~0.9 g |
| `GOG-593` | `MOD4_Trilho_Fixo_Cassete_Front_Esq` | `127.0 × 13.8 × 4.25` | 4.96 | ~2.7 g |
| `GOG-594` | `MOD4_Trilho_Fixo_Cassete_Rear_Dir` | `45.0 × 5.5 × 3.55` | 0.46 | ~0.2 g |
| `GOG-595` | `MOD4_Trilho_Fixo_Cassete_Rear_Esq` | `145.5 × 5.5 × 3.55` | 1.50 | ~0.8 g |
