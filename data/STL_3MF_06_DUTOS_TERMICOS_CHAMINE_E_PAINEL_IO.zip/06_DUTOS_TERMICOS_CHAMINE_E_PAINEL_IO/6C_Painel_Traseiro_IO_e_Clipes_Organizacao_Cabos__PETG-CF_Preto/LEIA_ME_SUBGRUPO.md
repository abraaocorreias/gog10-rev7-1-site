# 6C · Painel Traseiro I/O (Colares RJ45 / HDMI) e Clipes de Alívio de Tração dos Cabos

- **Propósito / Função**: Ancoragem traseira de conectores e organização dos 13 cabos internos
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `23` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `4` bandeja(s)
- **Volume Sólido / Peso Estimado**: `702.8 cm³` · **`~381 g`** (`907 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-278` | `FIX_AlivioTracao_Aba_Yneg_JBAT201` | `11.55 × 7.05 × 1.65` | 0.13 | ~0.1 g |
| `GOG-279` | `FIX_AlivioTracao_Aba_Ypos_JBAT201` | `11.55 × 7.05 × 1.65` | 0.13 | ~0.1 g |
| `GOG-280` | `FIX_AlivioTracao_Base_JBAT201` | `9.4 × 2.6 × 2.25` | 0.05 | ~0.0 g |
| `GOG-281` | `FIX_AlivioTracao_Base_RearIO` | `8.7 × 6.5 × 5.15` | 0.29 | ~0.2 g |
| `GOG-282` | `FIX_AlivioTracao_Presilha_JDCIN1` | `8.6 × 8.6 × 2.2` | 0.06 | ~0.0 g |
| `GOG-283` | `FIX_AlivioTracao_Presilha_JHDMI1` | `7.4 × 7.4 × 3.0` | 0.07 | ~0.0 g |
| `GOG-284` | `FIX_AlivioTracao_Presilha_JLAN1` | `8.0 × 8.0 × 2.6` | 0.07 | ~0.0 g |
| `GOG-285` | `FIX_AlivioTracao_Presilha_JUSBC1` | `6.5 × 6.5 × 3.0` | 0.06 | ~0.0 g |
| `GOG-286` | `FIX_AlivioTracao_Torre_RearIO` | `79.95 × 11.37 × 9.35` | 3.76 | ~2.0 g |
| `GOG-570` | `MOD4_Defletor_Suporte_BlowerEsq` | `84.1 × 26.0 × 6.7` | 2.74 | ~1.5 g |
| `GOG-589` | `MOD4_Trilho_Filtro_Frontal_Dir` | `142.5 × 3.8 × 2.5` | 1.34 | ~0.7 g |
| `GOG-590` | `MOD4_Trilho_Filtro_Frontal_Esq` | `142.5 × 4.0 × 2.5` | 1.41 | ~0.8 g |
| `GOG-591` | `MOD4_Trilho_Filtro_Frontal_Inf` | `81.5 × 12.5 × 4.0` | 4.06 | ~2.2 g |
| `GOG-647` | `PAINEL_IO_Braco_Fixacao_ColRear` | `139.2 × 16.5 × 8.5` | 19.52 | ~10.6 g |
| `GOG-648` | `PAINEL_IO_Colar_Direto_HDMI_JHDMI1` | `16.0 × 13.2 × 3.8` | 0.80 | ~0.4 g |
| `GOG-649` | `PAINEL_IO_Colar_Direto_RJ45_JLAN1` | `16.0 × 13.2 × 3.8` | 0.80 | ~0.4 g |
| `GOG-650` | `PAINEL_IO_Suporte_Colar_Traseiro` | `39.0 × 13.2 × 6.8` | 1.76 | ~1.0 g |
| `GOG-767` | `PELE_F6_Plinto_Base8mm_F_Dir` | `145.8 × 101.8 × 8.0` | 115.29 | ~62.5 g |
| `GOG-768` | `PELE_F6_Plinto_Base8mm_F_Esq` | `145.8 × 124.8 × 8.0` | 142.10 | ~77.0 g |
| `GOG-769` | `PELE_F6_Plinto_Base8mm_M_Dir` | `101.8 × 79.1 × 8.0` | 61.23 | ~33.2 g |
| `GOG-770` | `PELE_F6_Plinto_Base8mm_M_Esq` | `124.8 × 79.1 × 8.0` | 78.87 | ~42.7 g |
| `GOG-771` | `PELE_F6_Plinto_Base8mm_R_Dir` | `154.3 × 101.8 × 8.0` | 124.01 | ~67.2 g |
| `GOG-772` | `PELE_F6_Plinto_Base8mm_R_Esq` | `154.3 × 124.8 × 8.0` | 144.25 | ~78.2 g |
