# 6B · 4 Coletores Adiabáticos dos Blowers da Placa-Mãe, Defletores e Suporte H2 (MOD4)

- **Propósito / Função**: Captação direta dos 2 blowers originais da GPU/CPU rumo à exaustão superior
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `8` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `141.3 cm³` · **`~77 g`** (`182 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-003` | `AIR_Coletor_Adiabatico_Dir_Frontal_BlowerDir` | `160.0 × 48.75 × 4.0` | 30.05 | ~16.3 g |
| `GOG-004` | `AIR_Coletor_Adiabatico_Dir_Traseiro_BlowerEsq` | `142.0 × 48.75 × 4.0` | 26.08 | ~14.1 g |
| `GOG-005` | `AIR_Coletor_Adiabatico_Esq_Frontal_BlowerDir` | `160.0 × 48.75 × 4.0` | 30.05 | ~16.3 g |
| `GOG-006` | `AIR_Coletor_Adiabatico_Esq_Traseiro_BlowerEsq` | `142.0 × 48.75 × 4.0` | 26.08 | ~14.1 g |
| `GOG-008` | `AIR_Defletor_AntiRecirc_Central` | `34.0 × 17.5 × 4.0` | 2.34 | ~1.3 g |
| `GOG-009` | `AIR_Defletor_JatoSecundario_BlowerDir` | `93.0 × 47.0 × 27.9` | 13.95 | ~7.6 g |
| `GOG-010` | `AIR_Defletor_JatoSecundario_BlowerEsq_BaseSelada` | `26.0 × 14.15 × 3.5` | 1.29 | ~0.7 g |
| `GOG-585` | `MOD4_Suporte_Defletor_BlowerDir` | `88.2 × 37.0 × 17.9` | 11.45 | ~6.2 g |
