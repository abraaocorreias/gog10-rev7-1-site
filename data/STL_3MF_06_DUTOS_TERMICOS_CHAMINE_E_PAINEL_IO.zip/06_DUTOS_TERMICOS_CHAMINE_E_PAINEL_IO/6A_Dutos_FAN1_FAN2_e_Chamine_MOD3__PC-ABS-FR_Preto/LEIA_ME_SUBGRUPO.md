# 6A · Duto Frio FAN1, Coletor Inclinado FAN2, Chaminé Isolada By-Pass e Divisor de Topo (MOD3)

- **Propósito / Função**: Circuito fechado de exaustão do calor das fontes (135 W / iCLAMPER) até o teto
- **Material Recomendado**: `PC-ABS FR UL94 V-0 (Alta Temp. / Retardante de Chama)`
- **Cor Indicada**: `Preto Técnico FR` (`#262626`)
- **Quantidade de Peças Imprimíveis**: `9` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `5` bandeja(s)
- **Volume Sólido / Peso Estimado**: `497.1 cm³` · **`~246 g`** (`587 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-001` | `AIR_Chamine_ByPass_MOD3_Inf` | `152.0 × 115.8 × 84.5` | 107.68 | ~53.4 g |
| `GOG-002` | `AIR_Chamine_ByPass_MOD3_Sup` | `152.0 × 111.9 × 84.5` | 104.09 | ~51.6 g |
| `GOG-007` | `AIR_Coletor_ByPass_FAN2` | `196.0 × 153.5 × 53.5` | 93.72 | ~46.4 g |
| `GOG-011` | `AIR_Defletor_Termico_MOD3_MOD4_Dir` | `162.0 × 67.9 × 3.0` | 30.56 | ~15.1 g |
| `GOG-012` | `AIR_Defletor_Termico_MOD3_MOD4_Esq` | `162.0 × 115.65 × 3.0` | 53.76 | ~26.6 g |
| `GOG-013` | `AIR_Divisor_Topo_MOD3_MOD4_F` | `145.3 × 7.6 × 2.5` | 2.76 | ~1.4 g |
| `GOG-014` | `AIR_Divisor_Topo_MOD3_MOD4_M` | `113.0 × 7.6 × 2.5` | 2.15 | ~1.1 g |
| `GOG-015` | `AIR_Duto_Admissao_FAN1` | `184.0 × 156.0 × 26.5` | 100.93 | ~50.0 g |
| `GOG-016` | `AIR_Suporte_Defletor_MOD3_Dir` | `18.0 × 10.0 × 8.0` | 1.44 | ~0.7 g |
