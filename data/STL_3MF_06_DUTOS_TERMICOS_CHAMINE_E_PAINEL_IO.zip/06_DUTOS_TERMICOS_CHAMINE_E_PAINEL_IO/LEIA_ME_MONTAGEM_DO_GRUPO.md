# 06 · Dutos de Refrigeração, Chaminé Isolada MOD3, Coletores dos Blowers e Painel I/O

**Objetivo construtivo**: Separação física dos 2 circuitos térmicos (duto frio FAN1, coletor FAN2 e chaminé vertical selada de MOD3 vs. 4 coletores adiabáticos dos blowers da placa-mãe em MOD4) e painel traseiro de conectores/cabos.

**Como montar este grupo**: Passo 3 da montagem: Antes de fechar as laterais, instale no andar T2 o duto de admissão do FAN1, o coletor inclinado -14° do FAN2 e a metade inferior da chaminé By-Pass (6A, em PC-ABS FR UL94 V-0). No andar T3/T4, encaixe a metade superior da chaminé, o divisor de topo, os 4 coletores adiabáticos sobre os blowers da LA-L161P e o defletor secundário no suporte H2 (6B). Parafuse o suporte de colares RJ45/HDMI e clipes de cabos (6C) na traseira.

**Vistas de referência no site (`https://abraaocorreias.github.io/gog10-rev7-1-site/`)**: `V09, V13, V14, V20, V21, V22, V23, V24, V29`

## Subgrupos de Peças, Materiais e Cores:

| Subpasta | Material | Cor | Peças | Bandejas 202×202 | Volume | Peso Estimado |
|---|---|---|---:|---:|---:|---:|
| `6A_Dutos_FAN1_FAN2_e_Chamine_MOD3__PC-ABS-FR_Preto` | PC-ABS FR UL94 V-0 (Alta Temp. / Retardante de Chama) | Preto Técnico FR | 9 | 5 | 497.1 cm³ | **~246 g** |
| `6B_Coletores_Adiabaticos_Blowers_e_Defletores_MOD4__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 8 | 2 | 141.3 cm³ | **~77 g** |
| `6C_Painel_Traseiro_IO_e_Clipes_Organizacao_Cabos__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 23 | 4 | 702.8 cm³ | **~381 g** |
