# GOG10 — CAMINHO C v3.1 (100% Acrílico Cast Opaco + Grade Suíça REV7.1 + Saída Cabo AC iCLAMPER)

## 1. Resumo do Pacote
- **Envoltória exata REV7.1:** `294,0 × 436,0 × 624,9 mm` (Plinto flutuante `21 mm` + Corpo `574,9 mm` + Fresta negativa `8 mm` + Coroa `21 mm`).
- **Zero MDF e Zero Transparência:** Exterior em **Acrílico Cast Opaco Fosco `#ECEAE4` (`4,0 mm`)** e interior/recessos em **Acrílico Cast Opaco Preto Fosco `#141619` (`3,0 mm`)**.
- **Laterais (`-Y` e `+Y`) 100% sem acesso ou furos de serviço:** Toda manutenção, `2` portas opacas alinhadas à grade suíça, `FAN1`/`FAN2` (`Ø 76 mm`), Painel I/O e a saída do cabo de energia ficam exclusivamente na **face traseira (`-X`, oposta ao roteador)**.
- **Impressão 3D reduzida a `17` peças funcionais (`PETG Comum Preto`, `263.5 g`, `~9.0 h`, `3` bandejas `202×202 mm`, `100%` manifold `bad=0`)** — zero `PC-ABS FR` e zero `PETG-CF`.

## 2. Como Fazer a Grade Suíça REV7.1 (Sulcos Retangulares de 2 mm) no Acrílico Opaco
Todos os arquivos `.DXF` das chapas externas (`LASER-01..05`) trazem a camada dedicada **`SULCO_GRADE_SUICA_2MM_PROF_1_8MM`**:
- **Opção A1 — Sulco Fresado CNC ou Gravação Laser Profunda na Chapa `4 mm` (Recomendada):**
  - Rebaixo de **`2,0 mm` de largura × `1,8 mm` de profundidade** (restam `2,2 mm` sólidos -> **100% opaco**, sem atravessar!).
  - Preencher os sulcos com tinta acrílica preto fosco (`#141619`) ou marcador permanente com máscara de papel craft ainda aplicada no acrílico e remover a película: contraste arquitetural idêntico ao `REV7.1` sem linhas de camada 3D!
- **Opção A2 — Sanduíche `2 + 2 mm` 100% Corte a Laser (se a oficina não tiver CNC/fresa):**
  - Cortar uma base inteiriça em **Acrílico Preto Opaco `2 mm`** e colar por cima (com cola acrílica S-320) os retângulos da grade suíça cortados em **Acrílico Cast Opaco `#ECEAE4` `2 mm`** com espaçamento de **`2,0 mm`** entre eles -> junta escura real de `2 × 2 mm` feita 100% no corte a laser!

## 3. Saída Explícita do Cabo Único AC do Filtro de Linha (`iCLAMPER Energia 5`) + Fibra Óptica
1. **Origem:** `boot` do cabo AC do `iCLAMPER Energia 5` posicionado em `Z = 222 mm`, `Y = +95..+106 mm` (lado traseiro da bandeja `MOD2`).
2. **Descida Vertical Dedicada:** Recorte em `LASER-08` (prateleira `Z = 194 mm`, `X = -162..-112 mm, Y = +64..+108 mm`) permitindo que o cabo AC desça reto e sem dobra brusca até a base.
3. **Saída Traseira Inferior (`-X`):** Recorte dedicado em `LASER-04` (`Y = +64..+98 mm, Z = 21..49 mm`) + canal basal no plinto `LASER-06` + peça 3D **`CAMC3-17_GOLA_Saida_Cabo_AC_Filtro_iClamper_e_Fibra.stl`** (passa-cabo traseiro com alívio de tração para o cabo único AC + entrada da fibra óptica rumo à `ONT FD511G`).

## 4. Conteúdo das Pastas
- `01_CORTE_LASER_ACRILICO_CAST_OPACO_GRADE_SUICA_DXF/`: `11` chapas `.DXF` individuais + `PLANO_DE_CORTE_ACRILICO_OPACO_GRADE_SUICA_1PARA1.dxf`.
- `02_IMPRESSAO_3D_17_PECAS_PETG_COMUM/BANDEJAS_202x202mm_3MF_E_STL/`: `3` bandejas prontas `.3MF` e `.STL` (`PETG Comum Preto`, `20%` infill, `3` perímetros, sem suporte).
- `02_IMPRESSAO_3D_17_PECAS_PETG_COMUM/PECAS_INDIVIDUAIS_STL/`: `17` arquivos `.STL` individuais (`100%` estanques, `bad=0`).
- `TABELA_CAMINHO_C_V3_ACRILICO_OPACO.csv`: lista completa de materiais, medidas e tempos.
