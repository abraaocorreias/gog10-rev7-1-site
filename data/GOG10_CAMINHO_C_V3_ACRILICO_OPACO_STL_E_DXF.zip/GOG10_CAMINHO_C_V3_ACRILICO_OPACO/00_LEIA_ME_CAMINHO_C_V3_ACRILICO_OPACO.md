# GABINETE GOG10 · CAMINHO C v3 (ACRÍLICO CAST OPACO · ESTÉTICA RESTAURADA · ACESSO 100% TRASEIRO -X)

- **100% Acrílico Cast Opaco Fosco (ZERO MDF · ZERO Transparência)**: exterior em Acrílico Opaco Fosco `#ECEAE4` (`4,0 mm`, bordas perfeitas no laser CO₂, zero pintura) + interior, plinto flutuante `13 mm`, fresta superior `8 mm`, câmara escura atrás dos 5 frisos e baía RF em Acrílico Preto Fosco Opaco `#141619` (`3,0 mm`).
- **Laterais (`-Y` e `+Y`) 100% fechadas**: zero furos de ventoinha na lateral esquerda, zero portas laterais.
- **Acesso 100% pela Traseira (`-X`, placa oposta ao roteador)**: 2 portas opacas `#ECEAE4` com dobradiça oculta/ímãs, saque traseiro da `LA-L161P`, `iCLAMPER 290 mm`, `ONT`, `Hub`, `SSD`, `FAN1` + `FAN2` (`Ø 76 mm` na traseira) e Painel I/O.
- **Impressão 3D**: apenas **`16` peças funcionais** em **PETG Comum Preto** (`234 g` · `8.0 h` · `3` bandejas `202×202 mm` · `16/16` STLs com `bad = 0`).
