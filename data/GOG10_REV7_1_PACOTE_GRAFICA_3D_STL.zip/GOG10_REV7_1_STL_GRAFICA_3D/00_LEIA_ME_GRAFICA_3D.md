# PACOTE OFICIAL DE IMPRESSÃO 3D (STL) — GABINETE MONOLÍTICO GOG10 (REV7.1)

Este pacote contém **todas as 505 peças imprimíveis (FDM)** do gabinete `GOG10 (294,0 × 436,0 × 624,9 mm)`
100% verificadas em topologia (`0` arestas não-manifold, `1` única ilha sólida por arquivo, `0` sobreposições > 0,20 mm,
todas as peças entre `1,2 mm` e `201,5 mm <= 202,0 mm` e já rotacionadas com a base plana apoiada em `Z = 0`).

---

## 1. COMO ABRIR NO FATIADOR (BAMBU STUDIO / ORCASLICER / PRUSASLICER / CURA)

1. **Para Orçamento Rápido (5 arquivos por Material/Cor):**
   Abra a pasta `01_LOTES_POR_MATERIAL_PARA_ORCAMENTO/`.
   - Cada arquivo `LOTE_01..05_*.stl` reúne todas as peças daquele material/cor já deitadas em `Z=0`.
   - O arquivo `00_CONJUNTO_COMPLETO_MONTADO_REFERENCIA_505_PECAS.stl` mostra o gabinete inteiro montado na posição 3D final (apenas para visualização; não fatiar montado).
2. **Para Fatiar Direto em Impressoras 220×220 mm ou 256×256 mm:**
   Abra a pasta `02_BANDEJAS_202x202mm_PRONTAS_PARA_FATIAR/` (90 bandejas no total).
   - Cada arquivo representa uma mesa de até `202 × 202 mm` já organizada por material e cor, pronta para fatiar.
3. **Para Peças Individuais (505 arquivos `.stl`):**
   Abra `03_PECAS_INDIVIDUAIS_505_STLS/` (organizadas por material e com código `GOG-xxx` correspondente à planilha `BOM_505_PECAS_IMPRESSAO_3D.csv`).

---

## 2. RESUMO DE MATERIAIS, VOLUMES E MASSA ESTIMADA

| Lote | Material / Cor Recomendada | Peças | Mesas 202×202 | Volume Sólido (cm³) | Peso Estimado (4 perím. + 35% infill) | Peso 100% Sólido |
|---|---|---:|---:|---:|---:|---:|
| `01_PETG_CF_Preto_Estrutural_Esqueleto_e_Trilhos` | PETG-CF (Fibra de Carbono) Preto Estrutural | 199 | 22 | 3184.8 cm³ | **~1725 g** | 4108 g |
| `02_Carenagem_Externa_Branco_Osso_ECEAE4` | PLA+ / PETG / ASA Branco-Osso Fosco (#ECEAE4) | 147 | 39 | 6305.4 cm³ | **~3284 g** | 7819 g |
| `03_Baia_RF_e_Acabamentos_Preto_Fosco_141619` | PETG / ASA Preto Fosco (#141619, sem fibra de carbono) | 84 | 10 | 1107.1 cm³ | **~590 g** | 1406 g |
| `04_PC_ABS_FR_e_PC_FR_UL94_V0_Termico_MOD3` | PC-ABS FR / PC-FR UL94 V-0 (Alta Temp. / Retardante de Chama) | 37 | 13 | 1040.2 cm³ | **~515 g** | 1228 g |
| `05_PC_Puro_Sem_Carga_RF_MOD1` | Policarbonato (PC) Puro Sem Carga (Transparente a RF) | 38 | 6 | 416.8 cm³ | **~210 g** | 500 g |
| **TOTAL** | **Conjunto Completo FDM** | **505** | **90** | **12054.3 cm³** | **~6324 g (6.32 kg)** | **15061 g (15.06 kg)** |

---

## 3. PARÂMETROS DE IMPRESSÃO RECOMENDADOS

- **Bico**: `0,4 mm` (largura de linha `0,42–0,44 mm`)
- **Altura de camada**: `0,16 mm` nas corrediças/trilhos/encaixes (`0,20 mm` nos painéis planos e colunas)
- **Perímetros (Walls)**: `4 a 5 perímetros`
- **Preenchimento (Infill)**:
  - **Corrediças telescópicas (`Corredica_*`, `Trilho_*`, `Patim_*`), talas (`FIX_Tala_Struct_*`) e suportes**: `100%` sólido (ou `5` perímetros + `50%` Gyroid), **sempre impressos deitados no plano XY** (como já estão orientados nos arquivos `.stl`).
  - **Colunas e vigas (`ESQ_*`)**: `4` perímetros + `35–40%` Gyroid/Cubic.
  - **Painéis estéticos (`PELE_F6_*`) e defletores (`BAIA_*`, `AIR_*`)**: `3–4` perímetros + `25%` Gyroid.
- **Suportes**: Desnecessários na quase totalidade das peças (já orientadas a `0°`/`45°` de overhang); nos canais `C` de `0,25 mm` das corrediças, **não usar suporte interno**.
- **Recomendação de Pré-Série**: Imprimir inicialmente 1 par de corrediça (`GOG-493` + `GOG-495` + `GOG-491`) para calibrar o *flow/XY compensation* na folga deslizante de `0,25 mm` antes de rodar todas as bandejas.
