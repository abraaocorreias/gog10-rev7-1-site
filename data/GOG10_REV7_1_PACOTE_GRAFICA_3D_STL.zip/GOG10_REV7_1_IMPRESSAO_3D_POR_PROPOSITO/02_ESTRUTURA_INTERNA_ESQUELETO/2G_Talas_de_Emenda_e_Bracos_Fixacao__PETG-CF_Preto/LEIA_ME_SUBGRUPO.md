# 2G · Talas Estruturais Aparafusadas (M3) e Braços de Ancoragem da Carenagem

- **Propósito / Função**: Luvas/talas de união mecânica das vigas bipartidas e suportes de pino da pele
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `27` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `156.7 cm³` · **`~85 g`** (`202 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-136` | `ESQ_Abas_Inserto_Rear_0` | `12.2 × 8.0 × 8.0` | 0.78 | ~0.4 g |
| `GOG-137` | `ESQ_Abas_Inserto_Rear_2` | `12.2 × 8.0 × 8.0` | 0.78 | ~0.4 g |
| `GOG-138` | `ESQ_Abas_Inserto_Rear_4` | `12.2 × 8.0 × 8.0` | 0.78 | ~0.4 g |
| `GOG-139` | `ESQ_Braco_PinoPele_Dir_11` | `29.88 × 18.0 × 8.0` | 4.21 | ~2.3 g |
| `GOG-140` | `ESQ_Braco_PinoPele_Dir_12` | `29.88 × 18.0 × 8.0` | 4.21 | ~2.3 g |
| `GOG-141` | `ESQ_Braco_PinoPele_Dir_13` | `29.88 × 18.0 × 8.0` | 4.21 | ~2.3 g |
| `GOG-142` | `ESQ_Braco_PinoPele_Dir_14` | `29.88 × 18.0 × 8.0` | 4.11 | ~2.2 g |
| `GOG-143` | `ESQ_Braco_PinoPele_Esq_5` | `28.5 × 27.55 × 8.0` | 6.20 | ~3.4 g |
| `GOG-208` | `ESQ_Sapata_Junta_Nervura_Front_Base` | `52.35 × 16.5 × 13.95` | 12.03 | ~6.5 g |
| `GOG-209` | `ESQ_Sapata_Junta_Nervura_Front_FlangeSup` | `52.9 × 36.05 × 16.5` | 31.41 | ~17.0 g |
| `GOG-210` | `ESQ_Sapata_Junta_Nervura_Rear_BackWrap` | `50.0 × 9.45 × 1.95` | 0.92 | ~0.5 g |
| `GOG-211` | `ESQ_Sapata_Junta_Nervura_Rear_SideCol` | `50.0 × 27.5 × 6.9` | 9.13 | ~4.9 g |
| `GOG-219` | `ESQ_Suporte_Coletor_Air_Esq` | `44.0 × 7.0 × 6.0` | 1.85 | ~1.0 g |
| `GOG-220` | `ESQ_Suporte_Coletor_Air_Front` | `44.0 × 6.0 × 6.0` | 1.58 | ~0.9 g |
| `GOG-221` | `ESQ_Suporte_Coletor_Air_Rear` | `44.0 × 7.25 × 7.0` | 2.23 | ~1.2 g |
| `GOG-487` | `FIX_Tala_Struct_CasseteTrilho_Front` | `38.0 × 13.0 × 2.6` | 1.28 | ~0.7 g |
| `GOG-488` | `FIX_Tala_Struct_CasseteTrilho_Rear` | `38.0 × 3.55 × 2.55` | 0.34 | ~0.2 g |
| `GOG-489` | `FIX_Tala_Struct_Deck_Front_X38` | `68.0 × 15.0 × 4.5` | 4.58 | ~2.5 g |
| `GOG-490` | `FIX_Tala_Struct_Deck_Rear_X10` | `60.0 × 16.0 × 4.5` | 4.31 | ~2.3 g |
| `GOG-491` | `FIX_Tala_Struct_Esq_N1_Y146` | `14.5 × 12.0 × 2.7` | 0.47 | ~0.3 g |
| `GOG-492` | `FIX_Tala_Struct_Longarina_T4_Y100` | `70.0 × 13.0 × 4.4` | 3.38 | ~1.8 g |
| `GOG-493` | `FIX_Tala_Struct_MOD3_iClamper_Dir_Y22` | `39.4 × 35.0 × 1.65` | 2.27 | ~1.2 g |
| `GOG-494` | `FIX_Tala_Struct_MOD3_iClamper_Esq_Y22` | `39.4 × 35.0 × 1.65` | 2.27 | ~1.2 g |
| `GOG-495` | `FIX_Tala_Struct_Travessa_Front_Deck` | `72.0 × 17.0 × 16.5` | 9.66 | ~5.2 g |
| `GOG-496` | `FIX_Tala_Struct_Viga_Arco_X40` | `68.0 × 25.5 × 20.0` | 16.54 | ~9.0 g |
| `GOG-497` | `FIX_Tala_Struct_Viga_Balanco_Y137` | `72.0 × 19.4 × 14.0` | 11.03 | ~6.0 g |
| `GOG-498` | `FIX_Tala_Struct_Viga_Balanco_Y61` | `72.0 × 22.0 × 19.4` | 16.17 | ~8.8 g |
