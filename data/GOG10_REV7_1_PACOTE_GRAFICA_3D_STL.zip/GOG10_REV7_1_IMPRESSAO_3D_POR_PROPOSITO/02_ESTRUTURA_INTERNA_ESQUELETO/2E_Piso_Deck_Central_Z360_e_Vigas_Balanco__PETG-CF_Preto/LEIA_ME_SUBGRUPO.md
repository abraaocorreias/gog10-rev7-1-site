# 2E · Placas do Deck Estrutural Intermediário (Z = 360 mm) e Vigas de Balanço Y137/Y61

- **Propósito / Função**: Plataforma divisória portante entre MOD3 e MOD4 com passagem da chaminé
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `11` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `6` bandeja(s)
- **Volume Sólido / Peso Estimado**: `626.3 cm³` · **`~339 g`** (`808 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-196` | `ESQ_Piso_Balanco_Estrutural_Front_Dir` | `138.9 × 134.0 × 5.2` | 96.19 | ~52.1 g |
| `GOG-197` | `ESQ_Piso_Balanco_Estrutural_Front_Esq` | `134.0 × 133.9 × 5.2` | 79.16 | ~42.9 g |
| `GOG-198` | `ESQ_Piso_Balanco_Estrutural_Mid_Dir` | `138.9 × 121.6 × 5.2` | 87.42 | ~47.4 g |
| `GOG-199` | `ESQ_Piso_Balanco_Estrutural_Mid_Esq` | `133.9 × 121.6 × 5.2` | 84.67 | ~45.9 g |
| `GOG-200` | `ESQ_Piso_Balanco_Estrutural_Rear_Dir` | `138.9 × 128.1 × 5.2` | 92.52 | ~50.1 g |
| `GOG-201` | `ESQ_Piso_Balanco_Estrutural_Rear_Esq` | `133.9 × 128.1 × 5.2` | 89.19 | ~48.3 g |
| `GOG-244` | `ESQ_Viga_Reforco_Balanco_Y137_Dir` | `123.9 × 15.9 × 12.0` | 23.32 | ~12.6 g |
| `GOG-245` | `ESQ_Viga_Reforco_Balanco_Y137_Esq` | `131.9 × 15.9 × 12.0` | 23.98 | ~13.0 g |
| `GOG-246` | `ESQ_Viga_Reforco_Balanco_Y61_Dir` | `123.9 × 15.9 × 12.0` | 23.32 | ~12.6 g |
| `GOG-247` | `ESQ_Viga_Reforco_Balanco_Y61_Esq` | `131.9 × 15.9 × 12.0` | 23.98 | ~13.0 g |
| `GOG-248` | `ESQ_Viga_Transf_BayRear_Z76` | `52.0 × 8.0 × 6.15` | 2.56 | ~1.4 g |
