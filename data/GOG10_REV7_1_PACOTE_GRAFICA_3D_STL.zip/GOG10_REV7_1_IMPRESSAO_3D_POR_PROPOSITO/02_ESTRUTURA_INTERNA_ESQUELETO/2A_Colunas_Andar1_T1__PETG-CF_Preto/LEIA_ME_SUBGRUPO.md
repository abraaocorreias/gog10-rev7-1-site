# 2A · Colunas Verticais do 1º Andar (T1 · Z = 24,5 a 198 mm · 7 colunas)

- **Propósito / Função**: Pilares principais do andar inferior (MOD1 Roteador + MOD2 ONT)
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `7` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Estimado**: `258.7 cm³` · **`~140 g`** (`334 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-144` | `ESQ_Col_BayCheek_T1` | `173.6 × 18.0 × 8.0` | 25.00 | ~13.5 g |
| `GOG-148` | `ESQ_Col_BayRear_T1` | `68.85 × 14.0 × 8.0` | 7.71 | ~4.2 g |
| `GOG-152` | `ESQ_Col_Front_Dir_T1` | `173.6 × 24.0 × 14.0` | 58.33 | ~31.6 g |
| `GOG-156` | `ESQ_Col_Front_Esq_T1` | `173.6 × 51.5 × 27.55` | 67.13 | ~36.4 g |
| `GOG-160` | `ESQ_Col_Mid_Esq_T1` | `173.6 × 19.0 × 9.0` | 29.69 | ~16.1 g |
| `GOG-164` | `ESQ_Col_Rear_EsqExt_T1` | `173.6 × 27.6 × 22.0` | 36.44 | ~19.7 g |
| `GOG-168` | `ESQ_Col_Rear_Esq_T1` | `173.6 × 22.0 × 9.0` | 34.37 | ~18.6 g |
