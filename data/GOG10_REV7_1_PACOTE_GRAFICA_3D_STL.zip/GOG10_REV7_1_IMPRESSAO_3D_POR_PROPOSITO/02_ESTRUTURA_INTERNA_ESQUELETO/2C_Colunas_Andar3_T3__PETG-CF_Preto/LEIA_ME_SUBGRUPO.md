# 2C · Colunas Verticais do 3º Andar (T3 · Z = 364 a 536 mm · 6 colunas)

- **Propósito / Função**: Pilares inferiores do compartimento do servidor VPS (MOD4)
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `6` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Estimado**: `206.2 cm³` · **`~112 g`** (`266 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-146` | `ESQ_Col_BayCheek_T3` | `159.6 × 18.0 × 8.0` | 22.98 | ~12.5 g |
| `GOG-150` | `ESQ_Col_BayRear_T3` | `159.6 × 14.0 × 8.0` | 17.88 | ~9.7 g |
| `GOG-154` | `ESQ_Col_Front_Dir_T3` | `164.3 × 24.0 × 14.0` | 55.20 | ~29.9 g |
| `GOG-158` | `ESQ_Col_Front_Esq_T3` | `164.3 × 27.55 × 16.0` | 38.80 | ~21.0 g |
| `GOG-162` | `ESQ_Col_Rear_Dir_T3` | `159.6 × 29.88 × 28.2` | 38.35 | ~20.8 g |
| `GOG-166` | `ESQ_Col_Rear_EsqExt_T3` | `159.6 × 27.6 × 22.0` | 32.98 | ~17.9 g |
