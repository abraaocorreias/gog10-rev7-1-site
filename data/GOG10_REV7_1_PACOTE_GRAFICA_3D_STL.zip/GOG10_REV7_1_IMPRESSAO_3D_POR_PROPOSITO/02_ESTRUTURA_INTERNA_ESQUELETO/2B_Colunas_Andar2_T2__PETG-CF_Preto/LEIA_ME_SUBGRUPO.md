# 2B · Colunas Verticais do 2º Andar (T2 · Z = 198 a 359 mm · 7 colunas)

- **Propósito / Função**: Pilares do compartimento elétrico e térmico médio (MOD3)
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `7` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `1` bandeja(s)
- **Volume Sólido / Peso Estimado**: `248.3 cm³` · **`~134 g`** (`320 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-145` | `ESQ_Col_BayCheek_T2` | `144.9 × 18.0 × 8.0` | 20.87 | ~11.3 g |
| `GOG-149` | `ESQ_Col_BayRear_T2` | `160.9 × 14.0 × 8.0` | 18.02 | ~9.8 g |
| `GOG-153` | `ESQ_Col_Front_Dir_T2` | `161.9 × 24.0 × 14.0` | 54.40 | ~29.5 g |
| `GOG-157` | `ESQ_Col_Front_Esq_T2` | `161.9 × 51.5 × 27.55` | 63.20 | ~34.2 g |
| `GOG-161` | `ESQ_Col_Mid_Esq_T2` | `160.9 × 19.0 × 9.0` | 26.62 | ~14.4 g |
| `GOG-165` | `ESQ_Col_Rear_EsqExt_T2` | `160.9 × 27.55 × 21.5` | 33.30 | ~18.0 g |
| `GOG-169` | `ESQ_Col_Rear_Esq_T2` | `160.9 × 22.0 × 9.0` | 31.86 | ~17.3 g |
