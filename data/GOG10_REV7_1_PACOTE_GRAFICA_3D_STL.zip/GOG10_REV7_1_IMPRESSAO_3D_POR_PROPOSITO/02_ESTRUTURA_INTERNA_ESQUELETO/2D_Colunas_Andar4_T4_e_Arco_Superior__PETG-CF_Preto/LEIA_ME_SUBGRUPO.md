# 2D · Colunas do 4º Andar (T4 · 6 colunas), Viga Arco de Coroamento e Nervuras

- **Propósito / Função**: Fechamento estrutural superior do pórtico no nível T4 (Z = 536 a 596 mm)
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `13` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Estimado**: `317.5 cm³` · **`~172 g`** (`410 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-147` | `ESQ_Col_BayCheek_T4` | `67.6 × 18.0 × 8.0` | 9.73 | ~5.3 g |
| `GOG-151` | `ESQ_Col_BayRear_T4` | `67.6 × 14.0 × 8.0` | 7.57 | ~4.1 g |
| `GOG-155` | `ESQ_Col_Front_Dir_T4` | `60.9 × 24.0 × 14.0` | 20.46 | ~11.1 g |
| `GOG-159` | `ESQ_Col_Front_Esq_T4` | `72.6 × 27.55 × 16.0` | 19.01 | ~10.3 g |
| `GOG-163` | `ESQ_Col_Rear_Dir_T4` | `60.9 × 29.88 × 18.0` | 15.62 | ~8.5 g |
| `GOG-167` | `ESQ_Col_Rear_EsqExt_T4` | `60.9 × 14.0 × 13.0` | 11.08 | ~6.0 g |
| `GOG-191` | `ESQ_Longarina_T4_Arco_Dir` | `174.0 × 14.0 × 8.0` | 18.77 | ~10.2 g |
| `GOG-192` | `ESQ_Longarina_T4_Arco_Esq_Front` | `197.8 × 14.0 × 13.0` | 35.88 | ~19.4 g |
| `GOG-193` | `ESQ_Longarina_T4_Arco_Esq_Rear` | `199.3 × 37.0 × 19.55` | 38.59 | ~20.9 g |
| `GOG-194` | `ESQ_Nervura_ASA_8x50_Seg1` | `184.0 × 50.0 × 8.0` | 67.45 | ~36.5 g |
| `GOG-195` | `ESQ_Nervura_ASA_8x50_Seg2` | `71.3 × 50.0 × 8.0` | 28.37 | ~15.4 g |
| `GOG-242` | `ESQ_Viga_Arco_MOD4_Top_Dir` | `79.8 × 18.0 × 12.0` | 16.53 | ~9.0 g |
| `GOG-243` | `ESQ_Viga_Arco_MOD4_Top_Esq` | `136.0 × 18.0 × 12.0` | 28.42 | ~15.4 g |
