# 02 · Estrutura Portante Interna (Esqueleto: 26 Colunas, Vigas, Piso Deck e Talas)

**Objetivo construtivo**: Chassi estrutural interno em PETG-CF que sustenta os 4 andares (T1 a T4), o piso intermediário em balanço (Z = 360 mm) e a Viga Arco superior.

**Como montar este grupo**: Passo 2 da montagem: Erga primeiro as 7 colunas T1 (2A) sobre as sapatas e trave com as longarinas/travessas Z25 e N1 (2F). Monte as 7 colunas T2 (2B) e longarinas N2/Deck. Assente as 4 placas do Piso Deck Central Z=360 mm e as vigas de reforço Y137/Y61 (2E) unidas pelas talas aparafusadas M3 (2G). Por fim, suba as 6 colunas T3 (2C), as 6 colunas T4 e feche o topo com a Viga Arco bipartida (2D).

**Vistas de referência no site (`https://abraaocorreias.github.io/gog10-rev7-1-site/`)**: `V06, V10, V19, V20, V26, V28`

## Subgrupos de Peças, Materiais e Cores:

| Subpasta | Material | Cor | Peças | Bandejas 202×202 | Volume | Peso Estimado |
|---|---|---|---:|---:|---:|---:|
| `2A_Colunas_Andar1_T1__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 7 | 1 | 258.7 cm³ | **~140 g** |
| `2B_Colunas_Andar2_T2__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 7 | 1 | 248.3 cm³ | **~134 g** |
| `2C_Colunas_Andar3_T3__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 6 | 1 | 206.2 cm³ | **~112 g** |
| `2D_Colunas_Andar4_T4_e_Arco_Superior__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 13 | 2 | 317.5 cm³ | **~172 g** |
| `2E_Piso_Deck_Central_Z360_e_Vigas_Balanco__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 11 | 6 | 626.3 cm³ | **~339 g** |
| `2F_Longarinas_e_Travessas_Horizontais__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 41 | 4 | 438.6 cm³ | **~238 g** |
| `2G_Talas_de_Emenda_e_Bracos_Fixacao__PETG-CF_Preto` | PETG-CF (Fibra de Carbono) | Preto Fosco Estrutural | 27 | 2 | 156.7 cm³ | **~85 g** |
