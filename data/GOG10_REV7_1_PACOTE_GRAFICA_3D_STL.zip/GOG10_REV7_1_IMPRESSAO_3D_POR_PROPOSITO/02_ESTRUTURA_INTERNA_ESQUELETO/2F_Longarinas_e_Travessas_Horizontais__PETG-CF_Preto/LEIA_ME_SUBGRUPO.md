# 2F · Longarinas e Travessas Horizontais de Travamento dos 4 Andares

- **Propósito / Função**: Anéis horizontais de travamento entre colunas (níveis Z25, N1, N2, Deck e Top)
- **Material Recomendado**: `PETG-CF (Fibra de Carbono)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Quantidade de Peças Imprimíveis**: `41` peças
- **Bandejas de Impressão (`<= 202 × 202 mm`)**: `4` bandeja(s)
- **Volume Sólido / Peso Estimado**: `438.6 cm³` · **`~238 g`** (`566 g` se 100% sólido)

## O que usar no Fatiador:
1. **Recomendado (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.3mf`)**: abra o arquivo `.3mf` no Bambu Studio, OrcaSlicer, PrusaSlicer ou Cura. Todas as peças já vêm **separadas individualmente com seus nomes** e apoiadas em `Z = 0` dentro de `202 × 202 mm`.
2. **Alternativa por Bandeja (`BANDEJAS_MESA_202x202mm_3MF_E_STL/*.stl`)**: cada bandeja `<= 202 × 202 mm` pronta em `.stl`.
3. **Peça a Peça (`PECAS_INDIVIDUAIS_STL/*.stl`)**: cada placa/peça em um arquivo `.stl` individual já deitada na orientação correta de impressão.

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Volume (cm³) | Peso Estimado (g) |
|---|---|---:|---:|---:|
| `GOG-170` | `ESQ_Longarina_Dir_S1_Deck` | `162.0 × 12.0 × 12.0` | 22.11 | ~12.0 g |
| `GOG-171` | `ESQ_Longarina_Dir_S1_Top` | `162.0 × 12.0 × 7.0` | 13.61 | ~7.4 g |
| `GOG-172` | `ESQ_Longarina_Dir_S2_Deck` | `121.6 × 12.0 × 12.0` | 17.51 | ~9.5 g |
| `GOG-173` | `ESQ_Longarina_Dir_S2_Top` | `121.6 × 12.0 × 7.0` | 10.21 | ~5.5 g |
| `GOG-174` | `ESQ_Longarina_Dir_S3_Deck` | `135.6 × 12.0 × 12.0` | 19.53 | ~10.6 g |
| `GOG-175` | `ESQ_Longarina_Dir_S3_Top` | `125.4 × 12.0 × 7.0` | 10.53 | ~5.7 g |
| `GOG-176` | `ESQ_Longarina_Esq_S1_Deck` | `114.8 × 12.0 × 12.0` | 16.53 | ~9.0 g |
| `GOG-177` | `ESQ_Longarina_Esq_S1_N1` | `114.8 × 12.0 × 5.0` | 6.89 | ~3.7 g |
| `GOG-178` | `ESQ_Longarina_Esq_S1_N2` | `114.8 × 12.0 × 6.0` | 8.27 | ~4.5 g |
| `GOG-179` | `ESQ_Longarina_Esq_S1_Top` | `151.8 × 12.0 × 7.0` | 12.75 | ~6.9 g |
| `GOG-180` | `ESQ_Longarina_Esq_S1_Z25` | `114.8 × 12.0 × 5.0` | 6.89 | ~3.7 g |
| `GOG-181` | `ESQ_Longarina_Esq_S2_Deck` | `121.6 × 12.0 × 12.0` | 17.23 | ~9.3 g |
| `GOG-182` | `ESQ_Longarina_Esq_S2_N1` | `121.6 × 12.0 × 5.0` | 7.18 | ~3.9 g |
| `GOG-183` | `ESQ_Longarina_Esq_S2_N2` | `121.6 × 12.0 × 6.0` | 8.62 | ~4.7 g |
| `GOG-184` | `ESQ_Longarina_Esq_S2_Top` | `121.6 × 36.5 × 27.55` | 17.51 | ~9.5 g |
| `GOG-185` | `ESQ_Longarina_Esq_S2_Z25` | `121.6 × 27.55 × 21.5` | 11.30 | ~6.1 g |
| `GOG-186` | `ESQ_Longarina_Esq_S3_Deck` | `125.4 × 12.0 × 12.0` | 16.15 | ~8.8 g |
| `GOG-187` | `ESQ_Longarina_Esq_S3_N1` | `114.4 × 12.0 × 5.0` | 6.73 | ~3.6 g |
| `GOG-188` | `ESQ_Longarina_Esq_S3_N2` | `114.4 × 12.0 × 6.0` | 8.08 | ~4.4 g |
| `GOG-189` | `ESQ_Longarina_Esq_S3_Top` | `125.4 × 40.5 × 27.55` | 18.71 | ~10.1 g |
| `GOG-190` | `ESQ_Longarina_Esq_S3_Z25` | `114.4 × 12.0 × 5.0` | 6.73 | ~3.6 g |
| `GOG-222` | `ESQ_Travessa_Front_Deck_Dir` | `123.9 × 12.0 × 11.5` | 15.60 | ~8.5 g |
| `GOG-223` | `ESQ_Travessa_Front_Deck_Esq` | `115.7 × 12.0 × 11.5` | 15.97 | ~8.7 g |
| `GOG-224` | `ESQ_Travessa_Front_N1_Dir` | `123.9 × 11.5 × 5.0` | 6.50 | ~3.5 g |
| `GOG-225` | `ESQ_Travessa_Front_N1_Esq` | `115.7 × 11.5 × 5.0` | 6.65 | ~3.6 g |
| `GOG-226` | `ESQ_Travessa_Front_N2_Dir` | `123.9 × 11.5 × 6.0` | 7.80 | ~4.2 g |
| `GOG-227` | `ESQ_Travessa_Front_N2_Esq` | `115.7 × 11.5 × 6.0` | 7.98 | ~4.3 g |
| `GOG-228` | `ESQ_Travessa_Front_Top_Dir` | `123.9 × 11.5 × 7.0` | 9.82 | ~5.3 g |
| `GOG-229` | `ESQ_Travessa_Front_Top_Esq` | `115.7 × 11.5 × 7.0` | 9.31 | ~5.0 g |
| `GOG-230` | `ESQ_Travessa_Front_Z25_Dir` | `123.9 × 11.5 × 5.0` | 6.50 | ~3.5 g |
| `GOG-231` | `ESQ_Travessa_Front_Z25_Esq` | `115.7 × 11.5 × 5.0` | 6.65 | ~3.6 g |
| `GOG-232` | `ESQ_Travessa_Rear_Deck_Dir` | `29.8 × 12.0 × 10.8` | 3.86 | ~2.1 g |
| `GOG-233` | `ESQ_Travessa_Rear_Deck_Esq` | `184.0 × 12.0 × 10.8` | 21.25 | ~11.5 g |
| `GOG-234` | `ESQ_Travessa_Rear_N1_Dir` | `29.8 × 10.8 × 5.0` | 1.61 | ~0.9 g |
| `GOG-235` | `ESQ_Travessa_Rear_N1_Esq` | `163.8 × 10.8 × 5.0` | 8.85 | ~4.8 g |
| `GOG-236` | `ESQ_Travessa_Rear_N2_Dir` | `29.8 × 10.8 × 6.0` | 1.93 | ~1.0 g |
| `GOG-237` | `ESQ_Travessa_Rear_N2_Esq` | `163.8 × 10.8 × 6.0` | 10.58 | ~5.7 g |
| `GOG-238` | `ESQ_Travessa_Rear_Top_Dir` | `91.8 × 10.8 × 7.0` | 6.94 | ~3.8 g |
| `GOG-239` | `ESQ_Travessa_Rear_Top_Esq` | `184.0 × 10.8 × 7.0` | 13.91 | ~7.5 g |
| `GOG-240` | `ESQ_Travessa_Rear_Z25_Dir` | `91.8 × 10.8 × 5.0` | 4.96 | ~2.7 g |
| `GOG-241` | `ESQ_Travessa_Rear_Z25_Esq` | `163.8 × 10.8 × 5.0` | 8.85 | ~4.8 g |
