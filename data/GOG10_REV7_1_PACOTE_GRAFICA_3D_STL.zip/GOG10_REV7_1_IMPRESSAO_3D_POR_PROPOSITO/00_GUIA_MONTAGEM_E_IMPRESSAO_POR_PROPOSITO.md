# GUIA DE IMPRESSÃO 3D E MONTAGEM POR PROPÓSITO FUNCIONAL — GABINETE GOG10 (REV7.1)

> **ATENÇÃO (POR QUE NÃO É UM BLOCÃO ÚNICO)**:
> O gabinete `GOG10 (294,0 × 436,0 × 624,9 mm)` é um sistema modular composto por **505 placas, perfis, colunas, gavetas e dutos individuais**, todos dimensionados até `201,5 mm` para caberem em impressoras de mesa `220 × 220 mm` ou `256 × 256 mm`.
> **Nenhum item comercial (placa-mãe, roteador, fontes, cabos ou parafusos) está incluído nos arquivos `.stl` / `.3mf` — apenas o que será efetivamente impresso em 3D.**

---

## 1. COMO OS ARQUIVOS ESTÃO SEPARADOS (6 PROPÓSITOS FUNCIONAIS / 24 SUBGRUPOS)

Dentro de cada pasta você encontrará:
1. **`BANDEJAS_MESA_202x202mm_3MF_E_STL/`**:
   - **Arquivos `.3mf` (Recomendado p/ Bambu Studio, OrcaSlicer, PrusaSlicer, Cura)**: cada placa e peça na bandeja `202 × 202 mm` é um **objeto independente e separado com seu nome real** (`GOG-xxx`), já apoiado na mesa (`Z = 0`).
   - **Arquivos `.stl` por bandeja `202 × 202 mm`**: prontos para fatiar direto.
2. **`PECAS_INDIVIDUAIS_STL/`**:
   - **1 arquivo `.stl` para cada peça individual isolada**, já rotacionada para a mesa (`Z = 0`).

| Propósito Funcional | Peças | Bandejas 202×202 | Volume (cm³) | Peso Estimado (4 perím. + 35%) |
|---|---:|---:|---:|---:|
| **01 · Base, Plinto Flutuante e Sapatas de Apoio** (`01_BASE_PLINTO_E_SAPATAS`) | 40 | 9 | 502.2 cm³ | **~270 g** |
| **02 · Estrutura Portante Interna (Esqueleto: 26 Colunas, Vigas, Piso Deck e Talas)** (`02_ESTRUTURA_INTERNA_ESQUELETO`) | 112 | 17 | 2252.3 cm³ | **~1220 g** |
| **03 · Placas da Parte Externa (Carenagem #ECEAE4, 2 Portas Clique, Topo e Almas)** (`03_PLACAS_EXTERNAS_CARENAGEM_E_PORTAS`) | 131 | 44 | 5563.1 cm³ | **~2898 g** |
| **04 · Sistema das 7 Gavetas, Bandejas de Equipamentos e Corrediças Telescópicas** (`04_GAVETAS_BANDEJAS_E_CORREDICAS`) | 106 | 17 | 1033.6 cm³ | **~536 g** |
| **05 · Baía RF Preta do Roteador, Piso 4 Fendas U, Selos das Antenas e Plenums Chevron** (`05_BAIA_RF_ROTEADOR_E_VEDACAO_OPTICA`) | 76 | 16 | 1362.0 cm³ | **~721 g** |
| **06 · Dutos de Refrigeração, Chaminé Isolada MOD3, Coletores dos Blowers e Painel I/O** (`06_DUTOS_TERMICOS_CHAMINE_E_PAINEL_IO`) | 40 | 11 | 1341.2 cm³ | **~704 g** |
| **TOTAL GERAL (100% Imprimível)** | **505** | **114** | **12054.3 cm³** | **~6349 g (6.35 kg)** |

---

## 2. DETALHAMENTO DOS 24 SUBGRUPOS COM MATERIAIS, CORES E ORDEM DE MONTAGEM

### 01 · Base, Plinto Flutuante e Sapatas de Apoio
- **Função**: Base estrutural no piso (Z = 0 a 24,5 mm), 7 sapatas que recebem as colunas do 1º andar, carenagem inferior recuada (fresta 13 mm) e gaveta do filtro de ar basal.
- **Instrução de Montagem**: Passo 1 da montagem: Posicione as 7 sapatas (1A) no piso, apoie sobre elas as 4 placas do Piso Basal (1A) aparafusando com insertos M3. Encaixe por baixo o labirinto óptico preto (1C) e as placas externas brancas do plinto (1B). Deslize o cartucho do filtro basal (1C) na janela central.
- **Vistas de Referência no Site**: `V01, V03, V10, V15, V19, V21, V22, V27`

| Subgrupo | Material de Impressão | Cor Indicada | Peças | Mesas 202×202 | Peso Estimado |
|---|---|---|---:|---:|---:|
| `1A_Sapatas_e_Piso_Basal__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 13 | 6 | ~209 g |
| `1B_Placas_Externas_Plinto__ASA-PETG_BrancoOsso_ECEAE4` | **ASA / PETG / PLA+ Estético** | `Branco-Osso / Cinza-Pedra (#ECEAE4)` | 13 | 1 | ~46 g |
| `1C_Labirinto_Optico_e_Gaveta_Filtro_Basal__PETG_Preto_141619` | **PETG / ASA Opaco (Sem Fibra)** | `Preto Fosco Profundo (#141619)` | 14 | 2 | ~15 g |

### 02 · Estrutura Portante Interna (Esqueleto: 26 Colunas, Vigas, Piso Deck e Talas)
- **Função**: Chassi estrutural interno em PETG-CF que sustenta os 4 andares (T1 a T4), o piso intermediário em balanço (Z = 360 mm) e a Viga Arco superior.
- **Instrução de Montagem**: Passo 2 da montagem: Erga primeiro as 7 colunas T1 (2A) sobre as sapatas e trave com as longarinas/travessas Z25 e N1 (2F). Monte as 7 colunas T2 (2B) e longarinas N2/Deck. Assente as 4 placas do Piso Deck Central Z=360 mm e as vigas de reforço Y137/Y61 (2E) unidas pelas talas aparafusadas M3 (2G). Por fim, suba as 6 colunas T3 (2C), as 6 colunas T4 e feche o topo com a Viga Arco bipartida (2D).
- **Vistas de Referência no Site**: `V06, V10, V19, V20, V26, V28`

| Subgrupo | Material de Impressão | Cor Indicada | Peças | Mesas 202×202 | Peso Estimado |
|---|---|---|---:|---:|---:|
| `2A_Colunas_Andar1_T1__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 7 | 1 | ~140 g |
| `2B_Colunas_Andar2_T2__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 7 | 1 | ~134 g |
| `2C_Colunas_Andar3_T3__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 6 | 1 | ~112 g |
| `2D_Colunas_Andar4_T4_e_Arco_Superior__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 13 | 2 | ~172 g |
| `2E_Piso_Deck_Central_Z360_e_Vigas_Balanco__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 11 | 6 | ~339 g |
| `2F_Longarinas_e_Travessas_Horizontais__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 41 | 4 | ~238 g |
| `2G_Talas_de_Emenda_e_Bracos_Fixacao__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 27 | 2 | ~85 g |

### 03 · Placas da Parte Externa (Carenagem #ECEAE4, 2 Portas Clique, Topo e Almas)
- **Função**: Fechamento externo modular em placas (< 202 mm) com junta seca de 2 mm, 5 frisos verticais frontais ColF, 2 portas traseiras com abertura -95° e coroa superior de 21 mm.
- **Instrução de Montagem**: Passo 6 (final) da montagem: Instale primeiro as almas internas de união (3F) nos pinos/braços do esqueleto. Cole/encaixe as 4 telas colmeia pretas (3G) atrás dos painéis frontais de 5 frisos (3A). Monte os painéis frontais (3A), laterais esquerdos (3C), laterais direitos (3D) e traseiros fixos (3B). Instale as 2 portas traseiras (3B) com pino inox vertical e fecho push-latch (tic-tac). Feche o topo com os 6 colares de fresta 8 mm e as 6 placas da laje de 21 mm (3E).
- **Vistas de Referência no Site**: `V01, V02, V03, V04, V05, V18, V26, V28, V30`

| Subgrupo | Material de Impressão | Cor Indicada | Peças | Mesas 202×202 | Peso Estimado |
|---|---|---|---:|---:|---:|
| `3A_Placas_Fachada_Frontal_5Frisos_e_Lisas__BrancoOsso_ECEAE4` | **ASA / PETG / PLA+ Estético** | `Branco-Osso / Cinza-Pedra (#ECEAE4)` | 12 | 6 | ~300 g |
| `3B_Placas_Fachada_Traseira_e_2_Portas_Clique__BrancoOsso_ECEAE4` | **ASA / PETG / PLA+ Estético** | `Branco-Osso / Cinza-Pedra (#ECEAE4)` | 12 | 9 | ~507 g |
| `3C_Placas_Lateral_Esquerda_NegY__BrancoOsso_ECEAE4` | **ASA / PETG / PLA+ Estético** | `Branco-Osso / Cinza-Pedra (#ECEAE4)` | 8 | 6 | ~334 g |
| `3D_Placas_Lateral_Direita_PosY__BrancoOsso_ECEAE4` | **ASA / PETG / PLA+ Estético** | `Branco-Osso / Cinza-Pedra (#ECEAE4)` | 10 | 5 | ~296 g |
| `3E_Placas_Topo_Coroa_21mm_e_Frestas_8mm__BrancoOsso_ECEAE4` | **ASA / PETG / PLA+ Estético** | `Branco-Osso / Cinza-Pedra (#ECEAE4)` | 12 | 12 | ~1404 g |
| `3F_Almas_Internas_de_Encaixe_da_Carenagem__BrancoOsso_ECEAE4` | **ASA / PETG / PLA+ Estético** | `Branco-Osso / Cinza-Pedra (#ECEAE4)` | 73 | 3 | ~42 g |
| `3G_Telas_Colmeia_Internas_dos_Frisos__PETG_Preto_141619` | **PETG / ASA Opaco** | `Preto Fosco Profundo (#141619)` | 4 | 3 | ~15 g |

### 04 · Sistema das 7 Gavetas, Bandejas de Equipamentos e Corrediças Telescópicas
- **Função**: As 7 gavetas deslizantes independentes (Roteador MR30G, ONT Fibra, Filtro iCLAMPER, Fonte 135 W, Hub USB-C, SSD 2,5" e Cassete da Placa-Mãe LA-L161P) com seus trilhos de 3 estágios (C1 Fixo, C2 Intermediário e T3 Móvel).
- **Instrução de Montagem**: Passo 4 da montagem: Parafuse os trilhos fixos (C1) nas colunas/pisos de cada andar. Encaixe os perfis intermediários (C2) nos canais de 0,25 mm (sem graxa espessa; usar PTFE seco se desejar) e deslize as bandejas com seus trilhos móveis (T3) até engatar no dente de batente positivo. Importante: a Gaveta 1 (4A - Roteador MR30G) deve ser impressa em Policarbonato (PC) puro sem fibra de carbono para não atenuar as 4 antenas.
- **Vistas de Referência no Site**: `V11, V12, V13, V14, V16, V17, V28, V29`

| Subgrupo | Material de Impressão | Cor Indicada | Peças | Mesas 202×202 | Peso Estimado |
|---|---|---|---:|---:|---:|
| `4A_Gaveta1_Roteador_MR30G_MOD1__PC-Puro-Sem-Carga` | **Policarbonato (PC) Puro Sem Carga (Obrigatório p/ RF)** | `Preto ou Incolor Natural (Sem Carbono)` | 14 | 2 | ~67 g |
| `4B_Gaveta2_ONT_Fibra_MOD2__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 10 | 2 | ~32 g |
| `4C_Gaveta3_Filtro_iCLAMPER_MOD3__PC-FR_UL94-V0_Preto` | **PC-FR / PC-ABS FR UL94 V-0 (Retardante de Chama)** | `Preto Técnico FR` | 16 | 3 | ~108 g |
| `4D_Gaveta4_Fonte_135W_e_Blindagem_MOD3__PC-ABS-FR_Preto` | **PC-ABS FR UL94 V-0 (Alta Temp. / Retardante de Chama)** | `Preto Técnico FR` | 19 | 3 | ~90 g |
| `4E_Gaveta5_Hub_USBC_MOD4__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 12 | 2 | ~44 g |
| `4F_Gaveta6_SSD_25_SATA_MOD4__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 9 | 2 | ~40 g |
| `4G_Gaveta7_Cassete_PlacaMae_VPS_MOD4__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 26 | 3 | ~155 g |

### 05 · Baía RF Preta do Roteador, Piso 4 Fendas U, Selos das Antenas e Plenums Chevron
- **Função**: Enclausuramento interno preto fosco (#141619) da baía aberta do roteador MR30G, vedação deslizante das 4 fendas U das antenas e bloqueadores ópticos de luz (plenums chevron 45° e labirinto do teto).
- **Instrução de Montagem**: Passo 5 da montagem: Fixe o Piso Preto com 4 Fendas U e as paredes pretas da baía (5A) no quadrante frontal direito (+X/+Y, andar T1). Encaixe os selos móveis das antenas (5B) sobre a bandeja do MR30G. Posicione os 4 plenums chevron 45° (5C) atrás das telas frontais ColF e as placas do labirinto superior (5C) sob a coroa do teto.
- **Vistas de Referência no Site**: `V01, V04, V11, V21, V25, V28`

| Subgrupo | Material de Impressão | Cor Indicada | Peças | Mesas 202×202 | Peso Estimado |
|---|---|---|---:|---:|---:|
| `5A_Paredes_e_Piso_4FendasU_da_Baia_RF__Preto_141619` | **PETG / ASA Opaco (Sem Fibra)** | `Preto Fosco Profundo (#141619)` | 26 | 5 | ~321 g |
| `5B_Selos_Deslizantes_Antenas_e_Vedacao_FendasU__Preto_141619` | **PETG / ASA Opaco (Sem Fibra)** | `Preto Fosco Profundo (#141619)` | 30 | 2 | ~56 g |
| `5C_Plenums_Chevron_45graus_e_Labirinto_Topo__Preto_141619` | **PETG / ASA Opaco (Sem Fibra)** | `Preto Fosco Profundo (#141619)` | 20 | 9 | ~343 g |

### 06 · Dutos de Refrigeração, Chaminé Isolada MOD3, Coletores dos Blowers e Painel I/O
- **Função**: Separação física dos 2 circuitos térmicos (duto frio FAN1, coletor FAN2 e chaminé vertical selada de MOD3 vs. 4 coletores adiabáticos dos blowers da placa-mãe em MOD4) e painel traseiro de conectores/cabos.
- **Instrução de Montagem**: Passo 3 da montagem: Antes de fechar as laterais, instale no andar T2 o duto de admissão do FAN1, o coletor inclinado -14° do FAN2 e a metade inferior da chaminé By-Pass (6A, em PC-ABS FR UL94 V-0). No andar T3/T4, encaixe a metade superior da chaminé, o divisor de topo, os 4 coletores adiabáticos sobre os blowers da LA-L161P e o defletor secundário no suporte H2 (6B). Parafuse o suporte de colares RJ45/HDMI e clipes de cabos (6C) na traseira.
- **Vistas de Referência no Site**: `V09, V13, V14, V20, V21, V22, V23, V24, V29`

| Subgrupo | Material de Impressão | Cor Indicada | Peças | Mesas 202×202 | Peso Estimado |
|---|---|---|---:|---:|---:|
| `6A_Dutos_FAN1_FAN2_e_Chamine_MOD3__PC-ABS-FR_Preto` | **PC-ABS FR UL94 V-0 (Alta Temp. / Retardante de Chama)** | `Preto Técnico FR` | 9 | 5 | ~246 g |
| `6B_Coletores_Adiabaticos_Blowers_e_Defletores_MOD4__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 8 | 2 | ~77 g |
| `6C_Painel_Traseiro_IO_e_Clipes_Organizacao_Cabos__PETG-CF_Preto` | **PETG-CF (Fibra de Carbono)** | `Preto Fosco Estrutural` | 23 | 4 | ~381 g |
