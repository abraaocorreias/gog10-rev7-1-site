# GUIA DE IMPRESSÃO 3D OTIMIZADO (MENOR CUSTO, MENOS FILAMENTO E POR ETAPAS) — GABINETE GOG10

## AS 6 DIRETRIZES APLICADAS NESTE PACOTE `.STL` / `.3MF`
1. **Material (Maior Alavanca — Conta reduzida pela metade ou mais)**:
   - **`405` peças (`81,8%` do gabinete)** — toda a pele externa, painéis, portas, colunas (`FoS >= 15×`), pisos, longarinas, baía fria do roteador, bandejas das gavetas `MOD2`/`MOD4` e painel I/O — migradas para **`PETG Comum ou PLA+`** (`~4.09 kg` · `~141 h`).
   - **Apenas `100` peças (`18,2%`, dentro da meta de 70 a 100 peças!)** reservadas para material especial (`~1.19 kg` · `~58 h`):
     - **`42` peças em `PETG-CF` (`100%` sólido)**: somente os trilhos das corrediças, patins `40 mm`, bossas `M2.5`, `7` talas aparafusadas `M3` e `4` vigas de balanço.
     - **`37` peças em `PC-ABS FR / PC-FR UL94 V-0` (até `65 °C`)**: somente as paredes, bandejas, trilhos, dutos `FAN1/FAN2`, chaminé e `4` `BayWall` do **`MOD3` (`Fonte 135 W` + `iCLAMPER`)**.
     - **`13` peças em `PC Puro Sem Carga` (ou `PETG Puro Sem Fibra`)**: somente a bandeja e corrediças do **`MOD1`** (ao lado das `4` antenas do roteador).
2. **Menos Filamento por Peça (`-35%` de massa no Regime Leve + Zero Suporte)**:
   - **Pele, painéis, almas e baía leve (`250` peças)**: **`15%` de preenchimento + `2` perímetros (`0,84 mm`) + `3` camadas topo/base**.
   - **Colunas (`FoS >= 15×`), pisos, longarinas, bandejas e `MOD3` (`195` peças)**: **`20%` de preenchimento + `3` perímetros (`1,26 mm`) + `4` camadas topo/base**.
   - **Trilhos, patins, vigas de balanço e talas `M3` (`60` peças)**: **parede cheia e `100%` sólido (`4` perímetros)**.
   - **Alívio geométrico nas 6 lajes de `21 mm` do teto (`3E`)**: transformadas em casca de `3,2 mm` com saia de `10 mm` e nervuras de `3,0 mm` (`-1568 cm³` / `~1,0 kg` economizado, mantendo `RayLeaks = 0`), impressas viradas em `Z = 0` sem suporte.
   - **100% das `505` peças `.STL` auditadas no nível binário de triângulos (`degen = 0`, `nm = 0`, `islands = 1` em `505/505` arquivos)** e orientadas na maior face plana em `Z = 0` para imprimir sem suportes.
3. **Menos Peças, Menos Horas e Orçamento por kg e por Hora**:
   - Peças pequenas (almas, calços, clipes, selos) empacotadas juntas na mesma bandeja (`gap = 2,5 mm`).
   - Todas as tabelas e a planilha `TABELA_505_PECAS_POR_PROPOSITO_MATERIAL_PESO_E_HORAS.csv` informam **Peso (kg)** e **Tempo Estimado (h)** para você pedir orçamento **por kg e por hora de máquina**.
   - As **`36` peças puramente estéticas/ópticas** (`4` telas hexagonais, `4` plenums chevron `45°` e `28` chicanes do labirinto óptico) foram separadas no grupo **`07_OPCIONAIS_ESTETICOS_DISPENSAVEIS_NA_V1`**, podendo ser omitidas na 1ª versão funcional.
4. **Execução em Etapas Pronta na Raiz do Pacote**:
   - **`00_ETAPA_1__PILOTO_CORREDICA_E_CUPONS_INSERTO_1_MESA/`**: `7` peças em `1` única bandeja (`~21 g` · `~0.9 h`) — imprima primeiro para validar a folga de `0,25 mm` e os insertos `M3`/`M2.5`.
   - **`00_ETAPA_2__MODULO_COMPLETO_MOD1_TESTE_MONTAGEM_E_VENTILACAO/`**: `28` peças do módulo `MOD1` completo (`~168 g` · `~9.2 h` · `3` bandejas) — teste montagem e ventilação de 1 módulo antes do lote.
   - **`00_ALTERNATIVA_HIBRIDA__SO_AS_92_PECAS_TECNICAS_PARA_GRAFICA/`**: pacote isolado com apenas as **`92` peças técnicas (`~1186 g` · `~57.8 h` · `15` bandejas)** caso você decida imprimir o `PETG Comum / PLA+` em casa e mandar só o material técnico para a gráfica!

---

## RESUMO GERAL DE PESO (REGIME LEVE) E HORAS DE IMPRESSÃO

| Propósito Funcional / Grupo | Peças | Bandejas 202×202 | Volume Sólido | Peso Regime Leve (15–20% / 100% Trilhos) | Tempo Estimado (h) |
|---|---:|---:|---:|---:|---:|
| **01 · Base, Plinto Flutuante e Sapatas de Apoio (PETG Comum / PLA+)** (`01_BASE_PLINTO_E_SAPATAS`) | 29 | 8 | 486.2 cm³ | **~282 g** | **~9.6 h** |
| **02 · Estrutura Portante Interna (Colunas, Pisos e Longarinas em PETG Comum / PLA+ + Talas/Vigas em PETG-CF)** (`02_ESTRUTURA_INTERNA_ESQUELETO`) | 112 | 16 | 2252.3 cm³ | **~1254 g** | **~44.4 h** |
| **03 · Placas da Parte Externa e Portas (PETG Comum ou PLA+ · 15% Infill e 2 Perímetros)** (`03_PLACAS_EXTERNAS_CARENAGEM_E_PORTAS`) | 127 | 40 | 4010.7 cm³ | **~1636 g** | **~54.9 h** |
| **04 · Sistema das 7 Gavetas (Bandejas em PETG Comum Separadas dos Trilhos em PETG-CF / PC-ABS FR)** (`04_GAVETAS_BANDEJAS_E_CORREDICAS`) | 106 | 14 | 1033.6 cm³ | **~943 g** | **~42.5 h** |
| **05 · Baía RF do Roteador e Selos das 4 Antenas (PETG Comum Sem Fibra + 4 Paredes BayWall MOD3 em PC-ABS FR)** (`05_BAIA_RF_ROTEADOR_E_VEDACAO_OPTICA`) | 56 | 8 | 718.5 cm³ | **~341 g** | **~15.9 h** |
| **06 · Dutos Térmicos, Chaminé Isolada MOD3 e Painel Traseiro I/O** (`06_DUTOS_TERMICOS_CHAMINE_E_PAINEL_IO`) | 40 | 11 | 1341.2 cm³ | **~515 g** | **~20.4 h** |
| **07 · [OPCIONAL NA V1] Detalhes Puramente Estéticos e Ópticos (Telas Hex, Aletas Chevron 45° e Labirinto de Luz)** (`07_OPCIONAIS_ESTETICOS_DISPENSAVEIS_NA_V1`) | 35 | 12 | 687.8 cm³ | **~302 g** | **~10.7 h** |
| **TOTAL COMPLETO (Todas as 505 peças · 01 a 07)** | **505** | **109** | **10530.3 cm³** | **~5273 g (5.27 kg)** | **~198 h** |
| **TOTAL 1ª VERSÃO FUNCIONAL (Sem o Grupo `07` Estético/Óptico)** | **469** | **97** | **9842.5 cm³** | **~4971 g (4.97 kg)** | **~188 h** |
| **TOTAL V1 FUNCIONAL + CORTANDO PLACAS LISAS `3B` NO LASER (`.DXF`)** | **437** | **78** | **7652.2 cm³** | **~3972 g (3.97 kg)** | **~157 h** |
| **SÓ O LOTE TÉCNICO PARA A GRÁFICA (`00_ALTERNATIVA_HIBRIDA` · 92 peças)** | **92** | **15** | **1538.7 cm³** | **~1186 g (1.19 kg)** | **~58 h** |

---

## DETALHAMENTO DOS SUBGRUPOS COM MATERIAIS, PERFIS DE FATIAMENTO, PESO E HORAS

### 01 · Base, Plinto Flutuante e Sapatas de Apoio (PETG Comum / PLA+)
- **Função**: Base estrutural no piso (Z = 0 a 24,5 mm), 7 sapatas das colunas, carenagem inferior recuada (fresta 13 mm) e gaveta do filtro basal — 100% em PETG Comum ou PLA+.
- **Instrução de Montagem**: Passo 1: Posicione as 7 sapatas (1A) no piso e apoie sobre elas as 4 placas do Piso Basal (1A) com insertos M3. Encaixe as placas externas do plinto (1B) e deslize o cartucho do filtro basal (1C).

| Subgrupo | Material de Impressão | Configuração no Fatiador | Peças | Mesas 202×202 | Peso Leve | Tempo (h) |
|---|---|---|---:|---:|---:|---:|
| `1A_Sapatas_e_Piso_Basal__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 13 | 6 | ~241 g | ~7.7 h |
| `1B_Placas_Externas_Plinto__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 13 | 1 | ~34 g | ~1.6 h |
| `1C_Gaveta_Filtro_Basal_e_Gola__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 3 | 1 | ~6 g | ~0.3 h |

### 02 · Estrutura Portante Interna (Colunas, Pisos e Longarinas em PETG Comum / PLA+ + Talas/Vigas em PETG-CF)
- **Função**: As 26 colunas tem margem contra flambagem >= 15x no pior caso! Por isso, 101 das 112 pecas do esqueleto (colunas, pisos, longarinas e suportes de pele) usam PETG Comum ou PLA+ (20% infill, 3 perimetros), reservando PETG-CF (100% solido) apenas para as 7 talas aparafusadas M3 e 4 vigas criticas de balanco (2G).
- **Instrução de Montagem**: Passo 2: Erga as 7 colunas T1 (2A) sobre as sapatas e trave com as longarinas Z25/N1 (2F). Suba as 7 colunas T2 (2B) e o Piso Deck Central Z=360 mm (2E) unido pelas vigas e talas M3 (2G). Finalize com as colunas T3 (2C), T4 e Viga Arco (2D).

| Subgrupo | Material de Impressão | Configuração no Fatiador | Peças | Mesas 202×202 | Peso Leve | Tempo (h) |
|---|---|---|---:|---:|---:|---:|
| `2A_Colunas_Andar1_T1__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 7 | 1 | ~115 g | ~3.7 h |
| `2B_Colunas_Andar2_T2__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 7 | 1 | ~112 g | ~3.6 h |
| `2C_Colunas_Andar3_T3__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 6 | 1 | ~92 g | ~3.0 h |
| `2D_Colunas_Andar4_T4_e_Arco_Superior__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 13 | 2 | ~152 g | ~5.0 h |
| `2E_Placas_Piso_Deck_Central_Z360__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 6 | 6 | ~278 g | ~8.5 h |
| `2F_Longarinas_Travessas_e_Bracos_Pele__PETG-Comum_ou_PLA-Plus_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 56 | 4 | ~303 g | ~11.3 h |
| `2G_Talas_Parafusadas_M3_e_Vigas_Balanco__PETG-CF_100Pct_Solido` | **PETG-CF (Fibra de Carbono · 100% Sólido + 4 Perímetros)** | `100% Solido + 4 Perimetros (Sem Suporte)` | 17 | 1 | ~201 g | ~9.4 h |

### 03 · Placas da Parte Externa e Portas (PETG Comum ou PLA+ · 15% Infill e 2 Perímetros)
- **Função**: Toda a carenagem externa (#ECEAE4) usa PETG Comum ou PLA+ com 15% de preenchimento e 2 perimetros (sem suporte). As 6 lajes de 21 mm do teto (3E) foram aliviadas em casca de 3,2 mm (-1.535 cm3 / -1,0 kg!), e as 32 placas lisas de 4 mm (3B) acompanham arquivo .DXF 1:1 para opcao de corte a laser.
- **Instrução de Montagem**: Passo 6 (final): Encaixe as almas de 2 mm (3F), monte os paineis frontais de 5 frisos (3A), as placas lisas de 4 mm (3B), as 2 portas traseiras de clique (3C) e feche o teto com a coroa aliviada de 21 mm (3E).

| Subgrupo | Material de Impressão | Configuração no Fatiador | Peças | Mesas 202×202 | Peso Leve | Tempo (h) |
|---|---|---|---:|---:|---:|---:|
| `3A_Placas_Frontais_5Frisos_e_Envoltorio_Baia_3D__PETG-Comum_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 8 | 4 | ~144 g | ~4.7 h |
| `3B_Placas_Planas_Lisas_4mm__PETG-Comum_PLA-Plus_15Pct_2Perim_ou_Laser_DXF` | **PETG Comum ou PLA+ (#ECEAE4 · 15% Infill · 2 Perímetros) OU Chapa Cortada a Laser** | `15% Infill + 2 Perimetros (Sem Suporte)` | 32 | 19 | ~999 g | ~31.1 h |
| `3C_Portas_Traseiras_de_Clique_Giro_95graus__PETG-Comum_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 2 | 2 | ~111 g | ~3.4 h |
| `3E_Placas_Topo_Coroa_21mm_Aliviada_e_Frestas_8mm__PETG-Comum_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 12 | 12 | ~306 g | ~9.6 h |
| `3F_Almas_Internas_de_Encaixe_da_Carenagem__PETG-Comum_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Branco-Osso (#ECEAE4 · 15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 73 | 3 | ~77 g | ~6.1 h |

### 04 · Sistema das 7 Gavetas (Bandejas em PETG Comum Separadas dos Trilhos em PETG-CF / PC-ABS FR)
- **Função**: Para cortar o custo pela metade sem perder rigidez nem folga de 0,25 mm, separamos as BANDEJAS/CAIXAS das gavetas MOD2 e MOD4 (4B, impressas em PETG Comum ou PLA+ com 20% infill e 3 perimetros) dos TRILHOS/CORREDICAS/PATINS (4C, 31 pecas impressas em PETG-CF 100% solido). As gavetas quentes do MOD3 (4D, Fonte 135 W ate 65 °C e iCLAMPER) usam PC-ABS FR, e a Gaveta 1 do Roteador (4A, perto das antenas) usa PC Puro ou PETG Puro Sem Fibra.
- **Instrução de Montagem**: Passo 4: Parafuse os trilhos fixos C1 nas colunas/pisos, insira os perfis intermediarios C2 no canal de 0,25 mm e deslize as bandejas com os trilhos moveis T3 ate travar no batente positivo.

| Subgrupo | Material de Impressão | Configuração no Fatiador | Peças | Mesas 202×202 | Peso Leve | Tempo (h) |
|---|---|---|---:|---:|---:|---:|
| `4A_Gaveta1_Roteador_MR30G_ZonaAntenas__PC-Puro_ou_PETG-Sem-Fibra` | **PC Puro Sem Carga (ou PETG Puro Sem Fibra — Isento de Carbono p/ RF)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 13 | 2 | ~114 g | ~5.9 h |
| `4B_Bandejas_e_Caixas_Gavetas_MOD2_MOD3_MOD4__PETG-Comum_20Pct_3Perim` | **PETG Comum ou PLA+ Preto (20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 36 | 4 | ~292 g | ~10.3 h |
| `4C_Trilhos_Corredicas_e_Patins_Gavetas__PETG-CF_100Pct_Solido` | **PETG-CF (Fibra de Carbono · 100% Sólido + 4 Perímetros)** | `100% Solido + 4 Perimetros (Sem Suporte)` | 38 | 5 | ~356 g | ~16.9 h |
| `4D_Gaveta4_MOD3_Fonte135W_Ate65C_e_Trilhos__PC-ABS-FR` | **PC-ABS FR / PC-FR UL94 V-0 (Câmara Fechada · Resistente a 65 °C e Chama)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 19 | 3 | ~181 g | ~9.3 h |

### 05 · Baía RF do Roteador e Selos das 4 Antenas (PETG Comum Sem Fibra + 4 Paredes BayWall MOD3 em PC-ABS FR)
- **Função**: Enclausuramento da baia aberta do roteador MR30G: 52 pecas (piso de 4 fendas U, paredes frias, teto e selos deslizantes das antenas) em PETG Comum ou PLA+ Preto Sem Fibra (15% infill, 2 perimetros), mantendo apenas as 4 placas BayWall encostadas na fonte de 135 W em PC-ABS FR (5B).
- **Instrução de Montagem**: Passo 5: Fixe as 4 paredes BayWall termicas (5B) na divisoria com o MOD3, monte o Piso de 4 Fendas U e paredes da baia (5A) no quadrante frontal direito e encaixe os selos deslizantes das 4 antenas (5C).

| Subgrupo | Material de Impressão | Configuração no Fatiador | Peças | Mesas 202×202 | Peso Leve | Tempo (h) |
|---|---|---|---:|---:|---:|---:|
| `5A_Piso_4FendasU_Teto_e_Paredes_Frias_Baia_RF__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Preto Sem Fibra (15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 22 | 3 | ~139 g | ~5.2 h |
| `5B_Paredes_Divisorias_BayWall_Contiguas_MOD3__PC-ABS-FR_20Pct_3Perim` | **PC-ABS FR / PC-FR UL94 V-0 (Barreira Térmica entre Fonte 135 W e Roteador)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 4 | 3 | ~155 g | ~7.5 h |
| `5C_Selos_Deslizantes_4Antenas_e_Vedacao_FendasU__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Preto Sem Fibra (15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 30 | 2 | ~47 g | ~3.3 h |

### 06 · Dutos Térmicos, Chaminé Isolada MOD3 e Painel Traseiro I/O
- **Função**: Protecao termica inegociavel do MOD3 (6A: 9 pecas do duto FAN1, coletor FAN2, chamine isolada e suporte do defletor em PC-ABS FR UL94 V-0) separada dos coletores/defletores do MOD4 e do Painel Traseiro I/O (6B e 6C: 31 pecas em PETG Comum).
- **Instrução de Montagem**: Passo 3: Instale no MOD3 o duto FAN1, coletor FAN2 e chamine isolada (6A). No MOD4, fixe o suporte H2 do defletor e os 4 coletores sobre os blowers (6B). Na traseira, parafuse o painel I/O e clipes de cabos (6C).

| Subgrupo | Material de Impressão | Configuração no Fatiador | Peças | Mesas 202×202 | Peso Leve | Tempo (h) |
|---|---|---|---:|---:|---:|---:|
| `6A_Dutos_FAN1_FAN2_Chamine_e_Defletor_MOD3__PC-ABS-FR_20Pct_3Perim` | **PC-ABS FR / PC-FR UL94 V-0 (Segurança Térmica MOD3 · 20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 9 | 5 | ~180 g | ~8.8 h |
| `6B_Coletores_Blowers_e_Suporte_Defletor_H2_MOD4__PETG-Comum_20Pct_3Perim` | **PETG Comum Preto (Resistente até ~70 °C · 20% Infill · 3 Perímetros)** | `20% Infill + 3 Perimetros (Sem Suporte)` | 8 | 2 | ~90 g | ~3.0 h |
| `6C_Painel_Traseiro_IO_e_Clipes_Cabos__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | **PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 23 | 4 | ~246 g | ~8.6 h |

### 07 · [OPCIONAL NA V1] Detalhes Puramente Estéticos e Ópticos (Telas Hex, Aletas Chevron 45° e Labirinto de Luz)
- **Função**: Reune as 36 pecas que tem funcao exclusivamente estetica/optica (bloquear visao de LEDs internos): as 4 telas colmeia dos frisos, os 4 plenums chevron 45° e as 28 chicanes do labirinto optico do plinto e do teto. Podem ser 100% OMITIDAS na 1a versao funcional para economizar ~12 bandejas e ~11 horas de impressao sem afetar estrutura, gavetas ou seguranca!
- **Instrução de Montagem**: Opcional (pode nao imprimir na V1): Encaixe as 4 telas colmeia (7A) ou tela comercial atras dos frisos frontais, posicione os 4 plenums chevron (7B) e as chicanes do labirinto optico no plinto e teto (7C).

| Subgrupo | Material de Impressão | Configuração no Fatiador | Peças | Mesas 202×202 | Peso Leve | Tempo (h) |
|---|---|---|---:|---:|---:|---:|
| `7A_Telas_Colmeia_Frisos_Frontais__Opcional_ou_Tela_Comercial` | **PETG Comum ou PLA+ Preto (OU Tela Perfurada Comercial)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 4 | 3 | ~22 g | ~0.8 h |
| `7B_Aletas_Chevron_45graus_Frisos__Opcional_Estetico_V1` | **PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 14 | 3 | ~105 g | ~3.9 h |
| `7C_Labirinto_Optico_Bloqueador_LEDs_Plinto_e_Topo__Opcional_V1` | **PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)** | `15% Infill + 2 Perimetros (Sem Suporte)` | 17 | 6 | ~174 g | ~6.0 h |
