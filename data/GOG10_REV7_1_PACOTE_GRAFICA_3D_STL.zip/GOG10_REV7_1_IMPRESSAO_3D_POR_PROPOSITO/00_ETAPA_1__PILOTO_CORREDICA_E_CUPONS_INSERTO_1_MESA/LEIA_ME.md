# ETAPA 1 · Piloto da Corrediça Telescópica e Cupons de Inserto (1 Única Bandeja)

- **Peças**: `3` peças de calibração | **Peso**: **`~21 g`** | **Tempo estimado**: **`~0.9 h`**
- **Objetivo**: Antes de rodar o gabinete ou os módulos, imprima **apenas esta bandeja** para validar a folga de `0,25 mm` da corrediça de 3 estágios (`GOG-493` C1 + `GOG-495` C2 + `GOG-491` T3), o inserto de latão `M3` na tala (`GOG-497`), o inserto `M2.5` no standoff (`GOG-549`) e a junta seca de `2 mm` (`GOG-664` + `GOG-741`).
