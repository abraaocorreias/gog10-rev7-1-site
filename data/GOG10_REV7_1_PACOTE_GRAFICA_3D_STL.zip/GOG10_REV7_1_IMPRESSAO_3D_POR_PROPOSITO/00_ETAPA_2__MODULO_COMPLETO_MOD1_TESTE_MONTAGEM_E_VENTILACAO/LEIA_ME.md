# ETAPA 2 · Módulo Completo `MOD1` (Gaveta do Roteador MR30G + Corrediças + Piso 4 Fendas U + Selos das 4 Antenas)

- **Peças**: `41` peças | **Bandejas `202×202 mm`**: `3` | **Peso**: **`~168 g`** | **Tempo estimado**: **`~9.2 h`**
- **Objetivo**: Após aprovar o piloto da Etapa 1, imprima **apenas este módulo completo (`MOD1`, o menor)** para testar a montagem real, o curso de `+125 mm` com as 4 antenas passando pelas fendas em U e a ventilação antes de autorizar o lote principal.
