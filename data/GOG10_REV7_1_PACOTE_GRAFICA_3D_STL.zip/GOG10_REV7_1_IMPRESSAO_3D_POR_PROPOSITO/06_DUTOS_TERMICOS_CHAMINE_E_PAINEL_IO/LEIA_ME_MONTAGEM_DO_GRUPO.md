# 06 · Dutos Térmicos, Chaminé Isolada MOD3 e Painel Traseiro I/O

**Objetivo construtivo**: Protecao termica inegociavel do MOD3 (6A: 9 pecas do duto FAN1, coletor FAN2, chamine isolada e suporte do defletor em PC-ABS FR UL94 V-0) separada dos coletores/defletores do MOD4 e do Painel Traseiro I/O (6B e 6C: 31 pecas em PETG Comum).

**Como montar este grupo**: Passo 3: Instale no MOD3 o duto FAN1, coletor FAN2 e chamine isolada (6A). No MOD4, fixe o suporte H2 do defletor e os 4 coletores sobre os blowers (6B). Na traseira, parafuse o painel I/O e clipes de cabos (6C).

| Subpasta | Material | Fatiamento | Peças | Bandejas 202×202 | Peso Leve | Tempo Estimado |
|---|---|---|---:|---:|---:|---:|
| `6A_Dutos_FAN1_FAN2_Chamine_e_Defletor_MOD3__PC-ABS-FR_20Pct_3Perim` | PC-ABS FR / PC-FR UL94 V-0 (Segurança Térmica MOD3 · 20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 9 | 5 | **~180 g** | **~8.8 h** |
| `6B_Coletores_Blowers_e_Suporte_Defletor_H2_MOD4__PETG-Comum_20Pct_3Perim` | PETG Comum Preto (Resistente até ~70 °C · 20% Infill · 3 Perímetros) | `20% Infill + 3 Perimetros (Sem Suporte)` | 8 | 2 | **~90 g** | **~3.0 h** |
| `6C_Painel_Traseiro_IO_e_Clipes_Cabos__PETG-Comum_ou_PLA-Plus_15Pct_2Perim` | PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 23 | 4 | **~246 g** | **~8.6 h** |
