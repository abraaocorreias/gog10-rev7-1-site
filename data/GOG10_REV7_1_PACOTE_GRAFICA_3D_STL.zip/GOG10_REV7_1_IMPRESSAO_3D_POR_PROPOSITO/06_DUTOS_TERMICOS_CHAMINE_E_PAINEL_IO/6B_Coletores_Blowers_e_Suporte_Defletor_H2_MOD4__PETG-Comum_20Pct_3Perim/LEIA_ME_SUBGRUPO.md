# 6B · 4 Coletores dos Blowers da Placa-Mãe, Defletores e Suporte H2 (MOD4) — PETG Comum (20% Infill · 3 Perímetros)

- **Propósito / Função**: Captação direta dos 2 blowers originais da GPU/CPU e suporte aparafusado H2 do defletor
- **Material Recomendado**: `PETG Comum Preto (Resistente até ~70 °C · 20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `8` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `2` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `141.3 cm³` · **`~90 g`** · **`~3.0 h`** (`177 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-003` | `AIR_Coletor_Adiabatico_Dir_Frontal_BlowerDir` | `160.0 × 48.75 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 30.05 | ~18.5 g | ~0.59 h |
| `GOG-004` | `AIR_Coletor_Adiabatico_Dir_Traseiro_BlowerEsq` | `142.0 × 48.75 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 26.08 | ~16.1 g | ~0.52 h |
| `GOG-005` | `AIR_Coletor_Adiabatico_Esq_Frontal_BlowerDir` | `160.0 × 48.75 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 30.05 | ~18.5 g | ~0.59 h |
| `GOG-006` | `AIR_Coletor_Adiabatico_Esq_Traseiro_BlowerEsq` | `142.0 × 48.75 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 26.08 | ~16.1 g | ~0.52 h |
| `GOG-008` | `AIR_Defletor_AntiRecirc_Central` | `34.0 × 17.5 × 4.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 2.34 | ~1.7 g | ~0.09 h |
| `GOG-009` | `AIR_Defletor_JatoSecundario_BlowerDir` | `93.0 × 47.0 × 27.9` | `20% Infill + 3 Perimetros (Sem Suporte)` | 13.95 | ~5.2 g | ~0.19 h |
| `GOG-010` | `AIR_Defletor_JatoSecundario_BlowerEsq_BaseSelada` | `26.0 × 14.15 × 3.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.29 | ~1.0 g | ~0.08 h |
| `GOG-585` | `MOD4_Suporte_Defletor_BlowerDir` | `88.2 × 37.0 × 17.9` | `100% Solido + 4 Perimetros (Sem Suporte)` | 11.45 | ~13.2 g | ~0.43 h |
