# 6C · Painel Traseiro I/O (Colares RJ45/HDMI) e Clipes de Cabos (23 Peças) — PETG Comum ou PLA+ (15% Infill · 2 Perímetros)

- **Propósito / Função**: Ancoragem traseira de conectores e organização dos cabos internos
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Preto Fosco Estrutural` (`#1E2024`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `23` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `4` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `702.8 cm³` · **`~246 g`** · **`~8.6 h`** (`879 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-278` | `FIX_AlivioTracao_Aba_Yneg_JBAT201` | `11.55 × 7.05 × 1.65` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.13 | ~0.1 g | ~0.08 h |
| `GOG-279` | `FIX_AlivioTracao_Aba_Ypos_JBAT201` | `11.55 × 7.05 × 1.65` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.13 | ~0.1 g | ~0.08 h |
| `GOG-280` | `FIX_AlivioTracao_Base_JBAT201` | `9.4 × 2.6 × 2.25` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.05 | ~0.1 g | ~0.08 h |
| `GOG-281` | `FIX_AlivioTracao_Base_RearIO` | `8.7 × 6.5 × 5.15` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.29 | ~0.2 g | ~0.08 h |
| `GOG-282` | `FIX_AlivioTracao_Presilha_JDCIN1` | `8.6 × 8.6 × 2.2` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.06 | ~0.1 g | ~0.08 h |
| `GOG-283` | `FIX_AlivioTracao_Presilha_JHDMI1` | `7.4 × 7.4 × 3.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.07 | ~0.1 g | ~0.08 h |
| `GOG-284` | `FIX_AlivioTracao_Presilha_JLAN1` | `8.0 × 8.0 × 2.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.07 | ~0.1 g | ~0.08 h |
| `GOG-285` | `FIX_AlivioTracao_Presilha_JUSBC1` | `6.5 × 6.5 × 3.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.06 | ~0.1 g | ~0.08 h |
| `GOG-286` | `FIX_AlivioTracao_Torre_RearIO` | `79.95 × 11.37 × 9.35` | `15% Infill + 2 Perimetros (Sem Suporte)` | 3.76 | ~1.7 g | ~0.09 h |
| `GOG-570` | `MOD4_Defletor_Suporte_BlowerEsq` | `84.1 × 26.0 × 6.7` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.74 | ~1.1 g | ~0.08 h |
| `GOG-589` | `MOD4_Trilho_Filtro_Frontal_Dir` | `142.5 × 3.8 × 2.5` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.34 | ~1.2 g | ~0.08 h |
| `GOG-590` | `MOD4_Trilho_Filtro_Frontal_Esq` | `142.5 × 4.0 × 2.5` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.41 | ~1.2 g | ~0.08 h |
| `GOG-591` | `MOD4_Trilho_Filtro_Frontal_Inf` | `81.5 × 12.5 × 4.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 4.06 | ~2.3 g | ~0.11 h |
| `GOG-647` | `PAINEL_IO_Braco_Fixacao_ColRear` | `139.2 × 16.5 × 8.5` | `15% Infill + 2 Perimetros (Sem Suporte)` | 19.52 | ~8.1 g | ~0.28 h |
| `GOG-648` | `PAINEL_IO_Colar_Direto_HDMI_JHDMI1` | `16.0 × 13.2 × 3.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.80 | ~0.5 g | ~0.08 h |
| `GOG-649` | `PAINEL_IO_Colar_Direto_RJ45_JLAN1` | `16.0 × 13.2 × 3.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.80 | ~0.5 g | ~0.08 h |
| `GOG-650` | `PAINEL_IO_Suporte_Colar_Traseiro` | `39.0 × 13.2 × 6.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.76 | ~0.9 g | ~0.08 h |
| `GOG-767` | `PELE_F6_Plinto_Base8mm_F_Dir` | `145.8 × 101.8 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 115.29 | ~39.3 g | ~1.20 h |
| `GOG-768` | `PELE_F6_Plinto_Base8mm_F_Esq` | `145.8 × 124.8 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 142.10 | ~48.1 g | ~1.46 h |
| `GOG-769` | `PELE_F6_Plinto_Base8mm_M_Dir` | `101.8 × 79.1 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 61.23 | ~21.4 g | ~0.67 h |
| `GOG-770` | `PELE_F6_Plinto_Base8mm_M_Esq` | `124.8 × 79.1 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 78.87 | ~27.4 g | ~0.85 h |
| `GOG-771` | `PELE_F6_Plinto_Base8mm_R_Dir` | `154.3 × 101.8 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 124.01 | ~42.2 g | ~1.29 h |
| `GOG-772` | `PELE_F6_Plinto_Base8mm_R_Esq` | `154.3 × 124.8 × 8.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 144.25 | ~48.7 g | ~1.48 h |
