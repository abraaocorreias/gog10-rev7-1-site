# 6A · [Material Técnico Térmico · 9 Peças] Duto FAN1, Coletor FAN2, Chaminé Isolada e Defletor MOD3 — PC-ABS FR UL94 V-0

- **Propósito / Função**: Circuito selado de exaustão da fonte de 135 W e fixação dos defletores térmicos (não cortar!)
- **Material Recomendado**: `PC-ABS FR / PC-FR UL94 V-0 (Segurança Térmica MOD3 · 20% Infill · 3 Perímetros)`
- **Cor Indicada**: `Preto Técnico FR` (`#262626`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `20% Infill + 3 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `9` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `5` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `497.1 cm³` · **`~180 g`** · **`~8.8 h`** (`587 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-001` | `AIR_Chamine_ByPass_MOD3_Inf` | `152.0 × 115.8 × 84.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 107.68 | ~30.8 g | ~1.49 h |
| `GOG-002` | `AIR_Chamine_ByPass_MOD3_Sup` | `152.0 × 111.9 × 84.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 104.09 | ~29.8 g | ~1.44 h |
| `GOG-007` | `AIR_Coletor_ByPass_FAN2` | `196.0 × 153.5 × 53.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 93.72 | ~26.7 g | ~1.30 h |
| `GOG-011` | `AIR_Defletor_Termico_MOD3_MOD4_Dir` | `162.0 × 67.9 × 3.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 30.56 | ~20.4 g | ~1.00 h |
| `GOG-012` | `AIR_Defletor_Termico_MOD3_MOD4_Esq` | `162.0 × 115.65 × 3.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 53.76 | ~35.4 g | ~1.71 h |
| `GOG-013` | `AIR_Divisor_Topo_MOD3_MOD4_F` | `145.3 × 7.6 × 2.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 2.76 | ~2.4 g | ~0.15 h |
| `GOG-014` | `AIR_Divisor_Topo_MOD3_MOD4_M` | `113.0 × 7.6 × 2.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 2.15 | ~1.9 g | ~0.13 h |
| `GOG-015` | `AIR_Duto_Admissao_FAN1` | `184.0 × 156.0 × 26.5` | `20% Infill + 3 Perimetros (Sem Suporte)` | 100.93 | ~31.1 g | ~1.50 h |
| `GOG-016` | `AIR_Suporte_Defletor_MOD3_Dir` | `18.0 × 10.0 × 8.0` | `20% Infill + 3 Perimetros (Sem Suporte)` | 1.44 | ~1.0 g | ~0.09 h |
