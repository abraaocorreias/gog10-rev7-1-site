# 7C · [Opcional V1] 28 Chicanes do Labirinto Óptico do Plinto e do Teto (Bloqueio de Luz de LEDs)

- **Propósito / Função**: Chicanes internas apenas para bloquear reflexo de LEDs no piso e teto (dispensavel na V1 funcional)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Preto Fosco (#141619)` (`#141619`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `17` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `6` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `345.1 cm³` · **`~174 g`** · **`~6.0 h`** (`431 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-039` | `BAIA_Labirinto_Plinto_Dir_Front` | `125.3 × 12.9 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.62 | ~2.0 g | ~0.10 h |
| `GOG-040` | `BAIA_Labirinto_Plinto_Dir_Rear` | `37.0 × 12.9 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.77 | ~0.6 g | ~0.08 h |
| `GOG-041` | `BAIA_Labirinto_Plinto_Esq_Front` | `148.8 × 12.9 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 3.03 | ~2.3 g | ~0.11 h |
| `GOG-042` | `BAIA_Labirinto_Plinto_Esq_Mid` | `76.8 × 12.9 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.32 | ~1.0 g | ~0.08 h |
| `GOG-043` | `BAIA_Labirinto_Plinto_Esq_Mid_Seg2` | `48.8 × 12.9 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.91 | ~0.7 g | ~0.08 h |
| `GOG-044` | `BAIA_Labirinto_Plinto_Esq_RearGap` | `12.9 × 12.8 × 2.0` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.33 | ~0.3 g | ~0.08 h |
| `GOG-045` | `BAIA_Labirinto_Plinto_Front_Dir` | `91.7 × 12.9 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.69 | ~1.4 g | ~0.08 h |
| `GOG-046` | `BAIA_Labirinto_Plinto_Front_Esq` | `89.7 × 12.9 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.01 | ~1.7 g | ~0.09 h |
| `GOG-047` | `BAIA_Labirinto_Plinto_Rear_Dir` | `69.7 × 12.9 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.22 | ~1.0 g | ~0.08 h |
| `GOG-048` | `BAIA_Labirinto_Plinto_Rear_Dir_Seg2` | `29.8 × 12.9 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.59 | ~0.5 g | ~0.08 h |
| `GOG-049` | `BAIA_Labirinto_Plinto_Rear_Esq` | `89.7 × 12.9 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 1.52 | ~1.3 g | ~0.08 h |
| `GOG-050` | `BAIA_Labirinto_Topo_Plat_F_Dir` | `155.8 × 113.8 × 3.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 61.20 | ~30.0 g | ~0.93 h |
| `GOG-051` | `BAIA_Labirinto_Topo_Plat_F_Esq` | `155.8 × 147.8 × 3.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 61.31 | ~29.9 g | ~0.93 h |
| `GOG-052` | `BAIA_Labirinto_Topo_Plat_M_Dir` | `118.6 × 113.8 × 3.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 45.80 | ~22.6 g | ~0.71 h |
| `GOG-053` | `BAIA_Labirinto_Topo_Plat_M_Esq` | `147.8 × 118.6 × 3.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 51.93 | ~25.5 g | ~0.79 h |
| `GOG-054` | `BAIA_Labirinto_Topo_Plat_R_Dir` | `125.6 × 113.8 × 3.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 49.64 | ~24.5 g | ~0.76 h |
| `GOG-055` | `BAIA_Labirinto_Topo_Plat_R_Esq` | `147.8 × 125.6 × 3.6` | `15% Infill + 2 Perimetros (Sem Suporte)` | 59.17 | ~29.0 g | ~0.90 h |
