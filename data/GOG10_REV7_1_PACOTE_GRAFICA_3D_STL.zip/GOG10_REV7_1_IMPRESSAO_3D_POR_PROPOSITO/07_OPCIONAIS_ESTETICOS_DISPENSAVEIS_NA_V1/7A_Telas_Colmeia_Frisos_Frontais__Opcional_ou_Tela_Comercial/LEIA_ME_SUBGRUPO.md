# 7A · [Opcional V1] 4 Telas Hexagonais dos Frisos Frontais (100% Manifold 1 Ilha — ou substituir por tela comercial)

- **Propósito / Função**: Grade estetica atras dos 5 frisos frontais (dispensavel na V1 ou substituivel por tela comercial)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (OU Tela Perfurada Comercial)`
- **Cor Indicada**: `Preto Fosco (#141619)` (`#141619`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `4` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `28.3 cm³` · **`~22 g`** · **`~0.8 h`** (`35 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-018` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T1_ColF` | `142.84 × 104.0 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 7.88 | ~6.1 g | ~0.22 h |
| `GOG-019` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T2_ColF` | `153.94 × 104.0 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 8.41 | ~6.5 g | ~0.23 h |
| `GOG-020` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T3_ColF` | `173.94 × 104.0 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 9.39 | ~7.2 g | ~0.25 h |
| `GOG-021` | `AIR_Tela_Hex_Frisos_PELE_F6_Front_5Frisos_T4_ColF` | `104.0 × 42.84 × 1.8` | `15% Infill + 2 Perimetros (Sem Suporte)` | 2.64 | ~2.1 g | ~0.10 h |
