# 07 · [OPCIONAL NA V1] Detalhes Puramente Estéticos e Ópticos (Telas Hex, Aletas Chevron 45° e Labirinto de Luz)

**Objetivo construtivo**: Reune as 36 pecas que tem funcao exclusivamente estetica/optica (bloquear visao de LEDs internos): as 4 telas colmeia dos frisos, os 4 plenums chevron 45° e as 28 chicanes do labirinto optico do plinto e do teto. Podem ser 100% OMITIDAS na 1a versao funcional para economizar ~12 bandejas e ~11 horas de impressao sem afetar estrutura, gavetas ou seguranca!

**Como montar este grupo**: Opcional (pode nao imprimir na V1): Encaixe as 4 telas colmeia (7A) ou tela comercial atras dos frisos frontais, posicione os 4 plenums chevron (7B) e as chicanes do labirinto optico no plinto e teto (7C).

| Subpasta | Material | Fatiamento | Peças | Bandejas 202×202 | Peso Leve | Tempo Estimado |
|---|---|---|---:|---:|---:|---:|
| `7A_Telas_Colmeia_Frisos_Frontais__Opcional_ou_Tela_Comercial` | PETG Comum ou PLA+ Preto (OU Tela Perfurada Comercial) | `15% Infill + 2 Perimetros (Sem Suporte)` | 4 | 3 | **~22 g** | **~0.8 h** |
| `7B_Aletas_Chevron_45graus_Frisos__Opcional_Estetico_V1` | PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 14 | 3 | **~105 g** | **~3.9 h** |
| `7C_Labirinto_Optico_Bloqueador_LEDs_Plinto_e_Topo__Opcional_V1` | PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros) | `15% Infill + 2 Perimetros (Sem Suporte)` | 17 | 6 | **~174 g** | **~6.0 h** |
