# 7B · [Opcional V1] 4 Plenums com Aletas Chevron 45° (Bloqueio Visual dos Frisos Frontais)

- **Propósito / Função**: Veneziana obliqua interna apenas para ocultar componentes atras dos frisos (dispensavel na V1)
- **Material Recomendado**: `PETG Comum ou PLA+ Preto (15% Infill · 2 Perímetros)`
- **Cor Indicada**: `Preto Fosco (#141619)` (`#141619`)
- **Configuração de Fatiamento (Menos Filamento e Sem Suporte)**: `15% Infill + 2 Perimetros (Sem Suporte)`
- **Quantidade de Peças Imprimíveis**: `14` peças (`100%` estanques: `0` arestas não-manifold e `1` ilha por arquivo)
- **Bandejas de Impressão (`<= 202 × 202 mm`, agrupadas com `gap = 2,5 mm`)**: `3` bandeja(s)
- **Volume Sólido / Peso Regime Leve / Tempo Estimado**: `314.4 cm³` · **`~105 g`** · **`~3.9 h`** (`393 g` se 100% sólido)

## Lista das Peças deste Subgrupo:

| ID | Nome da Peça | Dimensão na Mesa (X × Y × Z mm) | Fatiamento | Volume (cm³) | Peso Leve (g) | Tempo (h) |
|---|---|---:|---|---:|---:|---:|
| `GOG-065` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T1_ColF` | `137.9 × 108.0 × 9.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 87.44 | ~28.2 g | ~0.87 h |
| `GOG-066` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T1_ColF_BracoBot` | `2.05 × 104.0 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.84 | ~0.9 g | ~0.08 h |
| `GOG-067` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T1_ColF_BracoTop` | `1.4 × 104.0 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.45 | ~0.5 g | ~0.08 h |
| `GOG-068` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T2_ColF` | `149.0 × 108.0 × 9.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 90.72 | ~29.2 g | ~0.90 h |
| `GOG-069` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T2_ColF_BracoBot` | `1.4 × 104.0 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.45 | ~0.5 g | ~0.08 h |
| `GOG-070` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T2_ColF_BracoTop` | `1.4 × 104.0 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.45 | ~0.5 g | ~0.08 h |
| `GOG-071` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF` | `169.0 × 108.0 × 9.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 106.72 | ~34.2 g | ~1.05 h |
| `GOG-072` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF_BracoBot` | `2.05 × 104.0 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.43 | ~0.5 g | ~0.08 h |
| `GOG-073` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF_BracoTop` | `1.4 × 14.8 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.06 | ~0.1 g | ~0.08 h |
| `GOG-074` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T3_ColF_BracoTop_Seg2` | `1.4 × 80.8 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.35 | ~0.4 g | ~0.08 h |
| `GOG-075` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF` | `37.9 × 108.0 × 9.4` | `15% Infill + 2 Perimetros (Sem Suporte)` | 25.24 | ~8.9 g | ~0.30 h |
| `GOG-076` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF_BracoBot` | `1.4 × 14.8 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.06 | ~0.1 g | ~0.08 h |
| `GOG-077` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF_BracoBot_Seg2` | `1.4 × 80.8 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.35 | ~0.4 g | ~0.08 h |
| `GOG-078` | `BAIA_Plenum_Hex_PELE_F6_Front_5Frisos_T4_ColF_BracoTop` | `2.05 × 104.0 × 3.95` | `15% Infill + 2 Perimetros (Sem Suporte)` | 0.84 | ~0.9 g | ~0.08 h |
