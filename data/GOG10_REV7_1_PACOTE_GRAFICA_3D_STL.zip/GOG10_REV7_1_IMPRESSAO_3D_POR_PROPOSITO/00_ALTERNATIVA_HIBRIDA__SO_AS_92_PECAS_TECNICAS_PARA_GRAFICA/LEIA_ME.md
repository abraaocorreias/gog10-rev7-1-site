# ALTERNATIVA DE FABRICAÇÃO HÍBRIDA · Somente as `92` Peças Técnicas (`PETG-CF`, `PC-ABS FR` e `PC` RF)

- **Peças**: `100` peças (`18,2%` do projeto) | **Bandejas `202×202 mm`**: `15` | **Peso total**: **`~1186 g`** | **Tempo estimado**: **`~57.8 h`**
- **Como usar esta pasta**: Se você decidir imprimir por conta própria (ou em serviço básico aberto) as **413 peças de `PETG Comum / PLA+`**, envie para a gráfica especializada (câmara fechada) **SOMENTE esta pasta (`92` peças, `~735 g`)**:
  1. **`42` peças em `PETG-CF` (`100%` sólido)**: todos os trilhos das corrediças, patins de 40 mm, bossas M2.5, 7 talas aparafusadas M3 e 4 vigas de balanço.
  2. **`37` peças em `PC-ABS FR UL94 V-0` (câmara fechada, até `65 °C`)**: paredes, bandejas, dutos `FAN1/FAN2`, chaminé e 4 `BayWall` do `MOD3` (Fonte `135 W` e `iCLAMPER`).
  3. **`13` peças em `PC Puro Sem Carga` (ou `PETG Puro Sem Fibra`)**: bandeja e corrediças do `MOD1` (ao lado das 4 antenas).
